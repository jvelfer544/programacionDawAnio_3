/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.apache.commons.lang3.LangAssertions.assertIllegalArgumentException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeFalse;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.io.Serializable;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.lang3.AbstractLangTest;
import org.apache.commons.lang3.JavaVersion;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.SystemUtils;
import org.junit.jupiter.api.Test;
import org.junitpioneer.jupiter.DefaultLocale;
import org.junitpioneer.jupiter.DefaultTimeZone;
import org.junitpioneer.jupiter.cartesian.ArgumentSets;
import org.junitpioneer.jupiter.cartesian.CartesianTest;

/**
 * Tests {@link FastDatePrinter}.
 */
class FastDatePrinterTest extends AbstractLangTest {

    private enum Expected1806 {
        India(INDIA, "+05", "+0530", "+05:30"), Greenwich(TimeZones.GMT, "Z", "Z", "Z"), NewYork(NEW_YORK, "-05", "-0500", "-05:00");

        final TimeZone zone;

        final String one;
        final String two;
        final String three;

        Expected1806(final TimeZone zone, final String one, final String two, final String three) {
            this.zone = zone;
            this.one = one;
            this.two = two;
            this.three = three;
        }
    }

    private static final String YYYY_MM_DD = "yyyy/MM/dd";
    private static final TimeZone NEW_YORK = TimeZones.getTimeZone("America/New_York");
    private static final TimeZone INDIA = TimeZones.getTimeZone("Asia/Calcutta");

    private static final Locale SWEDEN = new Locale("sv", "SE");

    private static Calendar initializeCalendar(final TimeZone tz) {
        final Calendar cal = Calendar.getInstance(tz);
        cal.set(Calendar.YEAR, 2001);
        cal.set(Calendar.MONTH, 1); // not daylight savings
        cal.set(Calendar.DAY_OF_MONTH, 4);
        cal.set(Calendar.HOUR_OF_DAY, 12);
        cal.set(Calendar.MINUTE, 8);
        cal.set(Calendar.SECOND, 56);
        cal.set(Calendar.MILLISECOND, 235);
        return cal;
    }

    static ArgumentSets testStandaloneMonthForMonthOnlyPatternFactory() {
        // Month-only patterns, with or without literals, use the standalone form; patterns with another field keep the format form.
        return ArgumentSets.argumentsForFirstParameter(Locale.US, Locale.GERMANY, new Locale("ru"), new Locale("cs"), new Locale("pl"), new Locale("fi"))
                .argumentsForNextParameter("M", "MM", "MMM", "MMMM", "MMMMM", "'m:'MMMM", "MMMM''", "MMMM,", "MMMM-", "MMMM ", "d MMMM", "MMMM yyyy",
                        "MMM MMM", "MMM LLL", "MMMM LLLL", "LLL", "LLLL")
                .argumentsForNextParameter(Calendar.JANUARY, Calendar.FEBRUARY, Calendar.MARCH, Calendar.APRIL, Calendar.MAY, Calendar.JUNE, Calendar.JULY,
                        Calendar.AUGUST, Calendar.SEPTEMBER, Calendar.OCTOBER, Calendar.NOVEMBER, Calendar.DECEMBER);
    }

    private DatePrinter getDateInstance(final int dateStyle, final Locale locale) {
        return getInstance(AbstractFormatCache.getPatternForStyle(Integer.valueOf(dateStyle), null, locale), TimeZone.getDefault(), Locale.getDefault());
    }

    DatePrinter getInstance(final String format) {
        return getInstance(format, TimeZone.getDefault(), Locale.getDefault());
    }

    private DatePrinter getInstance(final String format, final Locale locale) {
        return getInstance(format, TimeZone.getDefault(), locale);
    }

    private DatePrinter getInstance(final String format, final TimeZone timeZone) {
        return getInstance(format, timeZone, Locale.getDefault());
    }

    /**
     * Gets the printer instance to use for testing. Override this method in derived tests to change how instances are constructed.
     *
     * @param format   The format string to use
     * @param timeZone The time zone to use
     * @param locale   The locale to use
     * @return The DatePrinter to use for testing
     */
    protected DatePrinter getInstance(final String format, final TimeZone timeZone, final Locale locale) {
        return new FastDatePrinter(format, timeZone, locale);
    }

    @Test
    void test1806() {
        for (final Expected1806 trial : Expected1806.values()) {
            final Calendar cal = initializeCalendar(trial.zone);

            DatePrinter printer = getInstance("X", trial.zone);
            assertEquals(trial.one, printer.format(cal));

            printer = getInstance("XX", trial.zone);
            assertEquals(trial.two, printer.format(cal));

            printer = getInstance("XXX", trial.zone);
            assertEquals(trial.three, printer.format(cal));
        }
    }

    @Test
    void test1806Argument() {
        assertIllegalArgumentException(() -> getInstance("XXXX"));
    }

    @Test
    void testAppendableOptions() {
        final DatePrinter format = getInstance("yyyy-MM-dd HH:mm:ss.SSS Z", TimeZones.GMT);
        final Calendar calendar = Calendar.getInstance();
        final StringBuilder sb = new StringBuilder();
        final String expected = format.format(calendar, sb).toString();
        sb.setLength(0);

        final Date date = calendar.getTime();
        assertEquals(expected, format.format(date, sb).toString());
        sb.setLength(0);

        final long epoch = date.getTime();
        assertEquals(expected, format.format(epoch, sb).toString());
    }

    @Test
    void testDayNumberOfWeek() {
        final DatePrinter printer = getInstance("u");
        final Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        assertEquals("1", printer.format(calendar.getTime()));

        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
        assertEquals("6", printer.format(calendar.getTime()));

        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        assertEquals("7", printer.format(calendar.getTime()));
    }

    @Test
    void testEquals() {
        final DatePrinter printer1 = getInstance(YYYY_MM_DD);
        final DatePrinter printer2 = getInstance(YYYY_MM_DD);

        assertEquals(printer1, printer2);
        assertEquals(printer1.hashCode(), printer2.hashCode());

        assertNotEquals(printer1, new Object());
    }

    /**
     * Tests that 'G' names the era of the calendar being formatted when that calendar is not of the type the locale defaults to, like SimpleDateFormat.
     */
    @Test
    void testEraMixedCalendarTypes() {
        final Calendar cal = Calendar.getInstance(TimeZones.GMT, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.MAY, 1);
        final Date date = cal.getTime();
        // Gregorian, Thai Buddhist and Japanese Imperial calendars.
        final Locale[] locales = { Locale.US, new Locale("th", "TH"), new Locale("ja", "JP", "JP") };
        for (final Locale locale : locales) {
            for (final Locale calendarLocale : locales) {
                final Calendar calendar = Calendar.getInstance(TimeZones.GMT, calendarLocale);
                calendar.setTime(date);
                for (final String pattern : new String[] { "G", "GGGG" }) {
                    final SimpleDateFormat sdf = new SimpleDateFormat(pattern, locale);
                    sdf.setCalendar((Calendar) calendar.clone());
                    assertEquals(sdf.format(date), getInstance(pattern, TimeZones.GMT, locale).format(calendar),
                            () -> locale + " " + calendar.getCalendarType() + " " + pattern);
                }
            }
        }
    }

    /**
     * Tests that 'G' uses the era names of the locale's calendar when that calendar is not Gregorian, like SimpleDateFormat.
     */
    @Test
    void testEraNonGregorianCalendar() {
        final Calendar cal = Calendar.getInstance(TimeZones.GMT, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.MAY, 1);
        final Date date = cal.getTime();
        for (final Locale locale : new Locale[] { new Locale("th", "TH"), new Locale("ja", "JP", "JP") }) {
            for (final String pattern : new String[] { "G", "GGGG" }) {
                final SimpleDateFormat sdf = new SimpleDateFormat(pattern, locale);
                sdf.setTimeZone(TimeZones.GMT);
                assertEquals(sdf.format(date), getInstance(pattern, TimeZones.GMT, locale).format(date), () -> locale + " " + pattern);
            }
        }
    }

    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone("America/New_York")
    @Test
    void testFormat() {
        final GregorianCalendar cal1 = new GregorianCalendar(2003, 0, 10, 15, 33, 20);
        final GregorianCalendar cal2 = new GregorianCalendar(2003, 6, 10, 9, 0, 0);
        final Date date1 = cal1.getTime();
        final Date date2 = cal2.getTime();
        final long millis1 = date1.getTime();
        final long millis2 = date2.getTime();

        DatePrinter fdf = getInstance("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        assertEquals(sdf.format(date1), fdf.format(date1));
        assertEquals("2003-01-10T15:33:20", fdf.format(date1));
        assertEquals("2003-01-10T15:33:20", fdf.format(cal1));
        assertEquals("2003-01-10T15:33:20", fdf.format(millis1));
        assertEquals("2003-07-10T09:00:00", fdf.format(date2));
        assertEquals("2003-07-10T09:00:00", fdf.format(cal2));
        assertEquals("2003-07-10T09:00:00", fdf.format(millis2));

        fdf = getInstance("Z");
        assertEquals("-0500", fdf.format(date1));
        assertEquals("-0500", fdf.format(cal1));
        assertEquals("-0500", fdf.format(millis1));

        assertEquals("-0400", fdf.format(date2));
        assertEquals("-0400", fdf.format(cal2));
        assertEquals("-0400", fdf.format(millis2));

        fdf = getInstance("ZZ");
        assertEquals("-05:00", fdf.format(date1));
        assertEquals("-05:00", fdf.format(cal1));
        assertEquals("-05:00", fdf.format(millis1));

        assertEquals("-04:00", fdf.format(date2));
        assertEquals("-04:00", fdf.format(cal2));
        assertEquals("-04:00", fdf.format(millis2));

        final String pattern = "GGGG GGG GG G yyyy yyy yy y MMMM MMM MM M LLLL LLL LL L"
                + " dddd ddd dd d DDDD DDD DD D EEEE EEE EE E aaaa aaa aa a zzzz zzz zz z";
        fdf = getInstance(pattern);
        sdf = new SimpleDateFormat(pattern);
        // SDF bug fix starting with Java 7
        assertEquals(sdf.format(date1).replace("2003 03 03 03", "2003 2003 03 2003"), fdf.format(date1));
        assertEquals(sdf.format(date2).replace("2003 03 03 03", "2003 2003 03 2003"), fdf.format(date2));
    }

    @Test
    void testHourFormats() {
        final Calendar calendar = Calendar.getInstance();
        calendar.clear();
        final DatePrinter printer = getInstance("K k H h");

        calendar.set(Calendar.HOUR_OF_DAY, 0);
        assertEquals("0 24 0 12", printer.format(calendar));

        calendar.set(Calendar.HOUR_OF_DAY, 12);
        assertEquals("0 12 12 12", printer.format(calendar));

        calendar.set(Calendar.HOUR_OF_DAY, 23);
        assertEquals("11 23 23 11", printer.format(calendar));
    }

    @Test
    void testLang1103() {
        final Calendar cal = Calendar.getInstance(SWEDEN);
        cal.set(Calendar.DAY_OF_MONTH, 2);

        assertEquals("2", getInstance("d", SWEDEN).format(cal));
        assertEquals("02", getInstance("dd", SWEDEN).format(cal));
        assertEquals("002", getInstance("ddd", SWEDEN).format(cal));
        assertEquals("0002", getInstance("dddd", SWEDEN).format(cal));
        assertEquals("00002", getInstance("ddddd", SWEDEN).format(cal));
    }

    @Test
    void testLang303() {
        final Calendar cal = Calendar.getInstance();
        cal.set(2004, Calendar.DECEMBER, 31);

        DatePrinter format = getInstance(YYYY_MM_DD);
        final String output = format.format(cal);

        format = SerializationUtils.deserialize(SerializationUtils.serialize((Serializable) format));
        assertEquals(output, format.format(cal));
    }

    @Test
    void testLang538() {
        // more commonly constructed with: cal = new GregorianCalendar(2009, 9, 16, 8, 42, 16)
        // for the unit test to work in any time zone, constructing with GMT-8 rather than default locale time zone
        final GregorianCalendar cal = new GregorianCalendar(TimeZones.getTimeZone("GMT-8"));
        cal.clear();
        cal.set(2009, Calendar.OCTOBER, 16, 8, 42, 16);

        final DatePrinter format = getInstance("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", TimeZones.GMT);
        assertEquals("2009-10-16T16:42:16.000Z", format.format(cal.getTime()), "dateTime");
        assertEquals("2009-10-16T16:42:16.000Z", format.format(cal), "dateTime");
    }

    @Test
    void testLang645() {
        final Locale locale = new Locale("sv", "SE");

        final Calendar cal = Calendar.getInstance();
        cal.set(2010, Calendar.JANUARY, 1, 12, 0, 0);
        final Date d = cal.getTime();

        final DatePrinter fdf = getInstance("EEEE', week 'ww", locale);

        assertEquals("fredag, week 53", fdf.format(d));
    }

    /**
     * According to LANG-916 (https://issues.apache.org/jira/browse/LANG-916), the format method did contain a bug: it did not use the TimeZone data.
     *
     * This method test that the bug is fixed.
     */
    @Test
    void testLang916() {

        final Calendar cal = Calendar.getInstance(TimeZones.getTimeZone("Europe/Paris"));
        cal.clear();
        cal.set(2009, 9, 16, 8, 42, 16);

        // calendar fast.
        {
            final String value = FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss Z", TimeZones.getTimeZone("Europe/Paris")).format(cal);
            assertEquals("2009-10-16T08:42:16 +0200", value, "calendar");
        }
        {
            final String value = FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss Z", TimeZones.getTimeZone("Asia/Kolkata")).format(cal);
            assertEquals("2009-10-16T12:12:16 +0530", value, "calendar");
        }
        {
            final String value = FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss Z", TimeZones.getTimeZone("Europe/London")).format(cal);
            assertEquals("2009-10-16T07:42:16 +0100", value, "calendar");
        }
    }

    @Test
    void testLocaleMatches() {
        final DatePrinter printer = getInstance(YYYY_MM_DD, SWEDEN);
        assertEquals(SWEDEN, printer.getLocale());
    }

    /**
     * Tests that pre-1000AD years get padded with yyyy
     */
    @Test
    void testLowYearPadding() {
        final Calendar cal = Calendar.getInstance();
        final DatePrinter format = getInstance(YYYY_MM_DD);

        cal.set(1, Calendar.JANUARY, 1);
        assertEquals("0001/01/01", format.format(cal));
        cal.set(10, Calendar.JANUARY, 1);
        assertEquals("0010/01/01", format.format(cal));
        cal.set(100, Calendar.JANUARY, 1);
        assertEquals("0100/01/01", format.format(cal));
        cal.set(999, Calendar.JANUARY, 1);
        assertEquals("0999/01/01", format.format(cal));
    }

    /**
     * Show Bug #39410 is solved
     */
    @Test
    void testMilleniumBug() {
        final Calendar cal = Calendar.getInstance();
        final DatePrinter format = getInstance("dd.MM.yyyy");

        cal.set(1000, Calendar.JANUARY, 1);
        assertEquals("01.01.1000", format.format(cal));
    }

    @Test
    void testMonthOnlyPatternOnJava8() {
        assumeFalse(SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_9));
        final Locale[] locales = { Locale.US, Locale.GERMANY, new Locale("ru"), new Locale("cs"), new Locale("pl"), new Locale("fi") };
        for (final Locale locale : locales) {
            final DateFormatSymbols symbols = new DateFormatSymbols(locale);
            for (int month = Calendar.JANUARY; month <= Calendar.DECEMBER; month++) {
                final Calendar cal = Calendar.getInstance(TimeZones.GMT, locale);
                cal.clear();
                cal.set(2024, month, 10);
                final Date date = cal.getTime();
                // Preserve the DateFormatSymbols names used before the Java 9 standalone-month rule.
                assertEquals(symbols.getShortMonths()[month], getInstance("MMM", TimeZones.GMT, locale).format(date), () -> locale + " MMM");
                assertEquals(symbols.getMonths()[month], getInstance("MMMM", TimeZones.GMT, locale).format(date), () -> locale + " MMMM");
                assertEquals(symbols.getMonths()[month], getInstance("MMMMM", TimeZones.GMT, locale).format(date), () -> locale + " MMMMM");
                assertEquals(symbols.getMonths()[month] + ",", getInstance("MMMM,", TimeZones.GMT, locale).format(date), () -> locale + " MMMM,");
            }
        }
    }

    @Test
    void testPatternMatches() {
        final DatePrinter printer = getInstance(YYYY_MM_DD);
        assertEquals(YYYY_MM_DD, printer.getPattern());
    }

    @Test
    void testPatternsWithoutTextMonthFields() {
        final Calendar cal = Calendar.getInstance(TimeZones.GMT, Locale.US);
        cal.clear();
        cal.set(2024, Calendar.FEBRUARY, 10, 13, 45);
        final Date date = cal.getTime();
        final String[] patterns = { "M", "MM", "L", "LL", "yyyy-MM-dd", "'MMMM'", "'abc'", "", "HH:mm", "yyyy-dd" };
        for (final String pattern : patterns) {
            final SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
            sdf.setTimeZone(TimeZones.GMT);
            assertEquals(sdf.format(date), getInstance(pattern, TimeZones.GMT, Locale.US).format(date), () -> pattern);
        }
    }

    /**
     * Test case for {@link FastDateParser#FastDateParser(String, TimeZone, Locale)}.
     */
    @Test
    void testShortDateStyleWithLocales() {
        final Locale usLocale = Locale.US;
        final Locale swedishLocale = new Locale("sv", "SE");
        final Calendar cal = Calendar.getInstance();
        cal.set(2004, Calendar.FEBRUARY, 3);
        DatePrinter fdf = getDateInstance(FastDateFormat.SHORT, usLocale);
        assertEquals("2/3/04", fdf.format(cal));

        fdf = getDateInstance(FastDateFormat.SHORT, swedishLocale);
        assertEquals("2004-02-03", fdf.format(cal));

    }

    /**
     * testLowYearPadding showed that the date was buggy This test confirms it, getting 366 back as a date
     */
    @Test
    void testSimpleDate() {
        final Calendar cal = Calendar.getInstance();
        final DatePrinter format = getInstance(YYYY_MM_DD);

        cal.set(2004, Calendar.DECEMBER, 31);
        assertEquals("2004/12/31", format.format(cal));
        cal.set(999, Calendar.DECEMBER, 31);
        assertEquals("0999/12/31", format.format(cal));
        cal.set(1, Calendar.MARCH, 2);
        assertEquals("0001/03/02", format.format(cal));
    }

    /**
     * Tests that a month-only pattern uses the standalone month names, like SimpleDateFormat. In some languages, like the Slavic and Baltic ones, they are a
     * different grammatical form from the names used next to a day: "MMMM" alone prints Russian February as nominative "февраль" where "d MMMM" prints
     * genitive "февраля".
     *
     * @param locale the locale to test.
     * @param pattern the date format pattern to test.
     * @param month the calendar month to test.
     * @throws ParseException if the formatted date cannot be parsed.
     */
    @CartesianTest
    @CartesianTest.MethodFactory("testStandaloneMonthForMonthOnlyPatternFactory")
    void testStandaloneMonthForMonthOnlyPattern(final Locale locale, final String pattern, final int month) throws ParseException {
        // SimpleDateFormat forces the standalone form for a month-only pattern only since Java 9 (JDK-8114833); Java 8 has no such rule.
        assumeTrue(SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_9));
        final Calendar cal = Calendar.getInstance(TimeZones.GMT, locale);
        cal.clear();
        cal.set(2024, month, 10);
        final Date date = cal.getTime();
        final SimpleDateFormat sdf = new SimpleDateFormat(pattern, locale);
        sdf.setTimeZone(TimeZones.GMT);
        final FastDateFormat fdf = FastDateFormat.getInstance(pattern, TimeZones.GMT, locale);
        assertEquals(sdf.format(date), fdf.format(date), () -> locale + " " + pattern);
        // FastDateParser accepts all name styles, so the printer's output parses back.
        assertEquals(month, DateUtils.toCalendar(fdf.parse(fdf.format(date)), TimeZones.GMT).get(Calendar.MONTH), () -> locale + " " + pattern);
    }

    @SuppressWarnings("deprecation")
    @Test
    void testStringBufferOptions() {
        final DatePrinter format = getInstance("yyyy-MM-dd HH:mm:ss.SSS Z", TimeZones.GMT);
        final Calendar calendar = Calendar.getInstance();
        final StringBuffer sb = new StringBuffer();
        final String expected = format.format(calendar, sb, new FieldPosition(0)).toString();
        sb.setLength(0);
        assertEquals(expected, format.format(calendar, sb).toString());
        sb.setLength(0);

        final Date date = calendar.getTime();
        assertEquals(expected, format.format(date, sb, new FieldPosition(0)).toString());
        sb.setLength(0);
        assertEquals(expected, format.format(date, sb).toString());
        sb.setLength(0);

        final long epoch = date.getTime();
        assertEquals(expected, format.format(epoch, sb, new FieldPosition(0)).toString());
        sb.setLength(0);
        assertEquals(expected, format.format(epoch, sb).toString());
    }

    @DefaultTimeZone("UTC")
    @Test
    void testTimeZoneAsZ() {
        final Calendar c = Calendar.getInstance(FastTimeZone.getGmtTimeZone());
        final FastDateFormat noColonFormat = FastDateFormat.getInstance("Z");
        assertEquals("+0000", noColonFormat.format(c));

        final FastDateFormat isoFormat = FastDateFormat.getInstance("ZZ");
        assertEquals("Z", isoFormat.format(c));

        final FastDateFormat colonFormat = FastDateFormat.getInstance("ZZZ");
        assertEquals("+00:00", colonFormat.format(c));
    }

    @Test
    void testTimeZoneMatches() {
        final DatePrinter printer = getInstance(YYYY_MM_DD, NEW_YORK);
        assertEquals(NEW_YORK, printer.getTimeZone());
    }

    @Test
    void testToStringContainsName() {
        final DatePrinter printer = getInstance(YYYY_MM_DD);
        assertTrue(printer.toString().startsWith("FastDate"));
    }

    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone("America/New_York")
    @Test
    void testWeekYear() {
        final GregorianCalendar cal = new GregorianCalendar(2020, 12, 31, 0, 0, 0);
        final DatePrinter printer4Digits = getInstance("YYYY");
        final DatePrinter printer4DigitsFallback = getInstance("YYY");
        final DatePrinter printer2Digits = getInstance("YY");
        final DatePrinter printer4DigitAnotherFallback = getInstance("Y");
        assertEquals("2021", printer4Digits.format(cal));
        assertEquals("2021", printer4DigitsFallback.format(cal));
        assertEquals("2021", printer4DigitAnotherFallback.format(cal));
        assertEquals("21", printer2Digits.format(cal));
    }

    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone("America/New_York")
    @Test
    void testWeekYearBc() {
        final GregorianCalendar cal = new GregorianCalendar(42, Calendar.JULY, 15);
        cal.set(Calendar.ERA, GregorianCalendar.BC);
        assertEquals(-41, cal.getWeekYear());
        assertEquals(new SimpleDateFormat("YYYY").format(cal.getTime()), getInstance("YYYY").format(cal));
        assertEquals(new SimpleDateFormat("YYYYY").format(cal.getTime()), getInstance("YYYYY").format(cal));
        assertEquals(new SimpleDateFormat("YY").format(cal.getTime()), getInstance("YY").format(cal));
        assertEquals("-0041", getInstance("YYYY").format(cal));
        assertEquals("-00041", getInstance("YYYYY").format(cal));
        assertEquals("-41", getInstance("YY").format(cal));
        // Padded to four digits like the AD case, see testWeekYear.
        assertEquals("-0041", getInstance("YYY").format(cal));
        assertEquals("-0041", getInstance("Y").format(cal));
        // The week year of 1 BC is 0, which the digit rules already render.
        final GregorianCalendar oneBc = new GregorianCalendar(1, Calendar.JULY, 15);
        oneBc.set(Calendar.ERA, GregorianCalendar.BC);
        assertEquals("0000", getInstance("YYYY").format(oneBc));
    }
}
