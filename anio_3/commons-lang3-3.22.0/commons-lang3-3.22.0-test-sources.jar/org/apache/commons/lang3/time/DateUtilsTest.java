/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.time;

import static org.apache.commons.lang3.LangAssertions.assertIllegalArgumentException;
import static org.apache.commons.lang3.LangAssertions.assertNullPointerException;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.apache.commons.lang3.AbstractLangTest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junitpioneer.jupiter.DefaultLocale;
import org.junitpioneer.jupiter.DefaultTimeZone;
import org.junitpioneer.jupiter.ReadsDefaultLocale;
import org.junitpioneer.jupiter.ReadsDefaultTimeZone;
import org.junitpioneer.jupiter.WritesDefaultLocale;
import org.junitpioneer.jupiter.WritesDefaultTimeZone;

/**
 * Tests {@link DateUtils}.
 */
@ReadsDefaultLocale
@WritesDefaultLocale
@ReadsDefaultTimeZone
@WritesDefaultTimeZone
class DateUtilsTest extends AbstractLangTest {

    private static final Date MAX_DATE = new Date(Long.MAX_VALUE);
    private static final TimeZone TIME_ZONE_NY = TimeZones.getTimeZone("America/New_York");
    private static final TimeZone TIME_ZONE_DEFAULT = TimeZone.getDefault();
    private static final TimeZone TIME_ZONE_MET = TimeZones.getTimeZone("MET");
    private static Date BASE_DATE;

    /**
     * Used to check that Calendar objects are close enough
     * delta is in milliseconds
     */
    private static void assertCalendarsEquals(final String message, final Calendar cal1, final Calendar cal2, final long delta) {
        assertFalse(Math.abs(cal1.getTime().getTime() - cal2.getTime().getTime()) > delta,
                message + " expected " + cal1.getTime() + " but got " + cal2.getTime());
    }

    /**
     * This checks that this is a 7 element iterator of Calendar objects
     * that are dates (no time), and exactly 1 day spaced after each other.
     */
    private static void assertWeekIterator(final Iterator<?> it, final Calendar start) {
        final Calendar end = (Calendar) start.clone();
        end.add(Calendar.DATE, 6);

        assertWeekIterator(it, start, end);
    }

    /**
     * This checks that this is a 7 divisible iterator of Calendar objects
     * that are dates (no time), and exactly 1 day spaced after each other
     * (in addition to the proper start and stop dates)
     */
    private static void assertWeekIterator(final Iterator<?> it, final Calendar start, final Calendar end) {
        Calendar cal = (Calendar) it.next();
        assertCalendarsEquals("", start, cal, 0);
        Calendar last;
        int count = 1;
        while (it.hasNext()) {
            //Check this is just a date (no time component)
            assertCalendarsEquals("", cal, DateUtils.truncate(cal, Calendar.DATE), 0);

            last = cal;
            cal = (Calendar) it.next();
            count++;

            //Check that this is one day more than the last date
            last.add(Calendar.DATE, 1);
            assertCalendarsEquals("", last, cal, 0);
        }

        assertFalse(count % 7 != 0, "There were " + count + " days in this iterator");
        assertCalendarsEquals("", end, cal, 0);
    }

    /**
     * Convenience method for when working with Date objects
     */
    private static void assertWeekIterator(final Iterator<?> it, final Date start, final Date end) {
        final Calendar calStart = Calendar.getInstance();
        calStart.setTime(start);
        final Calendar calEnd = Calendar.getInstance();
        calEnd.setTime(end);

        assertWeekIterator(it, calStart, calEnd);
    }

    @BeforeAll
    public static void classSetup() {
        final GregorianCalendar cal = new GregorianCalendar(2000, 6, 5, 4, 3, 2);
        cal.set(Calendar.MILLISECOND, 1);
        BASE_DATE = cal.getTime();
    }

    private static Stream<Arguments> testToLocalDateTimeTimeZone() {
        // @formatter:off
        return Stream.of(
                // [1]
                Arguments.of(
                        // -292275055-05-16T16:47:04.192
                        LocalDateTime.of(-292275055, 5, 16, 16, 47, 04, 192_000_000),
                        new Date(Long.MIN_VALUE),
                        TimeZones.GMT
                ),
                // [2]
                Arguments.of(
                        // +292278994-08-17T07:12:55.807
                        LocalDateTime.of(292278994, 8, 17, 7, 12, 55, 807_000_000),
                        MAX_DATE,
                        TimeZones.GMT
                ),
                // [3]
                Arguments.of(
                        LocalDateTime.ofInstant(Instant.EPOCH, TimeZones.GMT.toZoneId()),
                        Date.from(LocalDateTime.of(1970, 1, 1, 0, 0).atOffset(ZoneOffset.UTC).toInstant()),
                        TimeZones.GMT
                ),
                // [4]
                Arguments.of(
                        LocalDateTime.ofInstant(Instant.EPOCH.minus(1, ChronoUnit.DAYS), TimeZones.GMT.toZoneId()),
                        Date.from(LocalDateTime.of(1969, 12, 31, 0, 0).atOffset(ZoneOffset.UTC).toInstant()),
                        TimeZones.GMT
                ),
                // [5]
                Arguments.of(
                        LocalDateTime.ofInstant(
                                java.sql.Timestamp.valueOf("2000-01-01 12:30:45").toInstant(),
                                TIME_ZONE_NY.toZoneId()
                        ),
                        java.sql.Timestamp.valueOf("2000-01-01 12:30:45"),
                        TIME_ZONE_NY
                ),
                // [6]
                Arguments.of(
                        LocalDateTime.ofInstant(
                                java.sql.Timestamp.valueOf("2023-03-12 02:30:00").toInstant(),
                                TIME_ZONE_NY.toZoneId()
                        ),
                        java.sql.Timestamp.valueOf("2023-03-12 02:30:00"),
                        TIME_ZONE_NY
                ),
                // [7]
                Arguments.of(
                        LocalDateTime.ofInstant(
                                java.sql.Timestamp.valueOf("2023-03-12 02:30:00").toInstant(),
                                TimeZones.GMT.toZoneId()
                        ),
                        java.sql.Timestamp.valueOf("2023-03-12 02:30:00"),
                        null
                ),
                // [8]
                Arguments.of(
                        LocalDateTime.of(2022, 12, 31, 19, 0),
                        Date.from(LocalDateTime.of(2023, 1, 1, 0, 0).atOffset(ZoneOffset.UTC).toInstant()),
                        TIME_ZONE_NY
                ),
                // [9]
                Arguments.of(
                        LocalDateTime.of(2023, 3, 12, 3, 0),
                        Date.from(LocalDateTime.of(2023, 3, 12, 7, 0).atOffset(ZoneOffset.UTC).toInstant()),
                        TIME_ZONE_NY
                ),
                // [10]
                Arguments.of(
                        LocalDateTime.of(2023, 1, 1, 14, 0),
                        Date.from(LocalDateTime.of(2023, 1, 1, 0, 0).atOffset(ZoneOffset.UTC).toInstant()),
                        TimeZones.getTimeZone("Pacific/Kiritimati")
                )
        );
        // @formatter:on
    }

    private DateFormat dateParser;
    private DateFormat dateTimeParser;
    private Date dateAmPm1;
    private Date dateAmPm2;
    private Date dateAmPm3;
    private Date dateAmPm4;
    private Date date0;
    private Date date1;
    private Date date2;
    private Date date3;
    private Date date4;
    private Date date5;
    private Date date6;
    private Date date7;
    private Date date8;
    private Date date9;
    private Calendar calAmPm1;
    private Calendar calAmPm2;
    private Calendar calAmPm3;
    private Calendar calAmPm4;
    private Calendar cal1;
    private Calendar cal2;
    private Calendar cal3;
    private Calendar cal4;
    private Calendar cal5;
    private Calendar cal6;
    private Calendar cal7;
    private Calendar cal8;

    @AfterEach
    public void afterEachResetTimeZones() {
        TimeZone.setDefault(TIME_ZONE_DEFAULT);
        dateTimeParser.setTimeZone(TIME_ZONE_DEFAULT);
    }
    private void assertDate(final Date date, final int year, final int month, final int day, final int hour, final int min, final int sec, final int mil) {
        final GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        assertEquals(year, cal.get(Calendar.YEAR));
        assertEquals(month, cal.get(Calendar.MONTH));
        assertEquals(day, cal.get(Calendar.DAY_OF_MONTH));
        assertEquals(hour, cal.get(Calendar.HOUR_OF_DAY));
        assertEquals(min, cal.get(Calendar.MINUTE));
        assertEquals(sec, cal.get(Calendar.SECOND));
        assertEquals(mil, cal.get(Calendar.MILLISECOND));
    }
    @BeforeEach
    public void setUp() throws Exception {
        final TimeZone defaultZone = TimeZone.getDefault();
        dateParser = new SimpleDateFormat("MMM dd, yyyy", Locale.ENGLISH);
        dateTimeParser = new SimpleDateFormat("MMM dd, yyyy H:mm:ss.SSS", Locale.ENGLISH);
        dateAmPm1 = dateTimeParser.parse("February 3, 2002 01:10:00.000");
        dateAmPm2 = dateTimeParser.parse("February 3, 2002 11:10:00.000");
        dateAmPm3 = dateTimeParser.parse("February 3, 2002 13:10:00.000");
        dateAmPm4 = dateTimeParser.parse("February 3, 2002 19:10:00.000");
        date0 = dateTimeParser.parse("February 3, 2002 12:34:56.789");
        date1 = dateTimeParser.parse("February 12, 2002 12:34:56.789");
        date2 = dateTimeParser.parse("November 18, 2001 1:23:11.321");
        try {
            TimeZone.setDefault(TIME_ZONE_MET);
            dateTimeParser.setTimeZone(TIME_ZONE_MET);
            date3 = dateTimeParser.parse("March 30, 2003 05:30:45.000");
            date4 = dateTimeParser.parse("March 30, 2003 01:10:00.000");
            date5 = dateTimeParser.parse("March 30, 2003 01:40:00.000");
            date6 = dateTimeParser.parse("March 30, 2003 02:10:00.000");
            date7 = dateTimeParser.parse("March 30, 2003 02:40:00.000");
            date8 = dateTimeParser.parse("October 26, 2003 05:30:45.000");
        } finally {
            dateTimeParser.setTimeZone(defaultZone);
            TimeZone.setDefault(defaultZone);
        }
        date9 = dateTimeParser.parse("March 30, 2003 01:10:00.000");
        calAmPm1 = Calendar.getInstance();
        calAmPm1.setTime(dateAmPm1);
        calAmPm2 = Calendar.getInstance();
        calAmPm2.setTime(dateAmPm2);
        calAmPm3 = Calendar.getInstance();
        calAmPm3.setTime(dateAmPm3);
        calAmPm4 = Calendar.getInstance();
        calAmPm4.setTime(dateAmPm4);
        cal1 = Calendar.getInstance();
        cal1.setTime(date1);
        cal2 = Calendar.getInstance();
        cal2.setTime(date2);
        try {
            TimeZone.setDefault(TIME_ZONE_MET);
            cal3 = Calendar.getInstance();
            cal3.setTime(date3);
            cal4 = Calendar.getInstance();
            cal4.setTime(date4);
            cal5 = Calendar.getInstance();
            cal5.setTime(date5);
            cal6 = Calendar.getInstance();
            cal6.setTime(date6);
            cal7 = Calendar.getInstance();
            cal7.setTime(date7);
            cal8 = Calendar.getInstance();
            cal8.setTime(date8);
        } finally {
            TimeZone.setDefault(defaultZone);
        }
    }

    @Test
    void testAddDays() throws Exception {
        Date result = DateUtils.addDays(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addDays(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 6, 4, 3, 2, 1);

        result = DateUtils.addDays(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 4, 4, 3, 2, 1);

        assertNullPointerException(() -> DateUtils.addDays(null, 0));
    }

    @DefaultTimeZone("Europe/Brussels")
    @Test
    void testAddDaysDaylightSavingTime() {
        final TimeZone brusselsTz = TimeZones.getTimeZone("Europe/Brussels");

        // 2012-03-25 00:00:00 CET: Brussels spring DST transition (23-hour day)
        final Calendar calSpring = Calendar.getInstance(brusselsTz);
        calSpring.clear();
        calSpring.set(2012, Calendar.MARCH, 25, 0, 0, 0);
        final Date inputSpring = calSpring.getTime();

        // In Europe/Brussels: calendar day advances to 2012-03-26 00:00:00 CEST (23 hours elapsed)
        final Date outputSpring = DateUtils.addDays(inputSpring, 1);
        assertEquals(TimeUnit.HOURS.toMillis(23), outputSpring.getTime() - inputSpring.getTime());

        final Calendar calSpringResult = Calendar.getInstance(brusselsTz);
        calSpringResult.setTime(outputSpring);
        assertEquals(2012, calSpringResult.get(Calendar.YEAR));
        assertEquals(Calendar.MARCH, calSpringResult.get(Calendar.MONTH));
        assertEquals(26, calSpringResult.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, calSpringResult.get(Calendar.HOUR_OF_DAY));
        assertEquals(inputSpring, DateUtils.addDays(outputSpring, -1));
        assertEquals(TimeUnit.HOURS.toMillis(24), DateUtils.addHours(inputSpring, 24).getTime() - inputSpring.getTime());

        // 2012-10-28 00:00:00 CEST: Brussels autumn DST transition (25-hour day)
        final Calendar calAutumn = Calendar.getInstance(brusselsTz);
        calAutumn.clear();
        calAutumn.set(2012, Calendar.OCTOBER, 28, 0, 0, 0);
        final Date inputAutumn = calAutumn.getTime();

        // In Europe/Brussels: calendar day advances to 2012-10-29 00:00:00 CET (25 hours elapsed)
        final Date outputAutumn = DateUtils.addDays(inputAutumn, 1);
        assertEquals(TimeUnit.HOURS.toMillis(25), outputAutumn.getTime() - inputAutumn.getTime());

        final Calendar calAutumnResult = Calendar.getInstance(brusselsTz);
        calAutumnResult.setTime(outputAutumn);
        assertEquals(2012, calAutumnResult.get(Calendar.YEAR));
        assertEquals(Calendar.OCTOBER, calAutumnResult.get(Calendar.MONTH));
        assertEquals(29, calAutumnResult.get(Calendar.DAY_OF_MONTH));
        assertEquals(0, calAutumnResult.get(Calendar.HOUR_OF_DAY));
        assertEquals(inputAutumn, DateUtils.addDays(outputAutumn, -1));
        assertEquals(TimeUnit.HOURS.toMillis(24), DateUtils.addHours(inputAutumn, 24).getTime() - inputAutumn.getTime());
    }

    @Test
    void testAddHours() throws Exception {
        Date result = DateUtils.addHours(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addHours(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 5, 3, 2, 1);

        result = DateUtils.addHours(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 3, 3, 2, 1);

        assertNullPointerException(() -> DateUtils.addHours(null, 0));
    }

    @Test
    void testAddMilliseconds() throws Exception {
        Date result = DateUtils.addMilliseconds(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addMilliseconds(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 2);

        result = DateUtils.addMilliseconds(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 0);

        assertNullPointerException(() -> DateUtils.addMilliseconds(null, 0));
    }

    @Test
    void testAddMinutes() throws Exception {
        Date result = DateUtils.addMinutes(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addMinutes(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 4, 2, 1);

        result = DateUtils.addMinutes(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 2, 2, 1);

        assertNullPointerException(() -> DateUtils.addMinutes(null, 0));
    }

    @Test
    void testAddMonths() throws Exception {
        Date result = DateUtils.addMonths(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addMonths(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 7, 5, 4, 3, 2, 1);

        result = DateUtils.addMonths(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 5, 5, 4, 3, 2, 1);

        assertNullPointerException(() -> DateUtils.addMonths(null, 0));
    }

    @Test
    void testAddSeconds() throws Exception {
        Date result = DateUtils.addSeconds(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addSeconds(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 3, 1);

        result = DateUtils.addSeconds(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 1, 1);

        assertNullPointerException(() -> DateUtils.addSeconds(null, 0));
    }

    @Test
    void testAddWeeks() throws Exception {
        Date result = DateUtils.addWeeks(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addWeeks(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 12, 4, 3, 2, 1);

        result = DateUtils.addWeeks(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);      // july
        assertDate(result, 2000, 5, 28, 4, 3, 2, 1);   // june

        assertNullPointerException(() -> DateUtils.addMonths(null, 0));
    }

    @Test
    void testAddYears() throws Exception {
        Date result = DateUtils.addYears(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addYears(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2001, 6, 5, 4, 3, 2, 1);

        result = DateUtils.addYears(BASE_DATE, -1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 1999, 6, 5, 4, 3, 2, 1);

        assertNullPointerException(() -> DateUtils.addYears(null, 0));
    }

    /**
     * Tests various values with the ceiling method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testCeiling() throws Exception {
        // test javadoc
        assertEquals(dateTimeParser.parse("March 28, 2002 14:00:00.000"),
                DateUtils.ceiling(
                            dateTimeParser.parse("March 28, 2002 13:45:01.231"),
                        Calendar.HOUR),
                "ceiling javadoc-1 failed");
        assertEquals(dateTimeParser.parse("April 1, 2002 00:00:00.000"),
                DateUtils.ceiling(
                            dateTimeParser.parse("March 28, 2002 13:45:01.231"),
                        Calendar.MONTH),
                "ceiling javadoc-2 failed");

        // tests public static Date ceiling(Date date, int field)
        assertEquals(dateParser.parse("January 1, 2003"),
                DateUtils.ceiling(date1, Calendar.YEAR),
                "ceiling year-1 failed");
        assertEquals(dateParser.parse("January 1, 2002"),
                DateUtils.ceiling(date2, Calendar.YEAR),
                "ceiling year-2 failed");
        assertEquals(dateParser.parse("March 1, 2002"),
                DateUtils.ceiling(date1, Calendar.MONTH),
                "ceiling month-1 failed");
        assertEquals(dateParser.parse("December 1, 2001"),
                DateUtils.ceiling(date2, Calendar.MONTH),
                "ceiling month-2 failed");
        assertEquals(dateParser.parse("February 16, 2002"),
                DateUtils.ceiling(date1, DateUtils.SEMI_MONTH),
                "ceiling semimonth-1 failed");
        assertEquals(dateParser.parse("December 1, 2001"),
                DateUtils.ceiling(date2, DateUtils.SEMI_MONTH),
                "ceiling semimonth-2 failed");
        assertEquals(dateParser.parse("February 13, 2002"),
                DateUtils.ceiling(date1, Calendar.DATE),
                "ceiling date-1 failed");
        assertEquals(dateParser.parse("November 19, 2001"),
                DateUtils.ceiling(date2, Calendar.DATE),
                "ceiling date-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 13:00:00.000"),
                DateUtils.ceiling(date1, Calendar.HOUR),
                "ceiling hour-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 2:00:00.000"),
                DateUtils.ceiling(date2, Calendar.HOUR),
                "ceiling hour-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:35:00.000"),
                DateUtils.ceiling(date1, Calendar.MINUTE),
                "ceiling minute-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:24:00.000"),
                DateUtils.ceiling(date2, Calendar.MINUTE),
                "ceiling minute-2 failed");
        // Edge cases (LANG-771)
        assertEquals(dateTimeParser.parse("March 30, 2003 01:10:00.000"),
                DateUtils.ceiling(date9, Calendar.MINUTE),
                "ceiling minute boundary failed");
        final Date epoch = new Date(0);
        assertEquals(epoch,
                DateUtils.ceiling(epoch, Calendar.MINUTE),
                "ceiling minute epoch failed");
        final Date negative = new Date(-1);
        assertEquals(new Date(0),
                DateUtils.ceiling(negative, Calendar.MINUTE),
                "ceiling minute negative failed");
        assertThrows(ArithmeticException.class,
                () -> DateUtils.ceiling(new Date(Long.MIN_VALUE), Calendar.MINUTE),
                "ceiling minute Long.MIN_VALUE failed");
        assertThrows(ArithmeticException.class,
                () -> DateUtils.ceiling(new Date(Long.MAX_VALUE), Calendar.MINUTE),
                "ceiling minute Long.MAX_VALUE failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:57.000"),
                DateUtils.ceiling(date1, Calendar.SECOND),
                "ceiling second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:12.000"),
                DateUtils.ceiling(date2, Calendar.SECOND),
                "ceiling second-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.ceiling(dateAmPm1, Calendar.AM_PM),
                "ceiling ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.ceiling(dateAmPm2, Calendar.AM_PM),
                "ceiling ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"),
                DateUtils.ceiling(dateAmPm3, Calendar.AM_PM),
                "ceiling ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"),
                DateUtils.ceiling(dateAmPm4, Calendar.AM_PM),
                "ceiling ampm-4 failed");

     // tests public static Date ceiling(Object date, int field)
        assertEquals(dateParser.parse("January 1, 2003"),
                DateUtils.ceiling((Object) date1, Calendar.YEAR),
                "ceiling year-1 failed");
        assertEquals(dateParser.parse("January 1, 2002"),
                DateUtils.ceiling((Object) date2, Calendar.YEAR),
                "ceiling year-2 failed");
        assertEquals(dateParser.parse("March 1, 2002"),
                DateUtils.ceiling((Object) date1, Calendar.MONTH),
                "ceiling month-1 failed");
        assertEquals(dateParser.parse("December 1, 2001"),
                DateUtils.ceiling((Object) date2, Calendar.MONTH),
                "ceiling month-2 failed");
        assertEquals(dateParser.parse("February 16, 2002"),
                DateUtils.ceiling((Object) date1, DateUtils.SEMI_MONTH),
                "ceiling semimonth-1 failed");
        assertEquals(dateParser.parse("December 1, 2001"),
                DateUtils.ceiling((Object) date2, DateUtils.SEMI_MONTH),
                "ceiling semimonth-2 failed");
        assertEquals(dateParser.parse("February 13, 2002"),
                DateUtils.ceiling((Object) date1, Calendar.DATE),
                "ceiling date-1 failed");
        assertEquals(dateParser.parse("November 19, 2001"),
                DateUtils.ceiling((Object) date2, Calendar.DATE),
                "ceiling date-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 13:00:00.000"),
                DateUtils.ceiling((Object) date1, Calendar.HOUR),
                "ceiling hour-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 2:00:00.000"),
                DateUtils.ceiling((Object) date2, Calendar.HOUR),
                "ceiling hour-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:35:00.000"),
                DateUtils.ceiling((Object) date1, Calendar.MINUTE),
                "ceiling minute-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:24:00.000"),
                DateUtils.ceiling((Object) date2, Calendar.MINUTE),
                "ceiling minute-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:57.000"),
                DateUtils.ceiling((Object) date1, Calendar.SECOND),
                "ceiling second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:12.000"),
                DateUtils.ceiling((Object) date2, Calendar.SECOND),
                "ceiling second-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.ceiling((Object) dateAmPm1, Calendar.AM_PM),
                "ceiling ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.ceiling((Object) dateAmPm2, Calendar.AM_PM),
                "ceiling ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"),
                DateUtils.ceiling((Object) dateAmPm3, Calendar.AM_PM),
                "ceiling ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"),
                DateUtils.ceiling((Object) dateAmPm4, Calendar.AM_PM),
                "ceiling ampm-4 failed");

        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:57.000"),
                DateUtils.ceiling((Object) cal1, Calendar.SECOND),
                "ceiling calendar second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:12.000"),
                DateUtils.ceiling((Object) cal2, Calendar.SECOND),
                "ceiling calendar second-2 failed");

        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.ceiling((Object) calAmPm1, Calendar.AM_PM),
                "ceiling ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.ceiling((Object) calAmPm2, Calendar.AM_PM),
                "ceiling ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"),
                DateUtils.ceiling((Object) calAmPm3, Calendar.AM_PM),
                "ceiling ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"),
                DateUtils.ceiling((Object) calAmPm4, Calendar.AM_PM),
                "ceiling ampm-4 failed");

        assertNullPointerException(() -> DateUtils.ceiling((Date) null, Calendar.SECOND));
        assertNullPointerException(() -> DateUtils.ceiling((Calendar) null, Calendar.SECOND));
        assertNullPointerException(() -> DateUtils.ceiling((Object) null, Calendar.SECOND));
        assertThrows(ClassCastException.class, () -> DateUtils.ceiling("", Calendar.SECOND));
        assertIllegalArgumentException(() -> DateUtils.ceiling(date1, -9999));

    }

    /**
     * Tests various values with the ceiling method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testCeiling_Bugzilla_31395() throws Exception {
        // Bug 31395, large dates
        final Date endOfTime = MAX_DATE; // fyi: Sun Aug 17 07:12:55 CET 292278994 -- 807 millis
        final GregorianCalendar endCal = new GregorianCalendar();
        endCal.setTime(endOfTime);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(endCal, Calendar.DATE));
        endCal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.ceiling(endCal, Calendar.DATE));
        endCal.set(Calendar.YEAR, 280000000);
        final Calendar cal = DateUtils.ceiling(endCal, Calendar.DATE);
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    /**
     * Tests various values with the ceiling method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testCeiling_MET() throws Exception {
        // Fix for https://issues.apache.org/bugzilla/show_bug.cgi?id=25560
        // Test ceiling across the beginning of daylight saving time
        TimeZone.setDefault(TIME_ZONE_MET);
        dateTimeParser.setTimeZone(TIME_ZONE_MET);

        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling(date4, Calendar.DATE), "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling((Object) cal4, Calendar.DATE),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling(date5, Calendar.DATE), "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling((Object) cal5, Calendar.DATE),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling(date6, Calendar.DATE), "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling((Object) cal6, Calendar.DATE),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling(date7, Calendar.DATE), "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 31, 2003 00:00:00.000"), DateUtils.ceiling((Object) cal7, Calendar.DATE),
                "ceiling MET date across DST change-over");

        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.ceiling(date4, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.ceiling((Object) cal4, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.ceiling(date5, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.ceiling((Object) cal5, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 04:00:00.000"), DateUtils.ceiling(date6, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 04:00:00.000"), DateUtils.ceiling((Object) cal6, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 04:00:00.000"), DateUtils.ceiling(date7, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 04:00:00.000"), DateUtils.ceiling((Object) cal7, Calendar.HOUR_OF_DAY),
                "ceiling MET date across DST change-over");
    }

    /**
     * Tests that clearing sub-hour fields does not spuriously select the later occurrence of an overlapping local time.
     *
     * @param milliseconds the millisecond value below, at, or above the rounding threshold.
     */
    @DefaultTimeZone("Europe/London")
    @ParameterizedTest
    @ValueSource(ints = { 245, 499, 500, 999 })
    void testCeilingAndRoundDstOverlap(final int milliseconds) {
        // 2024-10-27 01:00-02:00 BST repeats as 01:00-02:00 GMT; ZonedDateTime.of() picks the earlier offset, BST.
        final ZonedDateTime bst = ZonedDateTime.of(2024, 10, 27, 1, 8, 58, milliseconds * 1_000_000, ZoneId.of("Europe/London"));
        assertEquals(ZoneOffset.ofHours(1), bst.getOffset());
        final ZonedDateTime gmt = bst.withLaterOffsetAtOverlap();
        assertEquals(ZoneOffset.UTC, gmt.getOffset());
        for (final ZonedDateTime zdt : new ZonedDateTime[] { bst, gmt }) {
            final Date date = Date.from(zdt.toInstant());
            final ZonedDateTime second = zdt.truncatedTo(ChronoUnit.SECONDS);
            final ZonedDateTime minute = zdt.truncatedTo(ChronoUnit.MINUTES);
            final ZonedDateTime hour = zdt.truncatedTo(ChronoUnit.HOURS);
            assertEquals(Date.from(zdt.truncatedTo(ChronoUnit.SECONDS).plusSeconds(1).toInstant()), DateUtils.ceiling(date, Calendar.SECOND), "Ceiling Calendar.SECOND " + zdt);
            assertEquals(Date.from(second.plusSeconds(milliseconds >= 500 ? 1 : 0).toInstant()), DateUtils.round(date, Calendar.SECOND),
                    "Round Calendar.SECOND " + zdt);
            assertEquals(Date.from(minute.plusMinutes(1).toInstant()), DateUtils.ceiling(date, Calendar.MINUTE), "Ceiling Calendar.MINUTE " + zdt);
            assertEquals(Date.from(minute.plusMinutes(1).toInstant()), DateUtils.round(date, Calendar.MINUTE), "Round Calendar.MINUTE " + zdt);
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.ceiling(date, Calendar.HOUR_OF_DAY), "Ceiling Calendar.HOUR_OF_DAY " + zdt);
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.ceiling(date, Calendar.HOUR), "Ceiling Calendar.HOUR " + zdt);
            assertEquals(Date.from(hour.toInstant()), DateUtils.round(date, Calendar.HOUR_OF_DAY), "Round Calendar.HOUR_OF_DAY " + zdt);
            // 38 minutes past rounds up to the next hour
            final Date late = Date.from(zdt.withMinute(38).toInstant());
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.round(late, Calendar.HOUR_OF_DAY), "Round up Calendar.HOUR_OF_DAY " + zdt);
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.round(late, Calendar.HOUR), "Round up Calendar.HOUR " + zdt);
        }
    }

    /**
     * Tests that clearing sub-hour fields does not spuriously select the later occurrence of an overlapping local time.
     *
     * @param milliseconds the millisecond value below, at, or above the rounding threshold.
     */
    @DefaultTimeZone("UTC")
    @ParameterizedTest
    @ValueSource(ints = { 245, 499, 500, 999 })
    void testCeilingAndRoundDstOverlapCalendar(final int milliseconds) {
        // 2024-10-27 01:00-02:00 BST repeats as 01:00-02:00 GMT; ZonedDateTime.of() picks the earlier offset, BST.
        final ZonedDateTime bst = ZonedDateTime.of(2024, 10, 27, 1, 8, 58, milliseconds * 1_000_000, ZoneId.of("Europe/London"));
        assertEquals(ZoneOffset.ofHours(1), bst.getOffset());
        final ZonedDateTime gmt = bst.withLaterOffsetAtOverlap();
        assertEquals(ZoneOffset.UTC, gmt.getOffset());
        for (final ZonedDateTime zdt : new ZonedDateTime[] { bst, gmt }) {
            final Calendar date = GregorianCalendar.from(zdt);
            final Calendar original = (Calendar) date.clone();
            final ZonedDateTime second = zdt.truncatedTo(ChronoUnit.SECONDS);
            final ZonedDateTime minute = zdt.truncatedTo(ChronoUnit.MINUTES);
            final ZonedDateTime hour = zdt.truncatedTo(ChronoUnit.HOURS);
            assertEquals(Date.from(zdt.truncatedTo(ChronoUnit.SECONDS).plusSeconds(1).toInstant()), DateUtils.ceiling(date, Calendar.SECOND).getTime(), "Ceiling Calendar.SECOND " + zdt);
            assertEquals(Date.from(second.plusSeconds(milliseconds >= 500 ? 1 : 0).toInstant()), DateUtils.round(date, Calendar.SECOND).getTime(),
                    "Round Calendar.SECOND " + zdt);
            assertEquals(Date.from(minute.plusMinutes(1).toInstant()), DateUtils.ceiling(date, Calendar.MINUTE).getTime(), "Ceiling Calendar.MINUTE " + zdt);
            assertEquals(Date.from(minute.plusMinutes(1).toInstant()), DateUtils.round(date, Calendar.MINUTE).getTime(), "Round Calendar.MINUTE " + zdt);
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.ceiling(date, Calendar.HOUR_OF_DAY).getTime(), "Ceiling Calendar.HOUR_OF_DAY " + zdt);
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.ceiling(date, Calendar.HOUR).getTime(), "Ceiling Calendar.HOUR " + zdt);
            assertEquals(Date.from(hour.toInstant()), DateUtils.round(date, Calendar.HOUR_OF_DAY).getTime(), "Round Calendar.HOUR_OF_DAY " + zdt);
            // 38 minutes past rounds up to the next hour
            final Calendar late = GregorianCalendar.from(zdt.withMinute(38));
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.round(late, Calendar.HOUR_OF_DAY).getTime(), "Round up Calendar.HOUR_OF_DAY " + zdt);
            assertEquals(Date.from(hour.plusHours(1).toInstant()), DateUtils.round(late, Calendar.HOUR).getTime(), "Round up Calendar.HOUR " + zdt);
            assertEquals(zdt.getZone().getId(), DateUtils.ceiling(date, Calendar.HOUR_OF_DAY).getTimeZone().getID());
            assertEquals(original, date, "Input calendar must remain unchanged");
        }
    }

    @Test
    void testConstructor() {
        assertNotNull(new DateUtils());
        final Constructor<?>[] cons = DateUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(DateUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(DateUtils.class.getModifiers()));
    }

    /**
     * Failed date parse can poison the calendar's time zone for the next pattern.
     *
     * <p>
     * {@link DateUtils#parseDateWithLeniency} reuses a single {@link Calendar} across pattern attempts. The reset between iterations is
     * {@link Calendar#clear()}, which does NOT reset the calendar's time zone. A TZ-aware pattern (e.g. starts with {@code "X"}, {@code "Z"}, {@code "z"}) that
     * successfully consumes its TZ token (mutating the calendar via {@link Calendar#setTimeZone}) before failing on later tokens leaves the calendar carrying
     * the parsed (foreign) zone. The next pattern in the list then interprets its date fields against that zone, producing a wrong instant.
     * </p>
     *
     * <p>
     * <b>Construction:</b> input {@code "+0500 01/01/2024"} is parsed against two patterns:
     * </p>
     * <ol>
     * <li>{@code "Z 'X' MM/dd/yyyy"}: the {@code Z} strategy consumes {@code "+0500"} and calls {@code calendar.setTimeZone(GMT+05:00)}; the next literal
     * {@code 'X'} fails to match {@code " 01"}, so the overall parse returns false. The leaked TZ remains on the shared calendar.</li>
     * <li>{@code "'+0500 'MM/dd/yyyy"}: a TZ-less pattern that absorbs the literal prefix and parses the date. With the bug, the calendar still carries
     * GMT+05:00, so the date is interpreted as midnight in GMT+05:00 (5 hours earlier as an instant) than the same date interpreted in the system default
     * zone.</li>
     * </ol>
     *
     * <p>
     * The assertion compares {@link Date#getTime()} against a baseline parse using only the second pattern. A naive PoC that only checked calendar fields
     * (year/month/day) would not detect the bug because those equal in both runs.
     * </p>
     *
     * <p>
     * Pre-patch: the bug shifts the resulting instant by 5 hours.<br>
     * Post-patch: {@code parseDateWithLeniency} restores {@code calendar.setTimeZone(TimeZone.getDefault())} before each iteration, so the leaked zone never
     * reaches the second attempt and both instants match.
     * </p>
     */
    @Test
    public void testFailedTimeZonePatternDoesNotPoisonNextPatternInstant() throws Exception {
        final String input = "+0500 01/01/2024";
        // Baseline: a single TZ-less pattern; no leak source. The calendar uses
        // TimeZone.getDefault(), so the result is midnight 2024-01-01 in the default zone.
        final Date baseline = DateUtils.parseDate(input, "'+0500 'MM/dd/yyyy");
        assertNotNull(baseline, "baseline parse must succeed");
        // Poisoning sequence:
        //   pattern 1 = "Z 'X' MM/dd/yyyy"  -> Z consumes "+0500" then setTimeZone(GMT+05:00),
        //                                       'X' literal mismatches " 01", returns false.
        //   pattern 2 = "'+0500 'MM/dd/yyyy"-> matches the whole input via literal prefix +
        //                                       MM/dd/yyyy. With the bug, calendar still has
        //                                       GMT+05:00 leaked from pattern 1, so the date
        //                                       is interpreted in GMT+05:00 instead of default.
        final Date poisoned = DateUtils.parseDate(input, "Z 'X' MM/dd/yyyy", "'+0500 'MM/dd/yyyy");
        assertNotNull(poisoned, "poisoning sequence parse must succeed via the second pattern");
        // Compare INSTANTS, not Y/M/D. Calendar fields equal in both runs by coincidence
        // even when the bug shifts the underlying instant.
        assertEquals(baseline.getTime(), poisoned.getTime(),
                "Calendar TZ leaked from a failed prior pattern must not affect the instant produced by a subsequent TZ-less pattern");
    }

    @Test
    void testIsSameDay_Cal() {
        final GregorianCalendar cala = new GregorianCalendar(2004, 6, 9, 13, 45);
        final GregorianCalendar calb = new GregorianCalendar(2004, 6, 9, 13, 45);
        assertTrue(DateUtils.isSameDay(cala, calb));
        calb.add(Calendar.DAY_OF_YEAR, 1);
        assertFalse(DateUtils.isSameDay(cala, calb));
        cala.add(Calendar.DAY_OF_YEAR, 1);
        assertTrue(DateUtils.isSameDay(cala, calb));
        calb.add(Calendar.YEAR, 1);
        assertFalse(DateUtils.isSameDay(cala, calb));
    }

    @Test
    void testIsSameDay_CalNotNullNull() {
        assertNullPointerException(() -> DateUtils.isSameDay(Calendar.getInstance(), null));
    }

    @Test
    void testIsSameDay_CalNullNotNull() {
        assertNullPointerException(() -> DateUtils.isSameDay(null, Calendar.getInstance()));
    }

    @Test
    void testIsSameDay_CalNullNull() {
        assertNullPointerException(() -> DateUtils.isSameDay((Calendar) null, null));
    }

    @Test
    void testIsSameDay_Date() {
        Date dateA = new GregorianCalendar(2004, 6, 9, 13, 45).getTime();
        Date dateB = new GregorianCalendar(2004, 6, 9, 13, 45).getTime();
        assertTrue(DateUtils.isSameDay(dateA, dateB));
        dateB = new GregorianCalendar(2004, 6, 10, 13, 45).getTime();
        assertFalse(DateUtils.isSameDay(dateA, dateB));
        dateA = new GregorianCalendar(2004, 6, 10, 13, 45).getTime();
        assertTrue(DateUtils.isSameDay(dateA, dateB));
        dateB = new GregorianCalendar(2005, 6, 10, 13, 45).getTime();
        assertFalse(DateUtils.isSameDay(dateA, dateB));
        assertTrue(DateUtils.isSameDay(dateA, dateA));
        assertTrue(DateUtils.isSameDay(dateA, (Date) dateA.clone()));
        assertTrue(DateUtils.isSameDay(MAX_DATE, MAX_DATE));
        assertTrue(DateUtils.isSameDay(MAX_DATE, (Date) MAX_DATE.clone()));
    }

    @Test
    void testIsSameDay_DateNotNullNull() {
        assertNullPointerException(() -> DateUtils.isSameDay(new Date(), null));
    }

    @Test
    void testIsSameDay_DateNullNotNull() {
        assertNullPointerException(() -> DateUtils.isSameDay(null, new Date()));
    }

    @Test
    void testIsSameDay_DateNullNull() {
        assertNullPointerException(() -> DateUtils.isSameDay((Date) null, null));
    }

    @Test
    void testIsSameInstant_Cal() {
        final GregorianCalendar cala = new GregorianCalendar(TimeZones.getTimeZone("GMT+1"));
        final GregorianCalendar calb = new GregorianCalendar(TimeZones.getTimeZone("GMT-1"));
        cala.set(2004, Calendar.JULY, 9, 13, 45, 0);
        cala.set(Calendar.MILLISECOND, 0);
        calb.set(2004, Calendar.JULY, 9, 13, 45, 0);
        calb.set(Calendar.MILLISECOND, 0);
        assertFalse(DateUtils.isSameInstant(cala, calb));

        calb.set(2004, Calendar.JULY, 9, 11, 45, 0);
        assertTrue(DateUtils.isSameInstant(cala, calb));
    }

    @Test
    void testIsSameInstant_CalNotNullNull() {
        assertNullPointerException(() -> DateUtils.isSameInstant(Calendar.getInstance(), null));
    }

    @Test
    void testIsSameInstant_CalNullNotNull() {
        assertNullPointerException(() -> DateUtils.isSameInstant(null, Calendar.getInstance()));
    }

    @Test
    void testIsSameInstant_CalNullNull() {
        assertNullPointerException(() -> DateUtils.isSameInstant((Calendar) null, null));
    }

    @Test
    void testIsSameInstant_Date() {
        Date datea = new GregorianCalendar(2004, 6, 9, 13, 45).getTime();
        Date dateb = new GregorianCalendar(2004, 6, 9, 13, 45).getTime();
        assertTrue(DateUtils.isSameInstant(datea, dateb));
        dateb = new GregorianCalendar(2004, 6, 10, 13, 45).getTime();
        assertFalse(DateUtils.isSameInstant(datea, dateb));
        datea = new GregorianCalendar(2004, 6, 10, 13, 45).getTime();
        assertTrue(DateUtils.isSameInstant(datea, dateb));
        dateb = new GregorianCalendar(2005, 6, 10, 13, 45).getTime();
        assertFalse(DateUtils.isSameInstant(datea, dateb));
    }

    @Test
    void testIsSameInstant_DateNotNullNull() {
        assertNullPointerException(() -> DateUtils.isSameInstant(new Date(), null));
    }

    @Test
    void testIsSameInstant_DateNullNotNull() {
        assertNullPointerException(() -> DateUtils.isSameInstant(null, new Date()));
    }

    @Test
    void testIsSameInstant_DateNullNull() {
        assertNullPointerException(() -> DateUtils.isSameInstant((Date) null, null));
    }

    @Test
    void testIsSameLocalTime_Cal() {
        final GregorianCalendar cala = new GregorianCalendar(TimeZones.getTimeZone("GMT+1"));
        final GregorianCalendar calb = new GregorianCalendar(TimeZones.getTimeZone("GMT-1"));
        cala.set(2004, Calendar.JULY, 9, 13, 45, 0);
        cala.set(Calendar.MILLISECOND, 0);
        calb.set(2004, Calendar.JULY, 9, 13, 45, 0);
        calb.set(Calendar.MILLISECOND, 0);
        assertTrue(DateUtils.isSameLocalTime(cala, calb));

        final Calendar calc = Calendar.getInstance();
        final Calendar cald = Calendar.getInstance();
        calc.set(2004, Calendar.JULY, 9, 4,  0, 0);
        cald.set(2004, Calendar.JULY, 9, 16, 0, 0);
        calc.set(Calendar.MILLISECOND, 0);
        cald.set(Calendar.MILLISECOND, 0);
        assertFalse(DateUtils.isSameLocalTime(calc, cald), "LANG-677");

        calb.set(2004, Calendar.JULY, 9, 11, 45, 0);
        assertFalse(DateUtils.isSameLocalTime(cala, calb));
    }

    @Test
    void testIsSameLocalTime_CalNotNullNull() {
        assertNullPointerException(() -> DateUtils.isSameLocalTime(Calendar.getInstance(), null));
    }

    @Test
    void testIsSameLocalTime_CalNullNotNull() {
        assertNullPointerException(() -> DateUtils.isSameLocalTime(null, Calendar.getInstance()));
    }

    @Test
    void testIsSameLocalTime_CalNullNull() {
        assertNullPointerException(() -> DateUtils.isSameLocalTime(null, null));
    }

    /**
     * Tests the iterator exceptions
     */
    @Test
    void testIteratorEx() {
        assertIllegalArgumentException(() -> DateUtils.iterator(Calendar.getInstance(), -9999));
        assertNullPointerException(() -> DateUtils.iterator((Date) null, DateUtils.RANGE_WEEK_CENTER));
        assertNullPointerException(() -> DateUtils.iterator((Calendar) null, DateUtils.RANGE_WEEK_CENTER));
        assertNullPointerException(() -> DateUtils.iterator((Object) null, DateUtils.RANGE_WEEK_CENTER));
        assertThrows(ClassCastException.class, () -> DateUtils.iterator("", DateUtils.RANGE_WEEK_CENTER));
    }

    /** See https://issues.apache.org/jira/browse/LANG-530 */
    @SuppressWarnings("deprecation")
    @Test
    void testLang530() throws ParseException {
        final Date d = new Date();
        final String isoDateStr = DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.format(d);
        final Date d2 = DateUtils.parseDate(isoDateStr, DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.getPattern());
        // the format loses milliseconds so have to reintroduce them
        assertEquals(d.getTime(), d2.getTime() + d.getTime() % 1000, "Date not equal to itself ISO formatted and parsed");
    }

    @Test
    void testLANG799() throws ParseException {
        DateUtils.parseDateStrictly("09 abril 2008 23:55:38 GMT", new Locale("es"), "dd MMM yyyy HH:mm:ss zzz");
    }

    /** Parse English date with German Locale. */
    @DefaultLocale(language = "de")
    @Test
    void testLANG799_DE_FAIL() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("Wed, 09 Apr 2008 23:55:38 GMT", "EEE, dd MMM yyyy HH:mm:ss zzz"));
    }

    @DefaultLocale(language = "de")
    @Test
    void testLANG799_DE_OK() throws ParseException {
        DateUtils.parseDate("Mi, 09 Apr 2008 23:55:38 GMT", "EEE, dd MMM yyyy HH:mm:ss zzz");
        DateUtils.parseDateStrictly("Mi, 09 Apr 2008 23:55:38 GMT", "EEE, dd MMM yyyy HH:mm:ss zzz");
    }

    // Parse German date with English Locale
    @DefaultLocale(language = "en")
    @Test
    void testLANG799_EN_FAIL() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("Mi, 09 Apr 2008 23:55:38 GMT", "EEE, dd MMM yyyy HH:mm:ss zzz"));
    }

    @DefaultLocale(language = "en")
    @Test
    void testLANG799_EN_OK() throws ParseException {
        DateUtils.parseDate("Wed, 09 Apr 2008 23:55:38 GMT", "EEE, dd MMM yyyy HH:mm:ss zzz");
        DateUtils.parseDateStrictly("Wed, 09 Apr 2008 23:55:38 GMT", "EEE, dd MMM yyyy HH:mm:ss zzz");
    }

    /** Parse German date with English Locale, specifying German Locale override. */
    @DefaultLocale(language = "en")
    @Test
    void testLANG799_EN_WITH_DE_LOCALE() throws ParseException {
        DateUtils.parseDate("Mi, 09 Apr 2008 23:55:38 GMT", Locale.GERMAN, "EEE, dd MMM yyyy HH:mm:ss zzz");
    }

    /**
     * Tests the calendar iterator for month-based ranges
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testMonthIterator() throws Exception {
        Iterator<?> it = DateUtils.iterator(date1, DateUtils.RANGE_MONTH_SUNDAY);
        assertWeekIterator(it,
                dateParser.parse("January 27, 2002"),
                dateParser.parse("March 2, 2002"));

        it = DateUtils.iterator(date1, DateUtils.RANGE_MONTH_MONDAY);
        assertWeekIterator(it,
                dateParser.parse("January 28, 2002"),
                dateParser.parse("March 3, 2002"));

        it = DateUtils.iterator(date2, DateUtils.RANGE_MONTH_SUNDAY);
        assertWeekIterator(it,
                dateParser.parse("October 28, 2001"),
                dateParser.parse("December 1, 2001"));

        it = DateUtils.iterator(date2, DateUtils.RANGE_MONTH_MONDAY);
        assertWeekIterator(it,
                dateParser.parse("October 29, 2001"),
                dateParser.parse("December 2, 2001"));
    }

    @Test
    void testParse_EmptyParsers() {
        assertThrows(ParseException.class, () -> DateUtils.parseDate("19721203"));
    }

    @Test
    void testParse_NullParsers() {
        assertNullPointerException(() -> DateUtils.parseDate("19721203", (String[]) null));
    }

    @Test
    void testParseDate() throws Exception {
        final GregorianCalendar cal = new GregorianCalendar(1972, 11, 3);
        String dateStr = "1972-12-03";
        final String[] parsers = {"yyyy'-'DDD", "yyyy'-'MM'-'dd", "yyyyMMdd"};
        Date date = DateUtils.parseDate(dateStr, parsers);
        assertEquals(cal.getTime(), date);

        dateStr = "1972-338";
        date = DateUtils.parseDate(dateStr, parsers);
        assertEquals(cal.getTime(), date);

        dateStr = "19721203";
        date = DateUtils.parseDate(dateStr, parsers);
        assertEquals(cal.getTime(), date);
    }

    @Test
    void testParseDate_InvalidDateString() {
        final String[] parsers = {"yyyy'-'DDD", "yyyy'-'MM'-'dd", "yyyyMMdd"};
        assertThrows(ParseException.class, () -> DateUtils.parseDate("197212AB", parsers));
    }

    @Test
    void testParseDate_NoDateString() {
        final String[] parsers = {"yyyy'-'DDD", "yyyy'-'MM'-'dd", "yyyyMMdd"};
        assertThrows(ParseException.class, () -> DateUtils.parseDate("PURPLE", parsers));
    }

    @Test
    void testParseDate_Null() {
        final String[] parsers = {"yyyy'-'DDD", "yyyy'-'MM'-'dd", "yyyyMMdd"};
        assertNullPointerException(() -> DateUtils.parseDate(null, parsers));
    }

    /** LANG-486 */
    @Test
    void testParseDateWithLeniency() throws ParseException {
        final GregorianCalendar cal = new GregorianCalendar(1998, 6, 30);
        final String dateStr = "02 942, 1996";
        final String[] parsers = {"MM DDD, yyyy"};

        final Date date = DateUtils.parseDate(dateStr, parsers);
        assertEquals(cal.getTime(), date);

        assertThrows(ParseException.class, () -> DateUtils.parseDateStrictly(dateStr, parsers));
    }

    /**
     * Tests various values with the round method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testRound() throws Exception {
        // tests for public static Date round(Date date, int field)
        assertEquals(dateParser.parse("January 1, 2002"), DateUtils.round(date1, Calendar.YEAR), "round year-1 failed");
        assertEquals(dateParser.parse("January 1, 2002"), DateUtils.round(date2, Calendar.YEAR), "round year-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"), DateUtils.round(date1, Calendar.MONTH), "round month-1 failed");
        assertEquals(dateParser.parse("December 1, 2001"), DateUtils.round(date2, Calendar.MONTH), "round month-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"), DateUtils.round(date0, DateUtils.SEMI_MONTH), "round semimonth-0 failed");
        assertEquals(dateParser.parse("February 16, 2002"), DateUtils.round(date1, DateUtils.SEMI_MONTH), "round semimonth-1 failed");
        assertEquals(dateParser.parse("November 16, 2001"), DateUtils.round(date2, DateUtils.SEMI_MONTH), "round semimonth-2 failed");

        assertEquals(dateParser.parse("February 13, 2002"), DateUtils.round(date1, Calendar.DATE), "round date-1 failed");
        assertEquals(dateParser.parse("November 18, 2001"), DateUtils.round(date2, Calendar.DATE), "round date-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 13:00:00.000"), DateUtils.round(date1, Calendar.HOUR), "round hour-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:00:00.000"), DateUtils.round(date2, Calendar.HOUR), "round hour-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:35:00.000"), DateUtils.round(date1, Calendar.MINUTE), "round minute-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:00.000"), DateUtils.round(date2, Calendar.MINUTE), "round minute-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:57.000"), DateUtils.round(date1, Calendar.SECOND), "round second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:11.000"), DateUtils.round(date2, Calendar.SECOND), "round second-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"), DateUtils.round(dateAmPm1, Calendar.AM_PM), "round ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"), DateUtils.round(dateAmPm2, Calendar.AM_PM), "round ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"), DateUtils.round(dateAmPm3, Calendar.AM_PM), "round ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"), DateUtils.round(dateAmPm4, Calendar.AM_PM), "round ampm-4 failed");

        // tests for public static Date round(Object date, int field)
        assertEquals(dateParser.parse("January 1, 2002"), DateUtils.round((Object) date1, Calendar.YEAR), "round year-1 failed");
        assertEquals(dateParser.parse("January 1, 2002"), DateUtils.round((Object) date2, Calendar.YEAR), "round year-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"), DateUtils.round((Object) date1, Calendar.MONTH), "round month-1 failed");
        assertEquals(dateParser.parse("December 1, 2001"), DateUtils.round((Object) date2, Calendar.MONTH), "round month-2 failed");
        assertEquals(dateParser.parse("February 16, 2002"), DateUtils.round((Object) date1, DateUtils.SEMI_MONTH), "round semimonth-1 failed");
        assertEquals(dateParser.parse("November 16, 2001"), DateUtils.round((Object) date2, DateUtils.SEMI_MONTH), "round semimonth-2 failed");
        assertEquals(dateParser.parse("February 13, 2002"), DateUtils.round((Object) date1, Calendar.DATE), "round date-1 failed");
        assertEquals(dateParser.parse("November 18, 2001"), DateUtils.round((Object) date2, Calendar.DATE), "round date-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 13:00:00.000"), DateUtils.round((Object) date1, Calendar.HOUR), "round hour-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:00:00.000"), DateUtils.round((Object) date2, Calendar.HOUR), "round hour-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:35:00.000"), DateUtils.round((Object) date1, Calendar.MINUTE), "round minute-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:00.000"), DateUtils.round((Object) date2, Calendar.MINUTE), "round minute-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:57.000"), DateUtils.round((Object) date1, Calendar.SECOND), "round second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:11.000"), DateUtils.round((Object) date2, Calendar.SECOND), "round second-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:57.000"), DateUtils.round((Object) cal1, Calendar.SECOND), "round calendar second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:11.000"), DateUtils.round((Object) cal2, Calendar.SECOND), "round calendar second-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"), DateUtils.round((Object) dateAmPm1, Calendar.AM_PM), "round ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"), DateUtils.round((Object) dateAmPm2, Calendar.AM_PM), "round ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"), DateUtils.round((Object) dateAmPm3, Calendar.AM_PM), "round ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"), DateUtils.round((Object) dateAmPm4, Calendar.AM_PM), "round ampm-4 failed");

        assertNullPointerException(() -> DateUtils.round((Date) null, Calendar.SECOND));
        assertNullPointerException(() -> DateUtils.round((Calendar) null, Calendar.SECOND));
        assertNullPointerException(() -> DateUtils.round((Object) null, Calendar.SECOND));
        assertThrows(ClassCastException.class, () -> DateUtils.round("", Calendar.SECOND));
        assertIllegalArgumentException(() -> DateUtils.round(date1, -9999));

        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"), DateUtils.round((Object) calAmPm1, Calendar.AM_PM), "round ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"), DateUtils.round((Object) calAmPm2, Calendar.AM_PM), "round ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"), DateUtils.round((Object) calAmPm3, Calendar.AM_PM), "round ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 4, 2002 00:00:00.000"), DateUtils.round((Object) calAmPm4, Calendar.AM_PM), "round ampm-4 failed");
    }

    /**
     * Tests various values with the round method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testRound_MET() throws Exception {
        // Fix for https://issues.apache.org/bugzilla/show_bug.cgi?id=25560 / LANG-13
        // Test rounding across the beginning of daylight saving time
        TimeZone.setDefault(TIME_ZONE_MET);
        dateTimeParser.setTimeZone(TIME_ZONE_MET);
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round(date4, Calendar.DATE), "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round((Object) cal4, Calendar.DATE),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round(date5, Calendar.DATE), "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round((Object) cal5, Calendar.DATE),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round(date6, Calendar.DATE), "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round((Object) cal6, Calendar.DATE),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round(date7, Calendar.DATE), "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.round((Object) cal7, Calendar.DATE),
                "round MET date across DST change-over");

        assertEquals(dateTimeParser.parse("March 30, 2003 01:00:00.000"), DateUtils.round(date4, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 01:00:00.000"), DateUtils.round((Object) cal4, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.round(date5, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.round((Object) cal5, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.round(date6, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 03:00:00.000"), DateUtils.round((Object) cal6, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 04:00:00.000"), DateUtils.round(date7, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 04:00:00.000"), DateUtils.round((Object) cal7, Calendar.HOUR_OF_DAY),
                "round MET date across DST change-over");
    }

    /**
     * Tests the Changes Made by LANG-346 to the DateUtils.modify() private method invoked
     * by DateUtils.round().
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testRoundLang346() throws Exception {
        final Calendar testCalendar = Calendar.getInstance();
        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 50);
        Date date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 08:09:00.000"),
                DateUtils.round(date, Calendar.MINUTE),
                "Minute Round Up Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 20);
        date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 08:08:00.000"),
                DateUtils.round(date, Calendar.MINUTE),
                "Minute No Round Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 50);
        testCalendar.set(Calendar.MILLISECOND, 600);
        date = testCalendar.getTime();

        assertEquals(dateTimeParser.parse("July 2, 2007 08:08:51.000"),
                DateUtils.round(date, Calendar.SECOND),
                "Second Round Up with 600 Milli Seconds Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 50);
        testCalendar.set(Calendar.MILLISECOND, 200);
        date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 08:08:50.000"),
                DateUtils.round(date, Calendar.SECOND),
                "Second Round Down with 200 Milli Seconds Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 20);
        testCalendar.set(Calendar.MILLISECOND, 600);
        date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 08:08:21.000"),
                DateUtils.round(date, Calendar.SECOND),
                "Second Round Up with 200 Milli Seconds Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 20);
        testCalendar.set(Calendar.MILLISECOND, 200);
        date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 08:08:20.000"),
                DateUtils.round(date, Calendar.SECOND),
                "Second Round Down with 200 Milli Seconds Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 8, 50);
        date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 08:00:00.000"),
                DateUtils.round(date, Calendar.HOUR),
                "Hour Round Down Failed");

        testCalendar.set(2007, Calendar.JULY, 2, 8, 31, 50);
        date = testCalendar.getTime();
        assertEquals(dateTimeParser.parse("July 2, 2007 09:00:00.000"),
                DateUtils.round(date, Calendar.HOUR),
                "Hour Round Up Failed");
    }

    @Test
    void testSetDays() throws Exception {
        Date result = DateUtils.setDays(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 1, 4, 3, 2, 1);
        result = DateUtils.setDays(BASE_DATE, 29);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 29, 4, 3, 2, 1);
        final String outsideOfRangeAssertionMessage = "DateUtils.setDays did not throw an expected IllegalArgumentException for amount outside of range 1 to 31.";
        assertIllegalArgumentException(() -> DateUtils.setDays(BASE_DATE, 32), outsideOfRangeAssertionMessage);
        assertIllegalArgumentException(() -> DateUtils.setDays(BASE_DATE, 0), outsideOfRangeAssertionMessage);
        assertNullPointerException(() -> DateUtils.setDays(null, 1));
    }

    @Test
    void testSetHours() throws Exception {
        Date result = DateUtils.setHours(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 0, 3, 2, 1);
        result = DateUtils.setHours(BASE_DATE, 23);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 23, 3, 2, 1);
        final String outsideOfRangeAssertionMessage = "DateUtils.setHours did not throw an expected IllegalArgumentException for amount outside of range 0 to 23.";
        assertIllegalArgumentException(() -> DateUtils.setHours(BASE_DATE, 24), outsideOfRangeAssertionMessage);
        assertIllegalArgumentException(() -> DateUtils.setHours(BASE_DATE, -1), outsideOfRangeAssertionMessage);
        assertNullPointerException(() -> DateUtils.setHours(null, 0));
    }

    @Test
    void testSetMilliseconds() throws Exception {
        Date result = DateUtils.setMilliseconds(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 0);
        result = DateUtils.setMilliseconds(BASE_DATE, 999);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 999);
        final String outsideOfRangeAssertionMessage = "DateUtils.setMilliseconds did not throw an expected IllegalArgumentException for range outside of 0 to 999.";
        assertIllegalArgumentException(() -> DateUtils.setMilliseconds(BASE_DATE, 1000), outsideOfRangeAssertionMessage);
        assertIllegalArgumentException(() -> DateUtils.setMilliseconds(BASE_DATE, -1), outsideOfRangeAssertionMessage);
        assertNullPointerException(() -> DateUtils.setMilliseconds(null, 0));
    }

    @Test
    void testSetMinutes() throws Exception {
        Date result = DateUtils.setMinutes(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 0, 2, 1);
        result = DateUtils.setMinutes(BASE_DATE, 59);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 59, 2, 1);
        final String outsideOfRangeAssertionMessage = "DateUtils.setMinutes did not throw an expected IllegalArgumentException for amount outside of range 0 to 59.";
        assertIllegalArgumentException(() -> DateUtils.setMinutes(BASE_DATE, 60), outsideOfRangeAssertionMessage);
        assertIllegalArgumentException(() -> DateUtils.setMinutes(BASE_DATE, -1), outsideOfRangeAssertionMessage);
        assertNullPointerException(() -> DateUtils.setMinutes(null, 0));
    }

    @Test
    void testSetMonths() throws Exception {
        Date result = DateUtils.setMonths(BASE_DATE, 5);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 5, 5, 4, 3, 2, 1);
        result = DateUtils.setMonths(BASE_DATE, 1);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 1, 5, 4, 3, 2, 1);
        result = DateUtils.setMonths(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 0, 5, 4, 3, 2, 1);
        final String outsideOfRangeAssertionMessage = "DateUtils.setMonths did not throw an expected IllegalArgumentException for amount outside of range 0 to 11.";
        assertIllegalArgumentException(() -> DateUtils.setMonths(BASE_DATE, 12), outsideOfRangeAssertionMessage);
        assertIllegalArgumentException(() -> DateUtils.setMonths(BASE_DATE, -1), outsideOfRangeAssertionMessage);
        assertNullPointerException(() -> DateUtils.setMonths(null, 0));
    }

    @Test
    void testSetSeconds() throws Exception {
        Date result = DateUtils.setSeconds(BASE_DATE, 0);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 0, 1);
        result = DateUtils.setSeconds(BASE_DATE, 59);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 59, 1);
        final String outsideOfRangeAssertionMessage = "DateUtils.setSeconds did not throw an expected IllegalArgumentException for amount outside of range 0 to 59.";
        assertIllegalArgumentException(() -> DateUtils.setSeconds(BASE_DATE, 60), outsideOfRangeAssertionMessage);
        assertIllegalArgumentException(() -> DateUtils.setSeconds(BASE_DATE, -1), outsideOfRangeAssertionMessage);
        assertNullPointerException(() -> DateUtils.setSeconds(null, 0));
    }

    @Test
    void testSetYears() throws Exception {
        Date result = DateUtils.setYears(BASE_DATE, 2000);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2000, 6, 5, 4, 3, 2, 1);

        result = DateUtils.setYears(BASE_DATE, 2008);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2008, 6, 5, 4, 3, 2, 1);

        result = DateUtils.setYears(BASE_DATE, 2005);
        assertNotSame(BASE_DATE, result);
        assertDate(BASE_DATE, 2000, 6, 5, 4, 3, 2, 1);
        assertDate(result, 2005, 6, 5, 4, 3, 2, 1);

        assertNullPointerException(() -> DateUtils.setYears(null, 0));
    }

    @Test
    void testToCalendar() {
        assertEquals(date1, DateUtils.toCalendar(date1).getTime(), "Failed to convert to a Calendar and back");
        assertEquals(MAX_DATE, DateUtils.toCalendar(MAX_DATE).getTime(), "Failed to convert to a Calendar and back");
        assertNullPointerException(() -> DateUtils.toCalendar(null));
    }

    @Test
    void testToCalendarWithDateAndTimeZoneNotNull() {
        final Calendar c = DateUtils.toCalendar(date2, TIME_ZONE_DEFAULT);
        assertEquals(date2, c.getTime(), "Convert Date and TimeZone to a Calendar, but failed to get the Date back");
        assertEquals(TIME_ZONE_DEFAULT, c.getTimeZone(), "Convert Date and TimeZone to a Calendar, but failed to get the TimeZone back");
    }

    @Test
    void testToCalendarWithDateAndTimeZoneNull() {
        assertNullPointerException(() -> DateUtils.toCalendar(null, null));
    }

    @Test
    void testToCalendarWithDateNull() {
        assertNullPointerException(() -> DateUtils.toCalendar(null, TIME_ZONE_MET));
    }

    @Test
    void testToCalendarWithTimeZoneNull() {
        assertNullPointerException(() -> DateUtils.toCalendar(date1, null));
    }

    @ParameterizedTest
    @MethodSource("testToLocalDateTimeTimeZone")
    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone(TimeZones.GMT_ID)
    void testToLocalDateTime(final LocalDateTime expected, final Date date, final TimeZone timeZone) {
        assertEquals(LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()), DateUtils.toLocalDateTime(date),
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
    }

    @ParameterizedTest
    @MethodSource("testToLocalDateTimeTimeZone")
    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone(TimeZones.GMT_ID)
    void testToLocalDateTimeTimeZone(final LocalDateTime expected, final Date date, final TimeZone timeZone) {
        assertEquals(expected, DateUtils.toLocalDateTime(date, timeZone),
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
    }

    @ParameterizedTest
    @MethodSource("testToLocalDateTimeTimeZone")
    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone(TimeZones.GMT_ID)
    void testToOffsetDateTime(final LocalDateTime expected, final Date date, final TimeZone timeZone) {
        final OffsetDateTime offsetDateTime = DateUtils.toOffsetDateTime(date);
        assertEquals(OffsetDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()), offsetDateTime,
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
    }

    @ParameterizedTest
    @MethodSource("testToLocalDateTimeTimeZone")
    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone(TimeZones.GMT_ID)
    void testToOffsetDateTimeTimeZone(final LocalDateTime expected, final Date date, final TimeZone timeZone) {
        assertEquals(expected, DateUtils.toOffsetDateTime(date, timeZone).toLocalDateTime(),
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
    }

    @ParameterizedTest
    @MethodSource("testToLocalDateTimeTimeZone")
    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone(TimeZones.GMT_ID)
    void testToZonedDateTime(final LocalDateTime expected, final Date date, final TimeZone timeZone) {
        final ZonedDateTime zonedDateTime = DateUtils.toZonedDateTime(date);
        assertEquals(ZonedDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault()), zonedDateTime,
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
        // Using atZone()
        assertEquals(date.toInstant().atZone(ZoneId.systemDefault()), zonedDateTime,
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
    }

    @ParameterizedTest
    @MethodSource("testToLocalDateTimeTimeZone")
    @DefaultLocale(language = "en", country = "US")
    @DefaultTimeZone(TimeZones.GMT_ID)
    void testToZonedDateTimeTimeZone(final LocalDateTime expected, final Date date, final TimeZone timeZone) {
        final ZonedDateTime zonedDateTime = DateUtils.toZonedDateTime(date, timeZone);
        assertEquals(expected, zonedDateTime.toOffsetDateTime().toLocalDateTime(),
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
        // Using atZone()
        assertEquals(date.toInstant().atZone(TimeZones.toTimeZone(timeZone).toZoneId()), zonedDateTime,
                () -> String.format("expected = %s, date = %s, timeZone = %s, TimeZone.getDefault() = %s", expected, date, timeZone, TimeZone.getDefault()));
    }

    /**
     * Tests various values with the trunc method.
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testTruncate() throws Exception {
        // tests public static Date truncate(Date date, int field)
        assertEquals(dateParser.parse("January 1, 2002"),
                DateUtils.truncate(date1, Calendar.YEAR),
                "truncate year-1 failed");
        assertEquals(dateParser.parse("January 1, 2001"),
                DateUtils.truncate(date2, Calendar.YEAR),
                "truncate year-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"),
                DateUtils.truncate(date1, Calendar.MONTH),
                "truncate month-1 failed");
        assertEquals(dateParser.parse("November 1, 2001"),
                DateUtils.truncate(date2, Calendar.MONTH),
                "truncate month-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"),
                DateUtils.truncate(date1, DateUtils.SEMI_MONTH),
                "truncate semimonth-1 failed");
        assertEquals(dateParser.parse("November 16, 2001"),
                DateUtils.truncate(date2, DateUtils.SEMI_MONTH),
                "truncate semimonth-2 failed");
        assertEquals(dateParser.parse("February 12, 2002"),
                DateUtils.truncate(date1, Calendar.DATE),
                "truncate date-1 failed");
        assertEquals(dateParser.parse("November 18, 2001"),
                DateUtils.truncate(date2, Calendar.DATE),
                "truncate date-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:00:00.000"),
                DateUtils.truncate(date1, Calendar.HOUR),
                "truncate hour-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:00:00.000"),
                DateUtils.truncate(date2, Calendar.HOUR),
                "truncate hour-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:00.000"),
                DateUtils.truncate(date1, Calendar.MINUTE),
                "truncate minute-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:00.000"),
                DateUtils.truncate(date2, Calendar.MINUTE),
                "truncate minute-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:56.000"),
                DateUtils.truncate(date1, Calendar.SECOND),
                "truncate second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:11.000"),
                DateUtils.truncate(date2, Calendar.SECOND),
                "truncate second-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"),
                DateUtils.truncate(dateAmPm1, Calendar.AM_PM),
                "truncate ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"),
                DateUtils.truncate(dateAmPm2, Calendar.AM_PM),
                "truncate ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.truncate(dateAmPm3, Calendar.AM_PM),
                "truncate ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.truncate(dateAmPm4, Calendar.AM_PM),
                "truncate ampm-4 failed");

        // tests public static Date truncate(Object date, int field)
        assertEquals(dateParser.parse("January 1, 2002"),
                DateUtils.truncate((Object) date1, Calendar.YEAR),
                "truncate year-1 failed");
        assertEquals(dateParser.parse("January 1, 2001"),
                DateUtils.truncate((Object) date2, Calendar.YEAR),
                "truncate year-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"),
                DateUtils.truncate((Object) date1, Calendar.MONTH),
                "truncate month-1 failed");
        assertEquals(dateParser.parse("November 1, 2001"),
                DateUtils.truncate((Object) date2, Calendar.MONTH),
                "truncate month-2 failed");
        assertEquals(dateParser.parse("February 1, 2002"),
                DateUtils.truncate((Object) date1, DateUtils.SEMI_MONTH),
                "truncate semimonth-1 failed");
        assertEquals(dateParser.parse("November 16, 2001"),
                DateUtils.truncate((Object) date2, DateUtils.SEMI_MONTH),
                "truncate semimonth-2 failed");
        assertEquals(dateParser.parse("February 12, 2002"),
                DateUtils.truncate((Object) date1, Calendar.DATE),
                "truncate date-1 failed");
        assertEquals(dateParser.parse("November 18, 2001"),
                DateUtils.truncate((Object) date2, Calendar.DATE),
                "truncate date-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:00:00.000"),
                DateUtils.truncate((Object) date1, Calendar.HOUR),
                "truncate hour-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:00:00.000"),
                DateUtils.truncate((Object) date2, Calendar.HOUR),
                "truncate hour-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:00.000"),
                DateUtils.truncate((Object) date1, Calendar.MINUTE),
                "truncate minute-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:00.000"),
                DateUtils.truncate((Object) date2, Calendar.MINUTE),
                "truncate minute-2 failed");
        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:56.000"),
                DateUtils.truncate((Object) date1, Calendar.SECOND),
                "truncate second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:11.000"),
                DateUtils.truncate((Object) date2, Calendar.SECOND),
                "truncate second-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"),
                DateUtils.truncate((Object) dateAmPm1, Calendar.AM_PM),
                "truncate ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"),
                DateUtils.truncate((Object) dateAmPm2, Calendar.AM_PM),
                "truncate ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.truncate((Object) dateAmPm3, Calendar.AM_PM),
                "truncate ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.truncate((Object) dateAmPm4, Calendar.AM_PM),
                "truncate ampm-4 failed");

        assertEquals(dateTimeParser.parse("February 12, 2002 12:34:56.000"),
                DateUtils.truncate((Object) cal1, Calendar.SECOND),
                "truncate calendar second-1 failed");
        assertEquals(dateTimeParser.parse("November 18, 2001 1:23:11.000"),
                DateUtils.truncate((Object) cal2, Calendar.SECOND),
                "truncate calendar second-2 failed");

        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"),
                DateUtils.truncate((Object) calAmPm1, Calendar.AM_PM),
                "truncate ampm-1 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 00:00:00.000"),
                DateUtils.truncate((Object) calAmPm2, Calendar.AM_PM),
                "truncate ampm-2 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.truncate((Object) calAmPm3, Calendar.AM_PM),
                "truncate ampm-3 failed");
        assertEquals(dateTimeParser.parse("February 3, 2002 12:00:00.000"),
                DateUtils.truncate((Object) calAmPm4, Calendar.AM_PM),
                "truncate ampm-4 failed");

        assertNullPointerException(() -> DateUtils.truncate((Date) null, Calendar.SECOND));
        assertNullPointerException(() -> DateUtils.truncate((Calendar) null, Calendar.SECOND));
        assertNullPointerException(() -> DateUtils.truncate((Object) null, Calendar.SECOND));
        assertThrows(ClassCastException.class, () -> DateUtils.truncate("", Calendar.SECOND));

    }

    /**
     * Tests various values with the trunc method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testTruncate_Bugzilla_25560() throws Exception {
        // Fix for https://issues.apache.org/bugzilla/show_bug.cgi?id=25560
        // Test truncate across beginning of daylight saving time
        TimeZone.setDefault(TIME_ZONE_MET);
        dateTimeParser.setTimeZone(TIME_ZONE_MET);
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.truncate(date3, Calendar.DATE), "truncate MET date across DST change-over");
        assertEquals(dateTimeParser.parse("March 30, 2003 00:00:00.000"), DateUtils.truncate((Object) cal3, Calendar.DATE),
                "truncate MET date across DST change-over");
        // Test truncate across end of daylight saving time
        assertEquals(dateTimeParser.parse("October 26, 2003 00:00:00.000"), DateUtils.truncate(date8, Calendar.DATE),
                "truncate MET date across DST change-over");
        assertEquals(dateTimeParser.parse("October 26, 2003 00:00:00.000"), DateUtils.truncate((Object) cal8, Calendar.DATE),
                "truncate MET date across DST change-over");
    }

    /**
     * Tests various values with the trunc method
     *
     * @throws Exception Thrown if an operation in the test fails.
     */
    @Test
    void testTruncate_Bugzilla_31395() throws Exception {
        // Bug 31395, large dates
        final Date endOfTime = MAX_DATE; // fyi: Sun Aug 17 07:12:55 CET 292278994 -- 807 millis
        final GregorianCalendar endCal = new GregorianCalendar();
        endCal.setTime(endOfTime);
        assertThrows(ArithmeticException.class, () -> DateUtils.truncate(endCal, Calendar.DATE));
        endCal.set(Calendar.YEAR, 280000001);
        assertThrows(ArithmeticException.class, () -> DateUtils.truncate(endCal, Calendar.DATE));
        endCal.set(Calendar.YEAR, 280000000);
        final Calendar cal = DateUtils.truncate(endCal, Calendar.DATE);
        assertEquals(0, cal.get(Calendar.HOUR));
    }

    @Test
    public void testTruncatedCompareToCalendar() {
        final Calendar cal1 = Calendar.getInstance();
        cal1.set(2026, Calendar.JULY, 26, 10, 0, 0);
        final Calendar cal2 = Calendar.getInstance();
        cal2.set(2026, Calendar.JULY, 26, 14, 0, 0);

        assertEquals(0, DateUtils.truncatedCompareTo(cal1, cal2, Calendar.DAY_OF_MONTH));
        assertTrue(DateUtils.truncatedCompareTo(cal1, cal2, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(cal2, cal1, Calendar.HOUR_OF_DAY) > 0);

        assertThrows(NullPointerException.class, () -> DateUtils.truncatedCompareTo(null, cal2, Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedCompareTo(cal1, null, Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testTruncatedCompareToDate() {
        final Calendar cal1 = Calendar.getInstance();
        cal1.set(2026, Calendar.JULY, 26, 10, 0, 0);
        final Calendar cal2 = Calendar.getInstance();
        cal2.set(2026, Calendar.JULY, 26, 14, 0, 0);

        final Date date1 = cal1.getTime();
        final Date date2 = cal2.getTime();

        assertEquals(0, DateUtils.truncatedCompareTo(date1, date2, Calendar.DAY_OF_MONTH));

        assertTrue(DateUtils.truncatedCompareTo(date1, date2, Calendar.HOUR_OF_DAY) < 0);
        assertTrue(DateUtils.truncatedCompareTo(date2, date1, Calendar.HOUR_OF_DAY) > 0);

        assertThrows(NullPointerException.class, () -> DateUtils.truncatedCompareTo(null, date2, Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedCompareTo(date1, null, Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testTruncatedEqualCalendar() {
        final Calendar cal1 = Calendar.getInstance();
        cal1.set(2026, Calendar.JULY, 26, 10, 0, 0);
        final Calendar cal2 = Calendar.getInstance();
        cal2.set(2026, Calendar.JULY, 26, 14, 0, 0);

        assertTrue(DateUtils.truncatedEquals(cal1, cal2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(cal1, cal2, Calendar.HOUR_OF_DAY));

        assertThrows(NullPointerException.class, () -> DateUtils.truncatedEquals(null, cal2, Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedEquals(cal1, null, Calendar.DAY_OF_MONTH));
    }

    @Test
    public void testTruncatedEqualDate() {
        final Calendar cal1 = Calendar.getInstance();
        cal1.set(2026, Calendar.JULY, 26, 10, 0, 0);
        final Calendar cal2 = Calendar.getInstance();
        cal2.set(2026, Calendar.JULY, 26, 14, 0, 0);

        final Date date1 = cal1.getTime();
        final Date date2 = cal2.getTime();

        assertTrue(DateUtils.truncatedEquals(date1, date2, Calendar.DAY_OF_MONTH));
        assertFalse(DateUtils.truncatedEquals(date1, date2, Calendar.HOUR_OF_DAY));

        assertThrows(NullPointerException.class, () -> DateUtils.truncatedEquals(null, date2, Calendar.DAY_OF_MONTH));
        assertThrows(NullPointerException.class, () -> DateUtils.truncatedEquals(date1, null, Calendar.DAY_OF_MONTH));
    }

    /**
     * Tests for LANG-59
     *
     * see https://issues.apache.org/jira/browse/LANG-59
     */
    @Test
    void testTruncateLang59() {
        // Set TimeZone to Mountain Time
        final TimeZone denverZone = TimeZones.getTimeZone("America/Denver");
        TimeZone.setDefault(denverZone);
        final DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS XXX");
        format.setTimeZone(denverZone);
        final Date oct31_01MDT = new Date(1099206000000L);
        final Date oct31MDT = new Date(oct31_01MDT.getTime() - 3600000L); // - 1 hour
        final Date oct31_01_02MDT = new Date(oct31_01MDT.getTime() + 120000L); // + 2 minutes
        final Date oct31_01_02_03MDT = new Date(oct31_01_02MDT.getTime() + 3000L); // + 3 seconds
        final Date oct31_01_02_03_04MDT = new Date(oct31_01_02_03MDT.getTime() + 4L); // + 4 milliseconds
        assertEquals("2004-10-31 00:00:00.000 -06:00", format.format(oct31MDT), "Check 00:00:00.000");
        assertEquals("2004-10-31 01:00:00.000 -06:00", format.format(oct31_01MDT), "Check 01:00:00.000");
        assertEquals("2004-10-31 01:02:00.000 -06:00", format.format(oct31_01_02MDT), "Check 01:02:00.000");
        assertEquals("2004-10-31 01:02:03.000 -06:00", format.format(oct31_01_02_03MDT), "Check 01:02:03.000");
        assertEquals("2004-10-31 01:02:03.004 -06:00", format.format(oct31_01_02_03_04MDT), "Check 01:02:03.004");
        // Demonstrate Problem
        final Calendar gval = Calendar.getInstance();
        gval.setTime(new Date(oct31_01MDT.getTime()));
        gval.set(Calendar.MINUTE, gval.get(Calendar.MINUTE)); // set minutes to the same value
        assertEquals(gval.getTime().getTime(), oct31_01MDT.getTime() + 3600000L, "Demonstrate Problem");
        // Test Truncate
        assertEquals(oct31_01_02_03_04MDT, DateUtils.truncate(oct31_01_02_03_04MDT, Calendar.MILLISECOND), "Truncate Calendar.MILLISECOND");
        assertEquals(oct31_01_02_03MDT, DateUtils.truncate(oct31_01_02_03_04MDT, Calendar.SECOND), "Truncate Calendar.SECOND");
        assertEquals(oct31_01_02MDT, DateUtils.truncate(oct31_01_02_03_04MDT, Calendar.MINUTE), "Truncate Calendar.MINUTE");
        assertEquals(oct31_01MDT, DateUtils.truncate(oct31_01_02_03_04MDT, Calendar.HOUR_OF_DAY), "Truncate Calendar.HOUR_OF_DAY");
        assertEquals(oct31_01MDT, DateUtils.truncate(oct31_01_02_03_04MDT, Calendar.HOUR), "Truncate Calendar.HOUR");
        assertEquals(oct31MDT, DateUtils.truncate(oct31_01_02_03_04MDT, Calendar.DATE), "Truncate Calendar.DATE");
        // Test Round (down)
        assertEquals(oct31_01_02_03_04MDT, DateUtils.round(oct31_01_02_03_04MDT, Calendar.MILLISECOND), "Round Calendar.MILLISECOND");
        assertEquals(oct31_01_02_03MDT, DateUtils.round(oct31_01_02_03_04MDT, Calendar.SECOND), "Round Calendar.SECOND");
        assertEquals(oct31_01_02MDT, DateUtils.round(oct31_01_02_03_04MDT, Calendar.MINUTE), "Round Calendar.MINUTE");
        assertEquals(oct31_01MDT, DateUtils.round(oct31_01_02_03_04MDT, Calendar.HOUR_OF_DAY), "Round Calendar.HOUR_OF_DAY");
        assertEquals(oct31_01MDT, DateUtils.round(oct31_01_02_03_04MDT, Calendar.HOUR), "Round Calendar.HOUR");
        assertEquals(oct31MDT, DateUtils.round(oct31_01_02_03_04MDT, Calendar.DATE), "Round Calendar.DATE");
    }

    /**
     * Tests the calendar iterator for week ranges
     */
    @Test
    void testWeekIterator() {
        final Calendar now = Calendar.getInstance();
        for (int i = 0; i < 7; i++) {
            final Calendar today = DateUtils.truncate(now, Calendar.DATE);
            final Calendar sunday = DateUtils.truncate(now, Calendar.DATE);
            sunday.add(Calendar.DATE, 1 - sunday.get(Calendar.DAY_OF_WEEK));
            final Calendar monday = DateUtils.truncate(now, Calendar.DATE);
            if (monday.get(Calendar.DAY_OF_WEEK) == 1) {
                // This is sunday... roll back 6 days
                monday.add(Calendar.DATE, -6);
            } else {
                monday.add(Calendar.DATE, 2 - monday.get(Calendar.DAY_OF_WEEK));
            }
            final Calendar centered = DateUtils.truncate(now, Calendar.DATE);
            centered.add(Calendar.DATE, -3);

            Iterator<?> it = DateUtils.iterator(now, DateUtils.RANGE_WEEK_SUNDAY);
            assertWeekIterator(it, sunday);
            it = DateUtils.iterator(now, DateUtils.RANGE_WEEK_MONDAY);
            assertWeekIterator(it, monday);
            it = DateUtils.iterator(now, DateUtils.RANGE_WEEK_RELATIVE);
            assertWeekIterator(it, today);
            it = DateUtils.iterator(now, DateUtils.RANGE_WEEK_CENTER);
            assertWeekIterator(it, centered);

            it = DateUtils.iterator((Object) now, DateUtils.RANGE_WEEK_CENTER);
            assertWeekIterator(it, centered);
            final Iterator<?> it2 = DateUtils.iterator((Object) now.getTime(), DateUtils.RANGE_WEEK_CENTER);
            assertWeekIterator(it2, centered);
            assertThrows(NoSuchElementException.class, it2::next);
            final Iterator<?> it3 = DateUtils.iterator(now, DateUtils.RANGE_WEEK_CENTER);
            it3.next();
            assertThrows(UnsupportedOperationException.class, it3::remove);

            now.add(Calendar.DATE, 1);
        }
    }
}

