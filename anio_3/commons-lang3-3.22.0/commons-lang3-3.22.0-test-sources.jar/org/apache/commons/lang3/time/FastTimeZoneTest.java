/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.time;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.TimeZone;

import org.apache.commons.lang3.AbstractLangTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Tests {@link FastTimeZone}.
 */
class FastTimeZoneTest extends AbstractLangTest {

    private static final int HOURS_2 = 2 * 60 * 60 * 1000;
    private static final int HOURS_23 = 23 * 60 * 60 * 1000;
    private static final int MINUTES_5 = 5 * 60 * 1000;
    private static final int MINUTES_59 = 59 * 60 * 1000;

    @Test
    void testBareGmt() {
        assertEquals(FastTimeZone.getGmtTimeZone(), FastTimeZone.getTimeZone(TimeZones.GMT_ID));
    }

    @Test
    void testEmptyStringReturnsNonNullDespiteJavadoc() {
        // Javadoc claims null when pattern does not match. Empty string matches
        // the over-permissive regex and returns the GMT zone instead.
        final TimeZone tz = FastTimeZone.getGmtTimeZone("");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    void testGetGmtTimeZone() {
        assertEquals(0, FastTimeZone.getGmtTimeZone().getRawOffset());
    }

    @Test
    void testGmtOnlyReturnsNonNull() {
        // The literal "GMT" prefix on its own matches; both digit groups absent.
        final TimeZone tz = FastTimeZone.getGmtTimeZone("GMT");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    void testGmtPrefix() {
        assertEquals(HOURS_23, FastTimeZone.getGmtTimeZone("GMT+23:00").getRawOffset());
        assertEquals(-HOURS_23, FastTimeZone.getGmtTimeZone("GMT-23:00").getRawOffset());
    }

    @Test
    void testHoursColonMinutes() {
        assertEquals(HOURS_23, FastTimeZone.getGmtTimeZone("23:00").getRawOffset());
        assertEquals(HOURS_2, FastTimeZone.getGmtTimeZone("2:00").getRawOffset());
        assertEquals(MINUTES_59, FastTimeZone.getGmtTimeZone("00:59").getRawOffset());
        assertEquals(MINUTES_5, FastTimeZone.getGmtTimeZone("00:5").getRawOffset());
        assertEquals(HOURS_23 + MINUTES_59, FastTimeZone.getGmtTimeZone("23:59").getRawOffset());
        assertEquals(HOURS_2 + MINUTES_5, FastTimeZone.getGmtTimeZone("2:5").getRawOffset());
    }

    @Test
    void testHoursMinutes() {
        assertEquals(HOURS_23, FastTimeZone.getGmtTimeZone("2300").getRawOffset());
        assertEquals(HOURS_2, FastTimeZone.getGmtTimeZone("0200").getRawOffset());
        assertEquals(MINUTES_59, FastTimeZone.getGmtTimeZone("0059").getRawOffset());
        assertEquals(MINUTES_5, FastTimeZone.getGmtTimeZone("0005").getRawOffset());
        assertEquals(HOURS_23 + MINUTES_59, FastTimeZone.getGmtTimeZone("2359").getRawOffset());
        assertEquals(HOURS_2 + MINUTES_5, FastTimeZone.getGmtTimeZone("0205").getRawOffset());
    }

    @Test
    void testInvalidStringReturnsNull() {
        // Negative control: a string that genuinely cannot match the regex returns null.
        assertNull(FastTimeZone.getGmtTimeZone("XYZ"), "non-matching input returns null");
    }

    /**
     * Patched-source check. After the doc-only patch lands, the Javadoc on {@code getGmtTimeZone(String)} no longer promises "null if pattern does not match"
     * for the empty / sign-only / GMT-only inputs. We string-search the source file for the corrected wording so reverting the Javadoc (mutation control) flips
     * this assertion to FAIL.
     */
    @Test
    void testJavadocReflectsLenientBehavior() throws Exception {
        final Path src = Paths.get("src/main/java/org/apache/commons/lang3/time/FastTimeZone.java");
        final String body = new String(Files.readAllBytes(src), StandardCharsets.UTF_8);
        assertTrue(body.contains("defaulting to GMT for an unrecognized but parseable input"));
    }

    @Test
    void testOlson() {
        assertEquals(TimeZones.getTimeZone("America/New_York"), FastTimeZone.getTimeZone("America/New_York"));
    }

    /**
     * A pattern that matches the regex but whose hours or minutes are out of range is not a valid GMT id. Before the fix these threw IllegalArgumentException
     * from the GmtTimeZone constructor.
     */
    @ParameterizedTest
    @ValueSource(strings = { "GMT+24", "+24", "-24", "+99", "+12:60", "00:99", "99:99", "0099", "9999" })
    void testOutOfRangeOffsetReturnsNull(final String pattern) {
        assertNull(FastTimeZone.getGmtTimeZone(pattern));
    }

    @Test
    void testOutOfRangeOffsetViaGetTimeZoneFallsBack() {
        // getTimeZone must not propagate the constructor exception; a null GMT result falls back to the JDK lookup.
        final TimeZone tz = FastTimeZone.getTimeZone("GMT+24");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    void testPlusOnlyReturnsNonNull() {
        // Sign-only input still matches the regex; hours and minutes default to 0.
        final TimeZone tz = FastTimeZone.getGmtTimeZone("+");
        assertNotNull(tz);
        assertEquals(0, tz.getRawOffset());
    }

    @Test
    void testSign() {
        assertEquals(HOURS_23, FastTimeZone.getGmtTimeZone("+23:00").getRawOffset());
        assertEquals(HOURS_2, FastTimeZone.getGmtTimeZone("+2:00").getRawOffset());
        assertEquals(-HOURS_23, FastTimeZone.getGmtTimeZone("-23:00").getRawOffset());
        assertEquals(-HOURS_2, FastTimeZone.getGmtTimeZone("-2:00").getRawOffset());
    }

    @Test
    void testUTC() {
        assertEquals(FastTimeZone.getGmtTimeZone(), FastTimeZone.getTimeZone("UTC"));
    }

    @Test
    void testZ() {
        assertEquals(FastTimeZone.getGmtTimeZone(), FastTimeZone.getTimeZone("Z"));
    }

    @Test
    void testZeroOffsetsReturnSingleton() {
        assertEquals(FastTimeZone.getGmtTimeZone(), FastTimeZone.getTimeZone("+0"));
        assertEquals(FastTimeZone.getGmtTimeZone(), FastTimeZone.getTimeZone("-0"));
    }
}
