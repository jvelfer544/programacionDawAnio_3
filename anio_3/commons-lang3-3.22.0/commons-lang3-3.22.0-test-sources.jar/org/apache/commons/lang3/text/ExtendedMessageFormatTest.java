/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.text;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrowsExactly;

import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.AbstractLangTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junitpioneer.jupiter.cartesian.ArgumentSets;
import org.junitpioneer.jupiter.cartesian.CartesianTest;

/**
 * Test case for {@link ExtendedMessageFormat}.
 */
@Deprecated
class ExtendedMessageFormatTest extends AbstractLangTest {

    /**
     * {@link Format} implementation which converts to lower case.
     */
    private static final class LowerCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(((String) obj).toLowerCase(Locale.ROOT));
        }
        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * {@link FormatFactory} implementation for lower case format.
     */
    private static final class LowerCaseFormatFactory implements FormatFactory {
        private static final Format LOWER_INSTANCE = new LowerCaseFormat();

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return LOWER_INSTANCE;
        }
    }

    /**
     * Alternative ExtendedMessageFormat impl.
     */
    private static final class OtherExtendedMessageFormat extends ExtendedMessageFormat {
        private static final long serialVersionUID = 1L;

        OtherExtendedMessageFormat(final String pattern, final Locale locale,
                final Map<String, ? extends FormatFactory> registry) {
            super(pattern, locale, registry);
        }

    }

    /**
     * {@link FormatFactory} implementation to override date format "short" to "default".
     */
    private static final class OverrideShortDateFormatFactory implements FormatFactory {

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return !"short".equals(arguments) ? null
                    : locale == null ? DateFormat
                            .getDateInstance(DateFormat.DEFAULT) : DateFormat
                            .getDateInstance(DateFormat.DEFAULT, locale);
        }
    }

    /**
     * {@link Format} implementation which converts to upper case.
     */
    private static final class UpperCaseFormat extends Format {
        private static final long serialVersionUID = 1L;

        @Override
        public StringBuffer format(final Object obj, final StringBuffer toAppendTo, final FieldPosition pos) {
            return toAppendTo.append(((String) obj).toUpperCase(Locale.ROOT));
        }

        @Override
        public Object parseObject(final String source, final ParsePosition pos) {
            throw new UnsupportedOperationException();
        }
    }

    /**
     * {@link FormatFactory} implementation for upper case format.
     */
    private static final class UpperCaseFormatFactory implements FormatFactory {
        private static final Format UPPER_INSTANCE = new UpperCaseFormat();

        @Override
        public Format getFormat(final String name, final String arguments, final Locale locale) {
            return UPPER_INSTANCE;
        }
    }

    static ArgumentSets testBuiltInChoiceFormatFactory() {
        // @formatter:off
        return ArgumentSets
                .argumentsForFirstParameter(Integer.valueOf(1), Double.valueOf("2.2"), Double.valueOf("1234.5"))
                .argumentsForNextParameter(DateFormat.getAvailableLocales());
        // @formatter:on
    }

//    /**
//     * Test extended formats with choice format.
//     *
//     * NOTE: FAILING - currently sub-formats not supported
//     */
//    void testExtendedWithChoiceFormat() {
//        String pattern = "Choice: {0,choice,1.0#{1,lower}|2.0#{1,upper}}";
//        ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
//        assertPatterns(null, pattern, emf.toPattern());
//        try {
//            assertEquals("one", emf.format(new Object[] {Integer.valueOf(1), "ONE"}));
//            assertEquals("TWO", emf.format(new Object[] {Integer.valueOf(2), "two"}));
//        } catch (IllegalArgumentException e) {
//            // currently sub-formats not supported
//        }
//    }

//    /**
//     * Test mixed extended and built-in formats with choice format.
//     *
//     * NOTE: FAILING - currently sub-formats not supported
//     */
//    void testExtendedAndBuiltInWithChoiceFormat() {
//        String pattern = "Choice: {0,choice,1.0#{0} {1,lower} {2,number}|2.0#{0} {1,upper} {2,number,currency}}";
//        Object[] lowArgs  = new Object[] {Integer.valueOf(1), "Low",  Double.valueOf("1234.56")};
//        Object[] highArgs = new Object[] {Integer.valueOf(2), "High", Double.valueOf("9876.54")};
//        Locale[] availableLocales = ChoiceFormat.getAvailableLocales();
//        Locale[] testLocales = new Locale[availableLocales.length + 1];
//        testLocales[0] = null;
//        System.arraycopy(availableLocales, 0, testLocales, 1, availableLocales.length);
//        for (int i = 0; i < testLocales.length; i++) {
//            NumberFormat nf = null;
//            NumberFormat cf = null;
//            ExtendedMessageFormat emf = null;
//            if (testLocales[i] == null) {
//                nf = NumberFormat.getNumberInstance();
//                cf = NumberFormat.getCurrencyInstance();
//                emf = new ExtendedMessageFormat(pattern, registry);
//            } else {
//                nf = NumberFormat.getNumberInstance(testLocales[i]);
//                cf = NumberFormat.getCurrencyInstance(testLocales[i]);
//                emf = new ExtendedMessageFormat(pattern, testLocales[i], registry);
//            }
//            assertPatterns(null, pattern, emf.toPattern());
//            try {
//                String lowExpected = lowArgs[0] + " low "    + nf.format(lowArgs[2]);
//                String highExpected = highArgs[0] + " HIGH "  + cf.format(highArgs[2]);
//                assertEquals(lowExpected,  emf.format(lowArgs));
//                assertEquals(highExpected, emf.format(highArgs));
//            } catch (IllegalArgumentException e) {
//                // currently sub-formats not supported
//            }
//        }
//    }

    static ArgumentSets testBuiltInDateTimeFormatFactory() {
        // @formatter:off
        return ArgumentSets
                .argumentsForFirstParameter(
                        "1: {0,date,short}",
                        "2: {0,date,medium}",
                        "3: {0,date,long}",
                        "4: {0,date,full}",
                        "5: {0,date,d MMM yy}",
                        "6: {0,time,short}",
                        "7: {0,time,medium}",
                        "8: {0,time,long}",
                        "9: {0,time,full}",
                        "10: {0,time,HH:mm}",
                        "11: {0,date}", "12: {0,time}")
                .argumentsForNextParameter(DateFormat.getAvailableLocales());
        // @formatter:on
    }

    static ArgumentSets testBuiltInNumberFormatFactory() {
        // @formatter:off
        return ArgumentSets
                .argumentsForFirstParameter(
                        "1: {0,number}",
                        "2: {0,number,integer}",
                        "3: {0,number,currency}",
                        "4: {0,number,percent}",
                        "5: {0,number,00000.000}")
                .argumentsForNextParameter(DateFormat.getAvailableLocales());
        // @formatter:on
    }

    static ArgumentSets testOverriddenBuiltinFormatFactory() {
        // @formatter:off
        return ArgumentSets
                .argumentsForFirstParameter(
                        "1: {0,date}",
                        "2: {0,date,medium}",
                        "3: {0,date,long}",
                        "4: {0,date,full}",
                        "5: {0,date,d MMM yy}")
                .argumentsForNextParameter(DateFormat.getAvailableLocales());
        // @formatter:on
    }

    private final Map<String, FormatFactory> registry = new HashMap<>();

    /**
     * Create an ExtendedMessageFormat for the specified pattern and locale and check the
     * formatted output matches the expected result for the parameters.
     * @param pattern string
     * @param registryUnused map (currently unused)
     * @param args Object[]
     * @param locale Locale
     */
    private void checkBuiltInFormat(final String pattern, final Map<String, ?> registryUnused, final Object[] args, final Locale locale) {
        final StringBuilder buffer = new StringBuilder();
        buffer.append("Pattern=[");
        buffer.append(pattern);
        buffer.append("], locale=[");
        buffer.append(locale);
        buffer.append("]");
        final MessageFormat mf = createMessageFormat(pattern, locale);
        final ExtendedMessageFormat emf;
        if (locale == null) {
            emf = new ExtendedMessageFormat(pattern);
        } else {
            emf = new ExtendedMessageFormat(pattern, locale);
        }
        assertEquals(mf.format(args), emf.format(args), "format "    + buffer);
        assertEquals(mf.toPattern(), emf.toPattern(), "toPattern " + buffer);
    }

    /**
     * Replace MessageFormat(String, Locale) constructor (not available until JDK 1.4).
     * @param pattern string
     * @param locale Locale
     * @return MessageFormat
     */
    private MessageFormat createMessageFormat(final String pattern, final Locale locale) {
        final MessageFormat result = new MessageFormat(pattern);
        if (locale != null) {
            result.setLocale(locale);
            result.applyPattern(pattern);
        }
        return result;
    }

    @BeforeEach
    public void setUp() {
        registry.put("lower", new LowerCaseFormatFactory());
        registry.put("upper", new UpperCaseFormatFactory());
    }

    @Test
    void testArgumentIndexTrailingWhitespaceAtEnd() {
        assertThrowsExactly(IllegalArgumentException.class, () -> new ExtendedMessageFormat("{0 ", new HashMap<>()));
    }

    /**
     * Test the built-in choice format.
     */
    @CartesianTest
    @CartesianTest.MethodFactory("testBuiltInChoiceFormatFactory")
    void testBuiltInChoiceFormat(final Object value, final Locale locale) {
        String choicePattern;
        choicePattern = "{0,choice,1#One|2#Two|3#Many {0,number}}";
        checkBuiltInFormat(value + ": " + choicePattern, null, new Object[] { value }, (Locale) null);
        checkBuiltInFormat(value + ": " + choicePattern, null, new Object[] { value }, locale);
        //
        choicePattern = "{0,choice,1#''One''|2#\"Two\"|3#''{Many}'' {0,number}}";
        checkBuiltInFormat(value + ": " + choicePattern, null, new Object[] { value }, (Locale) null);
        checkBuiltInFormat(value + ": " + choicePattern, null, new Object[] { value }, locale);
    }

    /**
     * Test the built-in date/time formats
     */
    @CartesianTest
    @CartesianTest.MethodFactory("testBuiltInDateTimeFormatFactory")
    void testBuiltInDateTimeFormat(final String pattern, final Locale locale) {
        final Calendar cal = Calendar.getInstance();
        cal.set(2007, Calendar.JANUARY, 23, 18, 33, 5);
        final Object[] args = { cal.getTime() };
        checkBuiltInFormat(pattern, null, args, (Locale) null);
        checkBuiltInFormat(pattern, null, args, locale);
    }

    /**
     * Test the built-in number formats.
     */
    @CartesianTest
    @CartesianTest.MethodFactory("testBuiltInNumberFormatFactory")
    void testBuiltInNumberFormat(final String pattern, final Locale locale) {
        final Object[] args = { Double.valueOf("6543.21") };
        checkBuiltInFormat(pattern, null, args, (Locale) null);
        checkBuiltInFormat(pattern, null, args, locale);
    }

    /**
     * Test Bug LANG-917 - IndexOutOfBoundsException and/or infinite loop when using a choice pattern
     */
    @Test
    void testEmbeddedPatternInChoice() {
        final String pattern = "Hi {0,lower}, got {1,choice,0#none|1#one|1<{1,number}}, {2,upper}!";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals(emf.format(new Object[] {"there", 3, "great"}), "Hi there, got 3, GREAT!");
    }

    /**
     * Test equals() and hashCode().
     */
    @Test
    void testEqualsHashcode() {
        final Map<String, ? extends FormatFactory> fmtRegistry = Collections.singletonMap("testfmt", new LowerCaseFormatFactory());
        final Map<String, ? extends FormatFactory> otherRegistry = Collections.singletonMap("testfmt", new UpperCaseFormatFactory());

        final String pattern = "Pattern: {0,testfmt}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, Locale.US, fmtRegistry);

        ExtendedMessageFormat other;

        // Same object
        assertEquals(emf, emf, "same, equals()");
        assertEquals(emf.hashCode(), emf.hashCode(), "same, hashCode()");

        // Equal Object
        other = new ExtendedMessageFormat(pattern, Locale.US, fmtRegistry);
        assertEquals(emf, other, "equal, equals()");
        assertEquals(emf.hashCode(), other.hashCode(), "equal, hashCode()");

        // Different Class
        other = new OtherExtendedMessageFormat(pattern, Locale.US, fmtRegistry);
        assertNotEquals(emf, other, "class, equals()");
        assertEquals(emf.hashCode(), other.hashCode(), "class, hashCode()"); // same hash code

        // Different pattern
        other = new ExtendedMessageFormat("X" + pattern, Locale.US, fmtRegistry);
        assertNotEquals(emf, other, "pattern, equals()");
        assertNotEquals(emf.hashCode(), other.hashCode(), "pattern, hashCode()");

        // Different registry
        other = new ExtendedMessageFormat(pattern, Locale.US, otherRegistry);
        assertNotEquals(emf, other, "registry, equals()");
        assertNotEquals(emf.hashCode(), other.hashCode(), "registry, hashCode()");

        // Different Locale
        other = new ExtendedMessageFormat(pattern, Locale.FRANCE, fmtRegistry);
        assertNotEquals(emf, other, "locale, equals()");
        assertEquals(emf.hashCode(), other.hashCode(), "locale, hashCode()"); // same hash code
    }

    /**
     * Test Bug LANG-948 - Exception while using ExtendedMessageFormat and escaping braces
     */
    @Test
    void testEscapedBraces_LANG_948() {
        // message without placeholder because braces are escaped by quotes
        final String pattern = "Message without placeholders '{}'";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals("Message without placeholders {}", emf.format(new Object[] {"DUMMY"}));

        // message with placeholder because quotes are escaped by quotes
        final String pattern2 = "Message with placeholder ''{0}''";
        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat(pattern2, registry);
        assertEquals("Message with placeholder 'DUMMY'", emf2.format(new Object[] {"DUMMY"}));
    }

    /**
     * Test Bug LANG-477 - out of memory error with escaped quote
     */
    @Test
    void testEscapedQuote_LANG_477() {
        final String pattern = "it''s a {0,lower} 'test'!";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals("it's a dummy test!", emf.format(new Object[] {"DUMMY"}));
    }

    /**
     * Test extended and built-in formats with available locales.
     */
    @Test
    void testExtendedAndBuiltInFormatsWithAvailableLocales() {
        final String extendedPattern = "Name: {0,upper} ";
        final String builtinsPattern = "DOB: {1,date,short} Salary: {2,number,currency}";
        final String pattern = extendedPattern + builtinsPattern;

        final Calendar cal = Calendar.getInstance();
        cal.set(2007, Calendar.JANUARY, 23, 18, 33, 5);
        final Object[] args = {"John Doe", cal.getTime(), Double.valueOf("12345.67")};

        final HashSet<Locale> testLocales = new HashSet<>(Arrays.asList(DateFormat.getAvailableLocales()));
        testLocales.retainAll(Arrays.asList(NumberFormat.getAvailableLocales()));

        for (final Locale locale : testLocales) {
            final MessageFormat builtins = createMessageFormat(builtinsPattern, locale);
            final String expectedPattern = extendedPattern + builtins.toPattern();
            final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, locale, registry);
            assertEquals(expectedPattern, emf.toPattern(), "pattern comparison for locale " + locale);

            final DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, locale);
            final NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
            final StringBuilder expected = new StringBuilder();
            expected.append("Name: ");
            expected.append(args[0].toString().toUpperCase(locale));
            expected.append(" DOB: ");
            expected.append(df.format(args[1]));
            expected.append(" Salary: ");
            expected.append(nf.format(args[2]));
            assertEquals(expected.toString(), emf.format(args), String.valueOf(locale));
        }
    }

    /**
     * Test extended and built-in formats with the default locale.
     */
    @Test
    void testExtendedAndBuiltInFormatsWithDefaultLocale() {
        final String extendedPattern = "Name: {0,upper} ";
        final String builtinsPattern = "DOB: {1,date,short} Salary: {2,number,currency}";
        final String pattern = extendedPattern + builtinsPattern;

        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        final MessageFormat builtins = createMessageFormat(builtinsPattern, null);
        final String expectedPattern = extendedPattern + builtins.toPattern();
        assertEquals(expectedPattern, emf.toPattern(), "pattern comparison for default locale");

        final Calendar cal = Calendar.getInstance();
        cal.set(2007, Calendar.JANUARY, 23, 18, 33, 5);
        final Object[] args = {"John Doe", cal.getTime(), Double.valueOf("12345.67")};
        final DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
        final NumberFormat nf = NumberFormat.getCurrencyInstance();
        final StringBuilder expected = new StringBuilder();
        expected.append("Name: ");
        expected.append(args[0].toString().toUpperCase());
        expected.append(" DOB: ");
        expected.append(df.format(args[1]));
        expected.append(" Salary: ");
        expected.append(nf.format(args[2]));
        assertEquals(expected.toString(), emf.format(args));
    }

    /**
     * Test extended formats.
     */
    @Test
    void testExtendedFormats() {
        final String pattern = "Lower: {0,lower} Upper: {1,upper}";
        final ExtendedMessageFormat emf = new ExtendedMessageFormat(pattern, registry);
        assertEquals(pattern, emf.toPattern(), "TOPATTERN");
        assertEquals(emf.format(new Object[] {"foo", "bar"}), "Lower: foo Upper: BAR");
        assertEquals(emf.format(new Object[] {"Foo", "Bar"}), "Lower: foo Upper: BAR");
        assertEquals(emf.format(new Object[] {"FOO", "BAR"}), "Lower: foo Upper: BAR");
        assertEquals(emf.format(new Object[] {"FOO", "bar"}), "Lower: foo Upper: BAR");
        assertEquals(emf.format(new Object[] {"foo", "BAR"}), "Lower: foo Upper: BAR");
    }

    @CartesianTest
    @CartesianTest.MethodFactory("testOverriddenBuiltinFormatFactory")
    void testOverriddenBuiltinFormat(final String pattern, final Locale locale) {
        final Calendar cal = Calendar.getInstance();
        cal.set(2007, Calendar.JANUARY, 23);
        final Object[] args = { cal.getTime() };
        // check the non-overridden builtins:
        checkBuiltInFormat(pattern, null, args, (Locale) null);
        checkBuiltInFormat(pattern, null, args, locale);
    }

    @ParameterizedTest
    @MethodSource("java.text.DateFormat#getAvailableLocales")
    void testOverriddenBuiltinFormat2(final Locale locale) {
        final Calendar cal = Calendar.getInstance();
        cal.set(2007, Calendar.JANUARY, 23);
        final Object[] args = { cal.getTime() };
        final Map<String, ? extends FormatFactory> dateRegistry = Collections.singletonMap("date", new OverrideShortDateFormatFactory());
        // check the overridden format:
        final MessageFormat dateDefault = createMessageFormat("{0,date}", locale);
        final String pattern = "{0,date,short}";
        final ExtendedMessageFormat dateShort = new ExtendedMessageFormat(pattern, locale, dateRegistry);
        assertEquals(dateDefault.format(args), dateShort.format(args), "overridden date,short format");
        assertEquals(pattern, dateShort.toPattern(), "overridden date,short pattern");
    }

    /**
     * A format element whose format style ends with a quoted literal immediately before the closing brace is a valid
     * pattern (accepted by {@link MessageFormat} and by this class when no registry is supplied), but the registry
     * parsing path rejected it with "Unterminated format element".
     */
    @Test
    void testQuotedLiteralAtEndOfFormatElement() {
        assertEquals("ABC", new ExtendedMessageFormat("{0,upper,'x'}", registry).format(new Object[] {"abc"}));
        assertEquals("ABC", new ExtendedMessageFormat("{0,upper,'}'}", registry).format(new Object[] {"abc"}));
        // a built-in format style ending in a quote only reaches the registry parser because the registry is non-null
        assertEquals("5%", new ExtendedMessageFormat("{0,number,0'%'}", registry).format(new Object[] {Integer.valueOf(5)}));
    }

    @Test
    void testTruncatedFormatElementWithRegistry() {
        // Sanity check to match JRE
        assertThrowsExactly(IllegalArgumentException.class, () -> new MessageFormat("{"));
        assertThrowsExactly(IllegalArgumentException.class, () -> new MessageFormat("{0,"));
        assertThrowsExactly(IllegalArgumentException.class, () -> new MessageFormat("{0}extra{"));
        // A format element left unterminated at the end of the pattern used to make the
        // registry-based constructor seek one past the buffer and throw
        // ArrayIndexOutOfBoundsException; it should report the documented
        // IllegalArgumentException, as the plain constructor already does.
        assertThrowsExactly(IllegalArgumentException.class, () -> new ExtendedMessageFormat("{", new HashMap<>()));
        assertThrowsExactly(IllegalArgumentException.class, () -> new ExtendedMessageFormat("{0,", new HashMap<>()));
        assertThrowsExactly(IllegalArgumentException.class, () -> new ExtendedMessageFormat("{0}extra{", new HashMap<>()));
    }

    /**
     * Test that an unmatched quote is treated as closed at the end of the pattern,
     * as by java.text.MessageFormat.
     */
    @Test
    void testUnmatchedQuote() {
        final ExtendedMessageFormat emf = new ExtendedMessageFormat("it's a {0,lower} test!", registry);
        assertEquals("its a {0,lower} test!", emf.format(new Object[] {"DUMMY"}));
        assertEquals(emf.format(new Object[] {"DUMMY"}),
                new ExtendedMessageFormat(emf.toPattern(), registry).format(new Object[] {"DUMMY"}));

        final ExtendedMessageFormat emf2 = new ExtendedMessageFormat("Don{0,upper}t panic: '", registry);
        assertEquals("DonDUMMYt panic: ", emf2.format(new Object[] {"Dummy"}));
        assertEquals("Don{0,upper}t panic: ", emf2.toPattern());
        assertEquals(emf2.format(new Object[] {"Dummy"}),
                new ExtendedMessageFormat(emf2.toPattern(), registry).format(new Object[] {"Dummy"}));
    }

    /**
     * Checks that an unmatched quote does not make an unfinished format element valid.
     *
     * @param pattern pattern containing an unfinished format element
     */
    @ParameterizedTest
    @ValueSource(strings = {"{0,number,0'foo}", "{0,date,yyyy'foo}", "{0,choice,0#'foo}", "{0,upper,'foo}"})
    void testUnmatchedQuoteInFormatDescription(final String pattern) {
        assertThrowsExactly(IllegalArgumentException.class, () -> new ExtendedMessageFormat(pattern, registry));
    }

    /**
     * Checks unmatched quotes against MessageFormat with an empty registry, including pattern round-tripping.
     *
     * @param pattern pattern containing an unmatched quote
     */
    @ParameterizedTest
    @ValueSource(strings = {"Don't panic {0}", "'", "'''", "prefix '", "'{0}", "{0} suffix '{1}"})
    void testUnmatchedQuoteWithEmptyRegistry(final String pattern) {
        final Object[] args = {"Dummy", "Other"};
        final MessageFormat expected = new MessageFormat(pattern, Locale.ROOT);
        final ExtendedMessageFormat actual = new ExtendedMessageFormat(pattern, Locale.ROOT, Collections.emptyMap());
        assertEquals(expected.format(args), actual.format(args));
        assertEquals(expected.toPattern(), actual.toPattern());
        final ExtendedMessageFormat reconstructed = new ExtendedMessageFormat(actual.toPattern(), Locale.ROOT, Collections.emptyMap());
        assertEquals(actual.format(args), reconstructed.format(args));
    }

}
