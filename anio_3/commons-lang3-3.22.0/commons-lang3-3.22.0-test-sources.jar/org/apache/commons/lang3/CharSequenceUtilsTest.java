/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

import static org.apache.commons.lang3.LangAssertions.assertIndexOutOfBoundsException;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.params.provider.Arguments.arguments;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.nio.CharBuffer;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Tests CharSequenceUtils
 */
class CharSequenceUtilsTest extends AbstractLangTest {

    private abstract static class RunTest {

        abstract boolean invoke();

        void run(final TestData data, final String id) {
            if (data.throwable != null) {
                assertThrows(data.throwable, this::invoke, id + " Expected " + data.throwable);
            } else {
                final boolean stringCheck = invoke();
                assertEquals(data.expected, stringCheck, id + " Failed test " + data);
            }
        }

    }

    static class TestData {
        final String source;
        final boolean ignoreCase;
        final int toffset;
        final String other;
        final int ooffset;
        final int len;
        final boolean expected;
        final Class<? extends Throwable> throwable;

        TestData(final String source, final boolean ignoreCase, final int toffset, final String other, final int ooffset, final int len,
                final boolean expected) {
            this.source = source;
            this.ignoreCase = ignoreCase;
            this.toffset = toffset;
            this.other = other;
            this.ooffset = ooffset;
            this.len = len;
            this.expected = expected;
            this.throwable = null;
        }

        TestData(final String source, final boolean ignoreCase, final int toffset, final String other, final int ooffset, final int len,
                final Class<? extends Throwable> throwable) {
            this.source = source;
            this.ignoreCase = ignoreCase;
            this.toffset = toffset;
            this.other = other;
            this.ooffset = ooffset;
            this.len = len;
            this.expected = false;
            this.throwable = throwable;
        }

        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(source).append("[").append(toffset).append("]");
            sb.append(ignoreCase ? " caseblind " : " samecase ");
            sb.append(other).append("[").append(ooffset).append("]");
            sb.append(" ").append(len).append(" => ");
            if (throwable != null) {
                sb.append(throwable);
            } else {
                sb.append(expected);
            }
            return sb.toString();
        }
    }

    static class WrapperString implements CharSequence {
        private final CharSequence inner;

        WrapperString(final CharSequence inner) {
            this.inner = inner;
        }

        @Override
        public char charAt(final int index) {
            return inner.charAt(index);
        }

        @Override
        public IntStream chars() {
            return inner.chars();
        }

        @Override
        public IntStream codePoints() {
            return inner.codePoints();
        }

        @Override
        public int length() {
            return inner.length();
        }

        @Override
        public CharSequence subSequence(final int start, final int end) {
            return inner.subSequence(start, end);
        }

        @Override
        public String toString() {
            return inner.toString();
        }
    }

    private static final TestData[] TEST_DATA = {
            // @formatter:off
            //           Source  IgnoreCase Offset Other  Offset Length Result
            new TestData("",     true,      -1,     "",    -1,    -1,    false),
            new TestData("",     true,       0,     "",     0,     1,    false),
            new TestData("a",    true,       0,     "abc",  0,     0,    true),
            new TestData("a",    true,       0,     "abc",  0,     1,    true),
            new TestData("a",    true,       0,     null,   0,     0,    NullPointerException.class),
            new TestData(null,   true,       0,     null,   0,     0,    NullPointerException.class),
            new TestData(null,   true,       0,     "",     0,     0,    NullPointerException.class),
            new TestData("Abc",  true,       0,     "abc",  0,     3,    true),
            new TestData("Abc",  false,      0,     "abc",  0,     3,    false),
            new TestData("Abc",  true,       1,     "abc",  1,     2,    true),
            new TestData("Abc",  false,      1,     "abc",  1,     2,    true),
            new TestData("Abcd", true,       1,     "abcD", 1,     2,    true),
            new TestData("Abcd", false,      1,     "abcD", 1,     2,    true),
            // @formatter:on
    };

    private static void assertRegionMatchesParity(final String source, final boolean ignoreCase, final int toffset, final String other,
            final int ooffset, final int len) {
        // String is the reference: whatever the running JDK does for String, every CharSequence type must match.
        final boolean expected = source.regionMatches(ignoreCase, toffset, other, ooffset, len);
        final CharSequence[] sources = {source, new StringBuilder(source), new StringBuffer(source), CharBuffer.wrap(source)};
        for (final CharSequence cs : sources) {
            assertEquals(expected, CharSequenceUtils.regionMatches(cs, ignoreCase, toffset, other, ooffset, len),
                    cs.getClass().getSimpleName() + " differs from String for " + source + " vs " + other);
        }
    }

    static Stream<Arguments> lastIndexWithStandardCharSequence() {
        // @formatter:off
        return Stream.of(
            arguments("abc", "b", 2, 1),
            arguments(new StringBuilder("abc"), "b", 2, 1),
            arguments(new StringBuffer("abc"), "b", 2, 1),
            arguments("abc", new StringBuilder("b"), 2, 1),
            arguments(new StringBuilder("abc"), new StringBuilder("b"), 2, 1),
            arguments(new StringBuffer("abc"), new StringBuffer("b"), 2, 1),
            arguments(new StringBuilder("abc"), new StringBuffer("b"), 2, 1)
        );
        // @formatter:on
    }

    @Test
    void testConstructor() {
        assertNotNull(new CharSequenceUtils());
        final Constructor<?>[] cons = CharSequenceUtils.class.getDeclaredConstructors();
        assertEquals(1, cons.length);
        assertTrue(Modifier.isPublic(cons[0].getModifiers()));
        assertTrue(Modifier.isPublic(CharSequenceUtils.class.getModifiers()));
        assertFalse(Modifier.isFinal(CharSequenceUtils.class.getModifiers()));
    }

    @ParameterizedTest
    @MethodSource("lastIndexWithStandardCharSequence")
    void testLastIndexOfWithDifferentCharSequences(final CharSequence cs, final CharSequence search, final int start, final int expected) {
        assertEquals(expected, CharSequenceUtils.lastIndexOf(cs, search, start));
    }

    /**
     * Tests that the direct-scan fallback in {@link CharSequenceUtils#indexOf(CharSequence, CharSequence, int)} (taken by CharSequence
     * types without a dedicated dispatch branch, such as {@code org.apache.commons.lang3.text.StrBuilder}) matches
     * {@link String#indexOf(String, int)} semantics exactly and never materializes the searched sequence via {@code toString()}.
     */
    @Test
    void testNewIndexOf() {
        testNewIndexOfSingle("808087847-1321060740-635567660180086727-925755305", "-1321060740-635567660");
        testNewIndexOfSingle("", "");
        testNewIndexOfSingle("1", "");
        testNewIndexOfSingle("", "1");
        testNewIndexOfSingle("1", "1");
        testNewIndexOfSingle("11", "1");
        testNewIndexOfSingle("1", "11");
        testNewIndexOfSingle("apache", "a");
        testNewIndexOfSingle("apache", "p");
        testNewIndexOfSingle("apache", "e");
        testNewIndexOfSingle("apache", "x");
        testNewIndexOfSingle("oraoraoraora", "r");
        testNewIndexOfSingle("mudamudamudamuda", "d");
        testNewIndexOfSingle("junk-ststarting", "starting");
        // The searched sequence must not be copied by the fallback.
        final CharSequence noToString = new WrapperString("hello world") {
            @Override
            public String toString() {
                throw new AssertionError("cs.toString() must not be called by indexOf");
            }
        };
        assertEquals(6, CharSequenceUtils.indexOf(noToString, "world", 0));
        assertEquals(-1, CharSequenceUtils.indexOf(noToString, "worlds", 0));
    }

    private void testNewIndexOfSingle(final CharSequence a, final CharSequence b) {
        final int maxa = Math.max(a.length(), b.length());
        for (int i = -maxa - 10; i <= maxa + 10; i++) {
            testNewIndexOfSingle(a, b, i);
        }
        testNewIndexOfSingle(a, b, Integer.MIN_VALUE);
        testNewIndexOfSingle(a, b, Integer.MAX_VALUE);
    }

    private void testNewIndexOfSingle(final CharSequence a, final CharSequence b, final int start) {
        testNewIndexOfSingleSingle(a, b, start);
        testNewIndexOfSingleSingle(b, a, start);
    }

    private void testNewIndexOfSingleSingle(final CharSequence a, final CharSequence b, final int start) {
        assertEquals(a.toString().indexOf(b.toString(), start),
                CharSequenceUtils.indexOf(new WrapperString(a.toString()), new WrapperString(b.toString()), start),
                "testNewIndexOf fails! original : " + a + " seg : " + b + " start : " + start);
    }

    @Test
    void testNewLastIndexOf() {
        testNewLastIndexOfSingle("808087847-1321060740-635567660180086727-925755305", "-1321060740-635567660", 21);
        testNewLastIndexOfSingle("", "");
        testNewLastIndexOfSingle("1", "");
        testNewLastIndexOfSingle("", "1");
        testNewLastIndexOfSingle("1", "1");
        testNewLastIndexOfSingle("11", "1");
        testNewLastIndexOfSingle("1", "11");

        testNewLastIndexOfSingle("apache", "a");
        testNewLastIndexOfSingle("apache", "p");
        testNewLastIndexOfSingle("apache", "e");
        testNewLastIndexOfSingle("apache", "x");
        testNewLastIndexOfSingle("oraoraoraora", "r");
        testNewLastIndexOfSingle("mudamudamudamuda", "d");
        // There is a route through checkLaterThan1#checkLaterThan1
        // which only gets touched if there is a two letter (or more) partial match
        // (in this case "st") earlier in the searched string.
        testNewLastIndexOfSingle("junk-ststarting", "starting");

        final Random random = new Random();
        final StringBuilder seg = new StringBuilder();
        while (seg.length() <= CharSequenceUtils.TO_STRING_LIMIT) {
            seg.append(random.nextInt());
        }
        StringBuilder original = new StringBuilder(seg);
        testNewLastIndexOfSingle(original, seg);
        for (int i = 0; i < 100; i++) {
            if (random.nextDouble() < 0.5) {
                original.append(random.nextInt() % 10);
            } else {
                original = new StringBuilder().append(random.nextInt() % 100).append(original);
            }
            testNewLastIndexOfSingle(original, seg);
        }
    }

    private void testNewLastIndexOfSingle(final CharSequence a, final CharSequence b) {
        final int maxa = Math.max(a.length(), b.length());
        for (int i = -maxa - 10; i <= maxa + 10; i++) {
            testNewLastIndexOfSingle(a, b, i);
        }
        testNewLastIndexOfSingle(a, b, Integer.MIN_VALUE);
        testNewLastIndexOfSingle(a, b, Integer.MAX_VALUE);
    }

    private void testNewLastIndexOfSingle(final CharSequence a, final CharSequence b, final int start) {
        testNewLastIndexOfSingleSingle(a, b, start);
        testNewLastIndexOfSingleSingle(b, a, start);
    }

    private void testNewLastIndexOfSingleSingle(final CharSequence a, final CharSequence b, final int start) {
        assertEquals(a.toString().lastIndexOf(b.toString(), start),
                CharSequenceUtils.lastIndexOf(new WrapperString(a.toString()), new WrapperString(b.toString()), start),
                "testNewLastIndexOf fails! original : " + a + " seg : " + b + " start : " + start);
    }

    @Test
    void testRegionMatches() {
        for (final TestData data : TEST_DATA) {
            new RunTest() {
                @Override
                boolean invoke() {
                    return data.source.regionMatches(data.ignoreCase, data.toffset, data.other, data.ooffset, data.len);
                }
            }.run(data, "String");
            new RunTest() {
                @Override
                boolean invoke() {
                    return CharSequenceUtils.regionMatches(data.source, data.ignoreCase, data.toffset, data.other, data.ooffset, data.len);
                }
            }.run(data, "CSString");
            new RunTest() {
                @Override
                boolean invoke() {
                    return CharSequenceUtils.regionMatches(new StringBuilder(data.source), data.ignoreCase, data.toffset, data.other, data.ooffset, data.len);
                }
            }.run(data, "CSNonString");
        }
    }

    /**
     * A supplementary code point split across a surrogate pair must fold the same way for every {@link CharSequence}
     * type that it does for {@link String} on the running JDK. {@link String#regionMatches(boolean, int, String, int, int)}
     * only folds such a code point from Java 9 on, so these rows are checked against {@link String} itself rather than a
     * fixed result: {@link String}, {@link StringBuilder}, {@link StringBuffer} and {@link CharBuffer} all have to agree.
     * Deseret CAPITAL LONG I (U+10400) folds to SMALL LONG I (U+10428).
     */
    @Test
    void testRegionMatchesSupplementaryCaseFold() {
        assertRegionMatchesParity("\uD801\uDC00", true, 0, "\uD801\uDC28", 0, 2);
        assertRegionMatchesParity("\uD801\uDC00", false, 0, "\uD801\uDC28", 0, 2);
        assertRegionMatchesParity("\uD801\uDC28", true, 0, "\uD801\uDC00", 0, 2);
        assertRegionMatchesParity("x\uD801\uDC00", true, 1, "\uD801\uDC28", 0, 2);
        assertRegionMatchesParity("\uD801\uDC00", true, 0, "\uD801\uDC29", 0, 2);
    }

    @Test
    void testSubSequence() {
        //
        // null input
        //
        assertNull(CharSequenceUtils.subSequence(null, -1));
        assertNull(CharSequenceUtils.subSequence(null, 0));
        assertNull(CharSequenceUtils.subSequence(null, 1));
        //
        // non-null input
        //
        assertEquals(StringUtils.EMPTY, CharSequenceUtils.subSequence(StringUtils.EMPTY, 0));
        assertEquals("012", CharSequenceUtils.subSequence("012", 0));
        assertEquals("12", CharSequenceUtils.subSequence("012", 1));
        assertEquals("2", CharSequenceUtils.subSequence("012", 2));
        assertEquals(StringUtils.EMPTY, CharSequenceUtils.subSequence("012", 3));
    }

    @Test
    void testSubSequenceNegativeStart() {
        assertIndexOutOfBoundsException(() -> CharSequenceUtils.subSequence(StringUtils.EMPTY, -1));
    }

    @Test
    void testSubSequenceTooLong() {
        assertIndexOutOfBoundsException(() -> CharSequenceUtils.subSequence(StringUtils.EMPTY, 1));
    }

    @Test
    void testToCharArray() {
        final StringBuilder builder = new StringBuilder("abcdefg");
        final char[] expected = builder.toString().toCharArray();
        assertArrayEquals(expected, CharSequenceUtils.toCharArray(builder));
        assertArrayEquals(expected, CharSequenceUtils.toCharArray(builder.toString()));
        assertArrayEquals(ArrayUtils.EMPTY_CHAR_ARRAY, CharSequenceUtils.toCharArray(null));
    }
}
