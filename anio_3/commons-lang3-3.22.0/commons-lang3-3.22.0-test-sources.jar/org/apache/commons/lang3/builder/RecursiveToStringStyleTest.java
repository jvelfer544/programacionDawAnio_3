/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang3.AbstractLangTest;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableByte;
import org.apache.commons.lang3.mutable.MutableDouble;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.apache.commons.lang3.mutable.MutableInt;
import org.apache.commons.lang3.mutable.MutableLong;
import org.apache.commons.lang3.mutable.MutableShort;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link RecursiveToStringStyleTest}.
 */
class RecursiveToStringStyleTest extends AbstractLangTest {

    static class Job {

        /**
         * Test String field.
         */
        String title;
    }

    static class Person {

        /**
         * Test String field.
         */
        String name;

        /**
         * Test integer field.
         */
        int age;

        /**
         * Test boolean field.
         */
        boolean smoker;

        /**
         * Test Object field.
         */
        Job job;
    }

    private final Integer base = Integer.valueOf(5);

    private final String baseStr = base.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(base));

    @BeforeEach
    public void setUp() {
        ToStringBuilder.setDefaultStyle(new RecursiveToStringStyle());
    }

    @AfterEach
    public void tearDown() {
        ToStringBuilder.setDefaultStyle(ToStringStyle.DEFAULT_STYLE);
    }

    @Test
    void testAppendSuper() {
        assertEquals(baseStr + "[]", new ToStringBuilder(base).appendSuper("Integer@8888[]").toString());
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).appendSuper("Integer@8888[<null>]").toString());

        assertEquals(baseStr + "[a=hello]", new ToStringBuilder(base).appendSuper("Integer@8888[]").append("a", "hello").toString());
        assertEquals(baseStr + "[<null>,a=hello]", new ToStringBuilder(base).appendSuper("Integer@8888[<null>]").append("a", "hello").toString());
        assertEquals(baseStr + "[a=hello]", new ToStringBuilder(base).appendSuper(null).append("a", "hello").toString());
    }

    @Test
    void testAtomicsArray() {
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new AtomicLong[] { new AtomicLong(3), new AtomicLong(6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new AtomicInteger[] { new AtomicInteger(3), new AtomicInteger(6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{true,false}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new AtomicBoolean[] { new AtomicBoolean(true), new AtomicBoolean(false) } }).toString());
    }

    @Test
    void testBigDecimal() {
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new BigDecimal[] { BigDecimal.valueOf(3), BigDecimal.valueOf(6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3.0,6.0}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new BigDecimal[] { BigDecimal.valueOf(3.0), BigDecimal.valueOf(6.0) } }).toString());
    }

    @Test
    void testBigInteger() {
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new BigInteger[] { BigInteger.valueOf(3), BigInteger.valueOf(6) } }).toString());
    }

    @Test
    void testBlank() {
        assertEquals(baseStr + "[]", new ToStringBuilder(base).toString());
    }

    @Test
    void testLong() {
        assertEquals(baseStr + "[3]", new ToStringBuilder(base).append(3L).toString());
        assertEquals(baseStr + "[a=3]", new ToStringBuilder(base).append("a", 3L).toString());
        assertEquals(baseStr + "[a=3,b=4]", new ToStringBuilder(base).append("a", 3L).append("b", 4L).toString());
    }

    @Test
    void testLongArray() {
        long[] array = {1, 2, -3, 4};
        assertEquals(baseStr + "[{1,2,-3,4}]", new ToStringBuilder(base).append(array).toString());
        assertEquals(baseStr + "[{1,2,-3,4}]", new ToStringBuilder(base).append((Object) array).toString());
        array = null;
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append(array).toString());
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append((Object) array).toString());
    }

    @Test
    void testLongArrayArray() {
        long[][] array = {{1, 2}, null, {5}};
        assertEquals(baseStr + "[{{1,2},<null>,{5}}]", new ToStringBuilder(base).append(array).toString());
        assertEquals(baseStr + "[{{1,2},<null>,{5}}]", new ToStringBuilder(base).append((Object) array).toString());
        array = null;
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append(array).toString());
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append((Object) array).toString());
    }

    /**
     * With an output-length limit configured, nested objects past the limit are elided with a
     * clear truncation marker.
     */
    @Test
    void testMaxOutputLengthTruncates() {
        final List<Object> list = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            list.add(new ArrayList<>(Collections.singletonList("item" + i)));
        }
        final String s = new ToStringBuilder(base, RecursiveToStringStyle.builder().setMaxOutputLength(200).get()).append("g", list, true).toString();
        assertTrue(s.contains("...<truncated>"), "Truncation marker expected: " + s);
        assertTrue(s.length() < 10_000, "Output must be throttled, was " + s.length());
    }

    @Test
    void testMutableWrapperArray() {
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableLong[] { new MutableLong(3), new MutableLong(6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableInt[] { new MutableInt(3), new MutableInt(6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableShort[] { new MutableShort(3), new MutableShort(6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableByte[] { new MutableByte((byte) 3), new MutableByte((byte) 6) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3.0,6.0}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableFloat[] { new MutableFloat(3f), new MutableFloat(6f) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3.0,6.0}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableDouble[] { new MutableDouble(3d), new MutableDouble(6d) } }).toString());
        assertEquals(baseStr + "[{<null>,5,{true,false}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new MutableBoolean[] { new MutableBoolean(true), new MutableBoolean(false) } }).toString());
    }

    @Test
    void testObject() {
        final Integer i3 = Integer.valueOf(3);
        final Integer i4 = Integer.valueOf(4);
        final ArrayList<Object> emptyList = new ArrayList<>();

        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append((Object) null).toString());
        assertEquals(baseStr + "[3]", new ToStringBuilder(base).append(i3).toString());
        assertEquals(baseStr + "[a=<null>]", new ToStringBuilder(base).append("a", (Object) null).toString());
        assertEquals(baseStr + "[a=3]", new ToStringBuilder(base).append("a", i3).toString());
        assertEquals(baseStr + "[a=3,b=4]", new ToStringBuilder(base).append("a", i3).append("b", i4).toString());
        assertEquals(baseStr + "[a=<Integer>]", new ToStringBuilder(base).append("a", i3, false).toString());
        assertEquals(baseStr + "[a=<size=0>]", new ToStringBuilder(base).append("a", emptyList, false).toString());
        assertEquals(baseStr + "[a=java.util.ArrayList@" + Integer.toHexString(System.identityHashCode(emptyList)) + "{}]",
                new ToStringBuilder(base).append("a", emptyList, true).toString());
        assertEquals(baseStr + "[a=<size=0>]", new ToStringBuilder(base).append("a", new HashMap<>(), false).toString());
        assertEquals(baseStr + "[a={}]", new ToStringBuilder(base).append("a", new HashMap<>(), true).toString());
        assertEquals(baseStr + "[a=<size=0>]", new ToStringBuilder(base).append("a", (Object) new String[0], false).toString());
        assertEquals(baseStr + "[a={}]", new ToStringBuilder(base).append("a", (Object) new String[0], true).toString());
    }

    @Test
    void testObjectArray() {
        Object[] array = {null, base, new int[] {3, 6}};
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append(array).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append((Object) array).toString());
        array = null;
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append(array).toString());
        assertEquals(baseStr + "[<null>]", new ToStringBuilder(base).append((Object) array).toString());
    }

    @Test
    void testPerson() {
        final Person p = new Person();
        p.name = "John Doe";
        p.age = 33;
        p.smoker = false;
        p.job = new Job();
        p.job.title = "Manager";
        final String baseStr = p.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p));
        final String jobStr = p.job.getClass().getName() + "@" + Integer.toHexString(System.identityHashCode(p.job));
        final ReflectionToStringBuilder builder = new ReflectionToStringBuilder(p, new RecursiveToStringStyle());
        final String expected = baseStr + (builder.isForceAccessible() ? "[age=33,job=" + jobStr + "[title=Manager],name=John Doe,smoker=false]"
                : "[age=<null>,job=<null>,name=<null>,smoker=<null>]");
        assertEquals(expected, builder.toString());
    }

    @Test
    void testPrimitiveWrapperArray() {
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Character[] { '3', '6' } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Long[] { 3L, 6L } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Integer[] { 3, 6 } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Short[] { 3, 6 } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3,6}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Byte[] { 3, 6 } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3.0,6.0}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Float[] { 3f, 6f } }).toString());
        assertEquals(baseStr + "[{<null>,5,{3.0,6.0}}]", new ToStringBuilder(base).append(new Object[] { null, base, new Double[] { 3d, 6d } }).toString());
        assertEquals(baseStr + "[{<null>,5,{true,false}}]",
                new ToStringBuilder(base).append(new Object[] { null, base, new Boolean[] { true, false } }).toString());
    }

    /**
     * A shared (acyclic) reference is detailed once per top-level call; the second occurrence
     * is rendered in the abbreviated {@code Object.toString()} format instead of re-traversed.
     */
    @Test
    void testSharedReferenceDetailedOnce() {
        final ArrayList<Object> shared = new ArrayList<>(Collections.singletonList("x"));
        final String sharedStr = "java.util.ArrayList@" + Integer.toHexString(System.identityHashCode(shared));
        assertEquals(baseStr + "[a=" + sharedStr + "{x},b=" + sharedStr + "]",
                new ToStringBuilder(base).append("a", shared, true).append("b", shared, true).toString());
    }

    /**
     * A deep reference diamond (each level holding two references to the same child) must be
     * traversed in linear time and produce linear output. Without the per-call visited set,
     * this 40-level diamond would require ~2^40 traversals.
     */
    @Test
    void testSharedReferenceDiamondIsLinear() {
        List<Object> child = new ArrayList<>(Collections.singletonList("leaf"));
        for (int i = 0; i < 40; i++) {
            final List<Object> parent = new ArrayList<>();
            parent.add(child);
            parent.add(child);
            child = parent;
        }
        final String s = new ToStringBuilder(base).append("g", child, true).toString();
        assertTrue(s.contains("leaf"), "The graph content must still be rendered");
        assertTrue(s.length() < 100_000, "Output must be linear in graph size, was " + s.length());
    }
}
