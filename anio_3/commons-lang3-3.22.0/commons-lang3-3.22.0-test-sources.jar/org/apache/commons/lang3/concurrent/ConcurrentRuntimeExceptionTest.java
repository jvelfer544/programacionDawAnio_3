/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.commons.lang3.concurrent;

import static org.apache.commons.lang3.LangAssertions.assertIllegalArgumentException;

import org.apache.commons.lang3.AbstractLangTest;
import org.junit.jupiter.api.Test;

/**
 * Tests {@link ConcurrentRuntimeException}.
 */
class ConcurrentRuntimeExceptionTest extends AbstractLangTest {

    /**
     * Tries to create a ConcurrentRuntimeException with an error as cause.
     */
    @Test
    void testCauseError() {
        assertIllegalArgumentException(() -> new ConcurrentRuntimeException("An error", new Error()));
    }

    /**
     * Tries to create a ConcurrentRuntimeException with null as cause.
     */
    @Test
    void testCauseNull() {
        assertIllegalArgumentException(() -> new ConcurrentRuntimeException(null));
    }

    /**
     * Tries to create a ConcurrentRuntimeException with a runtime as cause.
     */
    @Test
    void testCauseUnchecked() {
        assertIllegalArgumentException(() -> new ConcurrentRuntimeException(new RuntimeException()));
    }
}
