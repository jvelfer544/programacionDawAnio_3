/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.reflect;

import static org.apache.commons.lang3.LangAssertions.assertIllegalArgumentException;
import static org.apache.commons.lang3.LangAssertions.assertNullPointerException;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.Insets;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.BiFunction;
import java.util.stream.Stream;

import org.apache.commons.lang3.AbstractLangTest;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.reflect.testbed.Foo;
import org.apache.commons.lang3.reflect.testbed.GenericParent;
import org.apache.commons.lang3.reflect.testbed.GenericTypeHolder;
import org.apache.commons.lang3.reflect.testbed.StringParameterizedChild;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

/**
 * Test fixture for https://issues.apache.org/jira/browse/LANG-1524
 *
 * @param <T> Test fixture type, unused type parameter for test.
 */
class AAAAClass<T extends AAAAClass.BBBBClass.CCCClass> {
    public static class BBBBClass {
        public static class CCCClass {
            // empty
        }
    }
}

final class AAAClass extends AAClass<String> {
    public class BBBClass extends BBClass<String> {
        // empty
    }
}

/**
 * Test fixture.
 *
 * @param <T> Test fixture type, unused type parameter for test.
 */
class AAClass<T> {

    /**
     * Test fixture.
     *
     * @param <S> Test fixture type, unused type parameter for test.
     */
    public class BBClass<S> {
        // empty
    }
}

@SuppressWarnings("rawtypes")
//raw types, where used, are used purposely
final class AClass extends AAClass<String>.BBClass<Number> {

    @SuppressWarnings("unused") // Unused type parameter for test
    public interface AInterface<T> {
        // empty
    }

    @SuppressWarnings("unused") // Unused type parameter for test
    public class BClass<T> {
        // empty
    }

    @SuppressWarnings("unused") // Unused type parameter for test
    public class CClass<T> extends BClass {
        // empty
    }

    @SuppressWarnings("unused") // Unused type parameter for test
    public class DClass<T> extends CClass<T> {
        // empty
    }

    @SuppressWarnings("unused") // Unused type parameter for test
    public class EClass<T> extends DClass {
        // empty
    }

    public class FClass extends EClass<String> {
        // empty
    }

    public class GClass<T extends BClass<? extends T> & AInterface<AInterface<? super T>>> {
        // empty
    }

    public BClass<Number> bClass;

    public CClass<? extends String> cClass;

    public DClass<String> dClass;

    public EClass<String> eClass;

    public FClass fClass;

    public GClass gClass;

    AClass(final AAClass<String> enclosingInstance) {
        enclosingInstance.super();
    }
}
class DependentBounds<T extends Number, S extends T> {
    // empty
}

class InterfaceBound<T extends List<String>> {
    // empty
}

class MultiBoundClass<U extends Number & Comparable<? super U>> {
    // empty
}

class MyClass<U extends MySuperClass<? super U>> {
    // empty
}

class MySuperClass<T> {
    // empty
}

class ParameterizedOwner<T> {
    class NonGenericInner {
        // empty
    }

    public NonGenericInner getInner() {
        return null;
    }
}

@SuppressWarnings("rawtypes")
abstract class Test1<G> {
    public abstract Object m0();
    public abstract String[] m1();
    public abstract <K, V> Map<? extends K, V[]> m10();
    public abstract <K, V> Map<? extends K, List<V[]>> m11();
    public abstract List m12();
    public abstract Map m13();
    public abstract Properties m14();
    public abstract G m15();
    public abstract List<G> m16();
    public abstract Enum m17();
    public abstract <E> E[] m2();
    public abstract <E> List<? extends E> m3();
    public abstract <E extends Enum<E>> List<? extends Enum<E>> m4();
    public abstract List<? extends Enum<?>> m5();
    public abstract List<? super Enum<?>> m6();
    public abstract List<?> m7();
    public abstract Map<? extends Enum<?>, ? super Enum<?>> m8();
    public abstract <K, V> Map<? extends K, ? super V[]> m9();
}

class TwoParams<T extends TwoParams<T, U>, U> {
    // empty
}

/**
 * Tests {@link TypeUtils}.
 *
 * @param <B> Type for test fixtures.
 */
@SuppressWarnings({ "unused", "rawtypes" })
// raw types, where used, are used purposely
class TypeUtilsTest<B> extends AbstractLangTest {

    public interface And<K, V> extends This<Number, Number> {
        // empty
    }

    private static class ArrayValues<T> extends ArrayList<T[]> {
        private static final long serialVersionUID = 1L;
    }

    private static class ClassWildcardTypes<T extends List, U, V extends List<String>, W extends U> {
        Class<ArrayValues<String>> arrayValues;
        Class<ArrayValues<U>> variableArrayValues;
        Class<? extends List<String[]>> extendsStringArrays;
        Class<? extends List<U[]>> extendsVariableArrays;
        Class<ArrayList<? extends U>> upperVariableValues;
        Class<ArrayList<? super U>> lowerVariableValues;
        Class<? extends List<? extends U>> extendsUpperVariableValues;
        Class<? extends List<? super U>> extendsLowerVariableValues;
        Class<List<String>> strings;
        Class<List> rawList;
        Class<ArrayList<String>> stringArrayList;
        Class<? extends List> extendsRawList;
        Class<? extends List<String>> extendsStrings;
        Class<? extends List<?>> extendsUnknownList;
        Class<? super List> superRawList;
        Class<? super List<String>> superStrings;
        Class<T> rawBound;
        Class<? extends T> extendsRawBound;
        Class<V> parameterizedBound;
        Class<RawTestImpl> rawSubclass;
        Class<ParameterizedRawTestImpl<String>> parameterizedRawSubclass;
        Class<RawNumberTestImpl> rawAncestor;
        Class<NumberTestImpl> fixedSubclass;
        Class<GenericNumberOwner.Member> rawMember;
        Class<GenericNumberOwner.StaticMember> staticMember;
        Class<GenericNumberOwner<String>.Member> parameterizedMember;
        Class<TestImpl<Number>> parameterizedSubclass;
        Class<TestImpl<U>> variableSubclass;
        Class<? extends TestIF<?>> extendsUnknownInterface;
        Class<? extends TestIF<Number>> extendsNumberInterface;
        Class<? extends TestIF<U>> extendsVariableInterface;
        Class<List[]> rawArray;
        Class<List<String>[]> parameterizedArray;
        Class<? extends List[]> extendsRawArray;
        Class<? extends List<String>[]> extendsParameterizedArray;
        Class<? super List[]> superRawArray;
        Class<? super List<String>[]> superParameterizedArray;
        Class<List<? extends List>> nestedRaw;
        Class<List<? extends List<String>>> nestedParameterized;
        Class<? extends List<? extends List<String>>> extendsNestedParameterized;
        Class<? super List<? extends List>> superNestedRaw;
        Class<? super List<? extends List<String>>> superNestedParameterized;
        Class<U> unboundedVariable;
        Class<? extends U> extendsUnboundedVariable;
        Class<? super U> superUnboundedVariable;
        Class<W> dependentVariable;
        Class<? extends W> extendsDependentVariable;
        Class<? super W> superDependentVariable;
    }

    public static class ClassWithSuperClassWithGenericType extends ArrayList<Object> {
        private static final long serialVersionUID = 1L;

        public static <U> Iterable<U> methodWithGenericReturnType() {
            return null;
        }
    }

    /**
     * A custom {@link ParameterizedType} with a structural {@code hashCode()}, whose owner and type arguments can be set after construction so that tests can
     * create cycles.
     */
    private static final class CyclicParameterizedType implements ParameterizedType {

        private final Class<?> rawType;
        private Type[] typeArguments;
        private Type ownerType;

        CyclicParameterizedType(final Class<?> rawType, final Type... typeArguments) {
            this.rawType = rawType;
            this.typeArguments = typeArguments;
        }

        @Override
        public boolean equals(final Object obj) {
            return this == obj;
        }

        @Override
        public Type[] getActualTypeArguments() {
            return typeArguments.clone();
        }

        @Override
        public Type getOwnerType() {
            return ownerType;
        }

        @Override
        public Type getRawType() {
            return rawType;
        }

        @Override
        public int hashCode() {
            // Structural like the JDK implementation: it follows the owner, so a cycle would overflow the stack.
            return Objects.hash(rawType, Arrays.hashCode(typeArguments), ownerType);
        }

        void setOwnerType(final Type ownerType) {
            this.ownerType = ownerType;
        }

        void setTypeArguments(final Type... typeArguments) {
            this.typeArguments = typeArguments;
        }

        @Override
        public String toString() {
            return "CyclicParameterizedType<" + rawType.getName() + ">";
        }
    }

    private static class GenericNumberOwner<T> {
        class Member implements TestIF<Number> {
        }

        static class StaticMember implements TestIF<Number> {
        }
    }

    private static class HashCodeTypes<T> {
        T[] array;
        List<T[]> arrayArgument;
        Map.Entry<String, Integer> entry;
        List<String> list;
        List<String>[] listArray;
        Map<String, Integer> map;
        Outer<String>.InnerU<Integer> member;
        Map<String, List<Integer>> nested;
        T[][] nestedArray;
        List<String>[][] nestedListArray;
        ParameterizedOwner<String>.NonGenericInner nonGenericMember;
        List<? extends T[]> upperBoundedArrayArgument;
        List<? extends Number> upperBoundedList;
        List<T> variableList;
        List<? super T[]> wildcardArrayArgument;
        List<?> wildcardList;
    }

    static class LexOrdering<T> extends MyOrdering<Iterable<T>> implements Serializable {
        private static final long serialVersionUID = 1L;
    }

    interface MyComparator<T> {
    }

    static class MyException extends Exception implements Iterable<Throwable> {

        private static final long serialVersionUID = 1L;

        @Override
        public Iterator<Throwable> iterator() {
            return null;
        }
    }

    /** This non-static inner class is parameterized. */
    private class MyInnerClass<T> {

        class MyInnerClass2<X> {
            // empty
        }
    }

    static class MyNonTransientException extends MyException {
        private static final long serialVersionUID = 1L;
    }

    static class MyOrdering<T> implements MyComparator<T> {
    }

    private static class NumberTestImpl implements TestIF<Number> {
    }

    public class Other<T> implements This<String, T> {
        // empty
    }

    /** LANG-1836: non-static inner classes whose owner type is parameterized. */
    static class Outer<T> {

        class Inner {
            // empty
        }

        class InnerU<U> {

            class Deep<V> {
                // empty
            }

            Deep<T> deep;
        }

        Map.Entry<T, Integer> entry;

        Inner inner;

        InnerU<Integer> innerUInteger;

        InnerU<T> innerUT;

        Map<T, T> map;
    }

    private static class ParameterizedRawTestImpl<T> extends TestImpl {
    }

    private static class RawGenericNumberTestImpl<T> extends NumberTestImpl {
    }

    private static class RawNumberTestImpl extends RawGenericNumberTestImpl {
    }

    private static class RawTestImpl extends TestImpl {
    }

    public class Tester implements This<String, B> {
        // empty
    }

    private interface TestIF<T> {
    }

    private static class TestImpl<T> implements TestIF<T> {
    }

    private static class TestImpl2<R> implements TestIF<Number> {
    }

    public class That<K, V> implements This<K, V> {
        // empty
    }

    public class The<K, V> extends That<Number, Number> implements And<String, String> {
        // empty
    }

    public class Thing<Q> extends Other<B> {
        // empty
    }

    public interface This<K, V> {
        // empty
    }

    public static Comparable<Integer> intComparable;

    public static Comparable<Long> longComparable;

    public static Comparable<String> stringComparable;

    public static List<String>[] stringListArray;

    public static URI uri;

    public static Comparable<URI> uriComparable;

    public static Comparable<?> wildcardComparable;

    public static <G extends Comparable<G>> G stub() {
        return null;
    }

    public static <G extends Comparable<? super G>> G stub2() {
        return null;
    }

    public static <T extends Comparable<? extends T>> T stub3() {
        return null;
    }

    static Stream<Arguments> testHashCodeMatchesJdk() {
        final Type variable = HashCodeTypes.class.getTypeParameters()[0];
        final Type array = TypeUtils.genericArrayType(variable);
        final Type strings = TypeUtils.parameterize(List.class, String.class);
        return Stream.of(
                Arguments.of("array", array),
                Arguments.of("arrayArgument", TypeUtils.parameterize(List.class, array)),
                Arguments.of("entry", TypeUtils.parameterizeWithOwner(Map.class, Map.Entry.class, String.class, Integer.class)),
                Arguments.of("list", strings),
                Arguments.of("listArray", TypeUtils.genericArrayType(strings)),
                Arguments.of("map", TypeUtils.parameterize(Map.class, String.class, Integer.class)),
                Arguments.of("member", TypeUtils.parameterizeWithOwner(TypeUtils.parameterize(Outer.class, String.class),
                        Outer.InnerU.class, Integer.class)),
                Arguments.of("nested", TypeUtils.parameterize(Map.class, String.class, TypeUtils.parameterize(List.class, Integer.class))),
                Arguments.of("nestedArray", TypeUtils.genericArrayType(array)),
                Arguments.of("nestedListArray", TypeUtils.genericArrayType(TypeUtils.genericArrayType(strings))),
                Arguments.of("nonGenericMember", TypeUtils.parameterizeWithOwner(TypeUtils.parameterize(ParameterizedOwner.class, String.class),
                        ParameterizedOwner.NonGenericInner.class)),
                Arguments.of("upperBoundedArrayArgument", TypeUtils.parameterize(List.class, TypeUtils.wildcardType().withUpperBounds(array).build())),
                Arguments.of("upperBoundedList", TypeUtils.parameterize(List.class, TypeUtils.wildcardType().withUpperBounds(Number.class).build())),
                Arguments.of("variableList", TypeUtils.parameterize(List.class, variable)),
                Arguments.of("wildcardArrayArgument", TypeUtils.parameterize(List.class, TypeUtils.wildcardType().withLowerBounds(array).build())),
                Arguments.of("wildcardList", TypeUtils.parameterize(List.class, TypeUtils.WILDCARD_ALL)));
    }

    static Stream<Arguments> testIsAssignable_ClassWildcardBounds() {
        return Stream.of(
                Arguments.of("arrayValues", "extendsStringArrays", true),
                Arguments.of("variableArrayValues", "extendsVariableArrays", true),
                Arguments.of("arrayValues", "extendsVariableArrays", false),
                Arguments.of("upperVariableValues", "extendsUpperVariableValues", true),
                Arguments.of("lowerVariableValues", "extendsLowerVariableValues", true),
                Arguments.of("upperVariableValues", "extendsLowerVariableValues", false),
                Arguments.of("lowerVariableValues", "extendsUpperVariableValues", false),
                Arguments.of("extendsRawList", "extendsStrings", false),
                Arguments.of("extendsRawList", "extendsUnknownList", false),
                Arguments.of("rawBound", "extendsStrings", false),
                Arguments.of("rawBound", "extendsUnknownList", false),
                Arguments.of("extendsRawBound", "extendsStrings", false),
                Arguments.of("rawSubclass", "extendsUnknownInterface", false),
                Arguments.of("parameterizedRawSubclass", "extendsUnknownInterface", false),
                Arguments.of("rawAncestor", "extendsNumberInterface", false),
                Arguments.of("rawMember", "extendsNumberInterface", false),
                Arguments.of("nestedRaw", "extendsNestedParameterized", false),
                Arguments.of("rawArray", "extendsParameterizedArray", false),
                Arguments.of("extendsRawArray", "extendsParameterizedArray", false),
                Arguments.of("strings", "superRawList", false),
                Arguments.of("superStrings", "superRawList", false),
                Arguments.of("parameterizedBound", "superRawList", false),
                Arguments.of("nestedParameterized", "superNestedRaw", false),
                Arguments.of("parameterizedArray", "superRawArray", false),
                Arguments.of("unboundedVariable", "extendsRawBound", false),
                Arguments.of("unboundedVariable", "extendsDependentVariable", false),
                Arguments.of("dependentVariable", "superUnboundedVariable", false),
                Arguments.of("rawBound", "extendsUnboundedVariable", false),
                Arguments.of("rawBound", "superUnboundedVariable", false),
                Arguments.of("strings", "extendsStrings", true),
                Arguments.of("stringArrayList", "extendsStrings", true),
                Arguments.of("parameterizedBound", "extendsStrings", true),
                Arguments.of("fixedSubclass", "extendsNumberInterface", true),
                Arguments.of("staticMember", "extendsNumberInterface", true),
                Arguments.of("parameterizedMember", "extendsNumberInterface", true),
                Arguments.of("parameterizedSubclass", "extendsNumberInterface", true),
                Arguments.of("variableSubclass", "extendsVariableInterface", true),
                Arguments.of("rawList", "superStrings", true),
                Arguments.of("rawArray", "superParameterizedArray", true),
                Arguments.of("nestedRaw", "superNestedParameterized", true),
                Arguments.of("parameterizedArray", "extendsParameterizedArray", true),
                Arguments.of("nestedParameterized", "extendsNestedParameterized", true),
                Arguments.of("unboundedVariable", "extendsUnboundedVariable", true),
                Arguments.of("unboundedVariable", "superUnboundedVariable", true),
                Arguments.of("dependentVariable", "extendsUnboundedVariable", true),
                Arguments.of("unboundedVariable", "superDependentVariable", true));
    }

    static Stream<Type> testTypeToString() {
        // @formatter:off
        return Stream.of(Comparator.class, Comparable.class, ArrayList.class, HashMap.class)
                .flatMap(cls -> Stream.of(cls.getDeclaredMethods()))
                .flatMap(m ->
                    Stream.concat(Stream.of(m.getGenericExceptionTypes()),
                    Stream.concat(Stream.of(m.getGenericParameterTypes()),
                    Stream.concat(Stream.of(m.getGenericReturnType()), Stream.of(m.getTypeParameters())))));
        // @formatter:on
    }

    public The<String, String> da;

    public That<String, String> dat;

    public TypeUtilsTest<String>.That<String, String> dat2;

    public TypeUtilsTest<Number>.That<String, String> dat3;

    public Thing ding;

    public This<String, String> dis;

    public Comparable<? extends Integer>[] intWildcardComparable;

    public Iterable<? extends Map<Integer, ? extends Collection<?>>> iterable;

    public TypeUtilsTest<String>.Tester tester;

    public Tester tester2;

    public Other<String> uhder;

    /** The inner class is used as a return type from a method. */
    private <U> MyInnerClass<U> aMethod() {
        return null;
    }

    @Test
    void test_LANG_1114() throws NoSuchFieldException {
        final Type nonWildcardType = getClass().getDeclaredField("wildcardComparable").getGenericType();
        final Type wildcardType = ((ParameterizedType) nonWildcardType).getActualTypeArguments()[0];

        assertFalse(TypeUtils.equals(wildcardType, nonWildcardType));
        assertFalse(TypeUtils.equals(nonWildcardType, wildcardType));
    }

    @Test
    void test_LANG_1190() throws NoSuchMethodException {
        final Type fromType = ClassWithSuperClassWithGenericType.class.getDeclaredMethod("methodWithGenericReturnType").getGenericReturnType();
        final Type failingToType = TypeUtils.wildcardType().withLowerBounds(ClassWithSuperClassWithGenericType.class).build();

        assertTrue(TypeUtils.isAssignable(fromType, failingToType));
    }

    @Test
    void test_LANG_1348() throws NoSuchMethodException {
        final Method method = Enum.class.getMethod("valueOf", Class.class, String.class);
        assertEquals("T extends java.lang.Enum<T>", TypeUtils.toString(method.getGenericReturnType()));
    }

    @Test
    void test_LANG_1524() {
        assertEquals("AAAAClass(cycle).BBBBClass.CCCClass", TypeUtils.toString(AAAAClass.BBBBClass.CCCClass.class));
        assertEquals("AAAAClass(cycle).BBBBClass", TypeUtils.toString(AAAAClass.BBBBClass.class));
        assertEquals("AAAAClass(cycle)", TypeUtils.toString(AAAAClass.class));
    }

    /**
     * Tests https://issues.apache.org/jira/projects/LANG/issues/LANG-1698
     *
     * <pre>{@code
     * java.lang.StackOverflowError
    at org.apache.commons.lang3.reflect.TypeUtils.typeVariableToString(TypeUtils.java:1785)
    at org.apache.commons.lang3.reflect.TypeUtils.toString(TypeUtils.java:1737)
    at org.apache.commons.lang3.reflect.TypeUtils.toString(TypeUtils.java:1714)
    at org.apache.commons.lang3.reflect.TypeUtils.appendAllTo(TypeUtils.java:302)
    at org.apache.commons.lang3.reflect.TypeUtils.wildcardTypeToString(TypeUtils.java:1902)
    at org.apache.commons.lang3.reflect.TypeUtils.toString(TypeUtils.java:1734)
    at org.apache.commons.lang3.reflect.TypeUtils.toString(TypeUtils.java:1714)
    at org.apache.commons.lang3.reflect.TypeUtils.appendAllTo(TypeUtils.java:302)
    at org.apache.commons.lang3.reflect.TypeUtils.parameterizedTypeToString(TypeUtils.java:1604)
    at org.apache.commons.lang3.reflect.TypeUtils.toString(TypeUtils.java:1731)
    at org.apache.commons.lang3.reflect.TypeUtils.toString(TypeUtils.java:1714)
    at org.apache.commons.lang3.reflect.TypeUtils.appendAllTo(TypeUtils.java:302)
    at org.apache.commons.lang3.reflect.TypeUtils.typeVariableToString(TypeUtils.java:1789)
     * }
     * </pre>
     */
    @Test
    void test_LANG_1698() {
        final ParameterizedType comparing = (ParameterizedType) Arrays.stream(Comparator.class.getDeclaredMethods())
                .filter(k -> k.getName().equals("comparing")).findFirst()
                .orElse(Comparator.class.getDeclaredMethods()[0]).getGenericParameterTypes()[0];
        final String typeName = TypeUtils
                .parameterize((Class<?>) comparing.getRawType(), comparing.getActualTypeArguments()).getTypeName();
        assertEquals("java.util.function.Function<? super T, ? extends U>", typeName);
    }

    /**
     * Tests that a parameterized type with a nested generic argument is correctly
     * evaluated for assignability to a wildcard lower-bounded type.
     *
     * @see <a href="https://issues.apache.org/jira/browse/LANG-1700">LANG-1700</a>
     */
    @Test
    public void test_LANG_1700() {
        final ParameterizedType from = TypeUtils.parameterize(LexOrdering.class, MyNonTransientException.class);
        // MyComparator<? super MyNonTransientException>
        final ParameterizedType to = TypeUtils.parameterize(MyComparator.class,
                TypeUtils.wildcardType().withLowerBounds(MyNonTransientException.class).build());
        // This is MyComparator<Iterable<MyNonTransientException>>
        // It should NOT be assignable to MyComparator<? super MyNonTransientException>
        // because Iterable<MyNonTransientException> is NOT a supertype of MyNonTransientException
        assertFalse(TypeUtils.isAssignable(from, to),
                () -> String.format("Type %s should not be assignable to %s", TypeUtils.toString(from), TypeUtils.toString(to)));
    }

    @Test
    void test_LANG_1702() throws NoSuchMethodException, SecurityException {
        final Type type = TypeUtilsTest.class.getDeclaredMethod("aMethod").getGenericReturnType();

        // any map will do
        final Map<TypeVariable<?>, Type> typeArguments = Collections.emptyMap();

        // this fails with a stack overflow
        final Type unrolledType = TypeUtils.unrollVariables(typeArguments, type);
    }

    @Test
    void testBoundedGenericArrayTypeToString() {
        final TypeVariable<?> t = DependentBounds.class.getTypeParameters()[0];
        final GenericArrayType gat = TypeUtils.genericArrayType(t);
        assertEquals("T[]", TypeUtils.toString(gat));
    }

    @Test
    void testBoundedParameterizedTypeArgumentToString() {
        final TypeVariable<?> t = DependentBounds.class.getTypeParameters()[0];
        final ParameterizedType pt = TypeUtils.parameterize(List.class, t);
        assertEquals("java.util.List<T>", TypeUtils.toString(pt));
    }

    @Test
    void testContainsTypeVariables() throws NoSuchMethodException {
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m0").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m1").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m2").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m3").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m4").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m5").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m6").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m7").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m8").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m9").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m10").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m11").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m12").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m13").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test1.class.getMethod("m14").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m15").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m16").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test1.class.getMethod("m17").getGenericReturnType()));
    }

    @Test
    void testContainsTypeVariablesCyclicOwnerType() {
        // LANG-1836: a (custom) ParameterizedType that is its own owner must not cause a StackOverflowError.
        final ParameterizedType[] self = new ParameterizedType[1];
        self[0] = new ParameterizedType() {

            @Override
            public Type[] getActualTypeArguments() {
                return new Type[0];
            }

            @Override
            public Type getOwnerType() {
                return self[0];
            }

            @Override
            public Type getRawType() {
                return Outer.Inner.class;
            }
        };
        assertFalse(TypeUtils.containsTypeVariables(self[0]));
    }

    @Test
    void testContainsTypeVariablesMultiBoundWildcard() {
        final TypeVariable<?> t = getClass().getTypeParameters()[0];
        final WildcardType wtUpper = TypeUtils.wildcardType().withUpperBounds(Integer.class, t).build();
        assertTrue(TypeUtils.containsTypeVariables(wtUpper));
        final WildcardType wtLower = TypeUtils.wildcardType().withLowerBounds(Integer.class, t).build();
        assertTrue(TypeUtils.containsTypeVariables(wtLower));
        final WildcardType wtNone = TypeUtils.wildcardType().withUpperBounds(Integer.class, String.class).build();
        assertFalse(TypeUtils.containsTypeVariables(wtNone));
    }

    @Test
    void testContainsTypeVariablesMultiLevelOwnerType() throws NoSuchFieldException {
        final Type type = Outer.InnerU.class.getDeclaredField("deep").getGenericType();
        assertTrue(TypeUtils.containsTypeVariables(type));
        final Type outer = TypeUtils.parameterize(Outer.class, String.class);
        final Type inner = TypeUtils.parameterizeWithOwner(outer, Outer.InnerU.class, Integer.class);
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.parameterizeWithOwner(inner, Outer.InnerU.Deep.class, String.class)));
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final TypeVariable<?> u = Outer.InnerU.class.getTypeParameters()[0];
        final Type variableOuter = TypeUtils.parameterize(Outer.class, t);
        final Type outerOnly = TypeUtils.parameterizeWithOwner(variableOuter, Outer.InnerU.class, Integer.class);
        assertTrue(TypeUtils.containsTypeVariables(TypeUtils.parameterizeWithOwner(outerOnly, Outer.InnerU.Deep.class, String.class)));
        final Type innerOnly = TypeUtils.parameterizeWithOwner(outer, Outer.InnerU.class, u);
        assertTrue(TypeUtils.containsTypeVariables(TypeUtils.parameterizeWithOwner(innerOnly, Outer.InnerU.Deep.class, String.class)));
    }

    @Test
    void testContainsTypeVariablesMutuallyReferencingTypeArguments() {
        // LANG-1836
        final CyclicParameterizedType a = new CyclicParameterizedType(List.class);
        final CyclicParameterizedType b = new CyclicParameterizedType(List.class);
        a.setTypeArguments(b);
        b.setTypeArguments(a);
        assertFalse(TypeUtils.containsTypeVariables(a));
        assertFalse(TypeUtils.containsTypeVariables(b));
    }

    @Test
    void testContainsTypeVariablesOwnerType() throws NoSuchFieldException {
        // LANG-1836: Outer<T>.Inner
        assertTrue(TypeUtils.containsTypeVariables(Outer.class.getDeclaredField("inner").getGenericType()));
        // Outer<T>.InnerU<Integer>
        assertTrue(TypeUtils.containsTypeVariables(Outer.class.getDeclaredField("innerUInteger").getGenericType()));
        // Outer<String>.Inner
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.parameterizeWithOwner(TypeUtils.parameterize(Outer.class, String.class), Outer.Inner.class)));
        // Map.Entry<String, Integer>: the owner is the raw Map.class, which declares type parameters but binds none.
        assertFalse(TypeUtils.containsTypeVariables(TypeUtils.parameterizeWithOwner(Map.class, Map.Entry.class, String.class, Integer.class)));
    }

    @Test
    void testContainsTypeVariablesPr437() throws Exception {
        abstract class Test2<G> {
            public abstract Object m0();
            public abstract String[] m1();
            public abstract <K, V> Map<? extends K, V[]> m10();
            public abstract <K, V> Map<? extends K, List<V[]>> m11();
            public abstract List m12();
            public abstract Map m13();
            public abstract Properties m14();
            public abstract G m15();
            public abstract List<G> m16();
            public abstract Enum m17();
            public abstract <E> E[] m2();
            public abstract <E> List<? extends E> m3();
            public abstract <E extends Enum<E>> List<? extends Enum<E>> m4();
            public abstract List<? extends Enum<?>> m5();
            public abstract List<? super Enum<?>> m6();
            public abstract List<?> m7();
            public abstract Map<? extends Enum<?>, ? super Enum<?>> m8();
            public abstract <K, V> Map<? extends K, ? super V[]> m9();
        }

        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m0").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m1").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m2").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m3").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m4").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m5").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m6").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m7").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m8").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m9").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m10").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m11").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m12").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m13").getGenericReturnType()));
        assertFalse(TypeUtils.containsTypeVariables(Test2.class.getMethod("m14").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m15").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m16").getGenericReturnType()));
        assertTrue(TypeUtils.containsTypeVariables(Test2.class.getMethod("m17").getGenericReturnType()));
    }

    @Test
    void testContainsTypeVariablesSelfOwnedTypeWithStructuralHashCode() {
        // LANG-1836: detecting the cycle must not call hashCode(), which would follow the owner again.
        final CyclicParameterizedType self = new CyclicParameterizedType(Outer.Inner.class);
        self.setOwnerType(self);
        assertFalse(TypeUtils.containsTypeVariables(self));
    }

    @Test
    void testContainsTypeVariablesSelfReferencingTypeArgument() {
        // LANG-1836: a (custom) ParameterizedType that is its own type argument must not cause a StackOverflowError.
        final CyclicParameterizedType self = new CyclicParameterizedType(List.class);
        self.setTypeArguments(self);
        assertFalse(TypeUtils.containsTypeVariables(self));
    }

    @Test
    void testContainsTypeVariablesSelfReferencingTypeArgumentBesideVariable() {
        // LANG-1836: cutting the cycle must not hide a variable that is found elsewhere.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final CyclicParameterizedType self = new CyclicParameterizedType(Map.class);
        self.setTypeArguments(self, t);
        assertTrue(TypeUtils.containsTypeVariables(self));
    }

    @Test
    void testCyclicGenericArrayTypeToString() {
        final GenericArrayType[] holder = new GenericArrayType[1];
        final GenericArrayType cyclicType = () -> holder[0];
        holder[0] = cyclicType;
        assertEquals("(cycle)[]", TypeUtils.toString(cyclicType));
    }

    @Test
    void testCyclicOwnerParameterizedTypeToString() {
        final ParameterizedType[] holder = new ParameterizedType[1];
        final ParameterizedType cyclicOwnerType = new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return ArrayUtils.EMPTY_TYPE_ARRAY;
            }

            @Override
            public Type getOwnerType() {
                return holder[0];
            }

            @Override
            public Type getRawType() {
                return List.class;
            }
        };
        holder[0] = cyclicOwnerType;
        assertEquals("List(cycle).List", TypeUtils.toString(cyclicOwnerType));

        final ParameterizedType[] holderA = new ParameterizedType[1];
        final ParameterizedType[] holderB = new ParameterizedType[1];
        final ParameterizedType typeA = new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return ArrayUtils.EMPTY_TYPE_ARRAY;
            }

            @Override
            public Type getOwnerType() {
                return holderB[0];
            }

            @Override
            public Type getRawType() {
                return Map.class;
            }
        };
        final ParameterizedType typeB = new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return ArrayUtils.EMPTY_TYPE_ARRAY;
            }

            @Override
            public Type getOwnerType() {
                return holderA[0];
            }

            @Override
            public Type getRawType() {
                return Set.class;
            }
        };
        holderA[0] = typeA;
        holderB[0] = typeB;
        assertEquals("Map(cycle).Set.Map", TypeUtils.toString(typeA));
    }

    @Test
    void testCyclicParameterizedTypeToString() {
        final ParameterizedType[] holder = new ParameterizedType[1];
        final ParameterizedType cyclicType = new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return new Type[] { holder[0] };
            }

            @Override
            public Type getOwnerType() {
                return null;
            }

            @Override
            public Type getRawType() {
                return List.class;
            }
        };
        holder[0] = cyclicType;
        assertEquals("java.util.List<List(cycle)>", TypeUtils.toString(cyclicType));
    }

    @Test
    void testCyclicWildcardTypeToString() {
        final WildcardType[] holder = new WildcardType[1];
        final WildcardType cyclicWildcard = new WildcardType() {
            @Override
            public Type[] getLowerBounds() {
                return ArrayUtils.EMPTY_TYPE_ARRAY;
            }

            @Override
            public Type[] getUpperBounds() {
                return new Type[] { holder[0] };
            }
        };
        holder[0] = cyclicWildcard;
        assertEquals("? extends ? (cycle)", TypeUtils.toString(cyclicWildcard));
    }

    @Test
    void testDependentBoundsClassAndTypeParametersToString() {
        assertEquals("org.apache.commons.lang3.reflect.DependentBounds<T extends java.lang.Number, S extends T>",
                TypeUtils.toString(DependentBounds.class));
        assertEquals("T extends java.lang.Number",
                TypeUtils.toString(DependentBounds.class.getTypeParameters()[0]));
        assertEquals("S extends T",
                TypeUtils.toString(DependentBounds.class.getTypeParameters()[1]));
    }

    @Test
    void testDeprecatedConstructor() {
        assertNotNull(new TypeUtils().toString());
    }

    @Test
    void testDetermineTypeArguments() throws NoSuchFieldException {
        final ParameterizedType iterableType = (ParameterizedType) getClass().getField("iterable").getGenericType();
        assertNull(TypeUtils.determineTypeArguments(Object.class, iterableType));
        final Map<TypeVariable<?>, Type> typeVarAssigns = TypeUtils.determineTypeArguments(TreeSet.class, iterableType);
        final TypeVariable<?> treeSetTypeVar = TreeSet.class.getTypeParameters()[0];
        assertTrue(typeVarAssigns.containsKey(treeSetTypeVar));
        assertEquals(iterableType.getActualTypeArguments()[0], typeVarAssigns.get(treeSetTypeVar));
        assertNullPointerException(() -> TypeUtils.determineTypeArguments(TreeSet.class, null));
        assertNullPointerException(() -> TypeUtils.determineTypeArguments(null, iterableType));
    }

    @Test
    void testEquals() throws NoSuchFieldException {
        final Type expected = getClass().getField("intWildcardComparable").getGenericType();
        final GenericArrayType gat1 = TypeUtils
                .genericArrayType(TypeUtils.parameterize(Comparable.class, TypeUtils.wildcardType().withUpperBounds(Integer.class).build()));
        final GenericArrayType gat2 = TypeUtils
                .genericArrayType(TypeUtils.parameterize(Comparable.class, TypeUtils.wildcardType().withUpperBounds(Integer.class).build()));
        assertTrue(TypeUtils.equals(gat1, gat1));
        assertTrue(TypeUtils.equals(gat1, gat2));
        assertFalse(TypeUtils.equals(gat1, null));
        assertFalse(TypeUtils.equals(null, gat1));
    }

    @Test
    void testGClassToString() {
        assertEquals("org.apache.commons.lang3.reflect.AClass.GClass<T extends org.apache.commons.lang3.reflect.AClass.BClass<? extends T> "
                + "& org.apache.commons.lang3.reflect.AClass.AInterface<org.apache.commons.lang3.reflect.AClass.AInterface<? super T>>>",
                TypeUtils.toString(AClass.GClass.class));
    }

    @SuppressWarnings("unlikely-arg-type")
    @Test
    void testGenericArrayType() throws NoSuchFieldException {
        final Type expected = getClass().getField("intWildcardComparable").getGenericType();
        final GenericArrayType actual = TypeUtils
                .genericArrayType(TypeUtils.parameterize(Comparable.class, TypeUtils.wildcardType().withUpperBounds(Integer.class).build()));
        assertTrue(TypeUtils.equals(expected, actual));
        assertEquals("java.lang.Comparable<? extends java.lang.Integer>[]", actual.toString());
        assertEquals(expected.hashCode(), actual.hashCode());
        assertEquals(actual, actual);
        assertFalse(actual.equals(null));
        assertFalse(actual.equals(TypeUtils.wildcardType().build()));
    }

    @Test
    void testGetArrayComponentType() throws NoSuchFieldException {
        final Type rawListType = GenericTypeHolder.class.getDeclaredField("rawList").getGenericType();
        final Type objectListType = GenericTypeHolder.class.getDeclaredField("objectList").getGenericType();
        final Type unboundListType = GenericTypeHolder.class.getDeclaredField("unboundList").getGenericType();
        final Type superObjectListType = GenericTypeHolder.class.getDeclaredField("superObjectList").getGenericType();
        final Type stringListType = GenericTypeHolder.class.getDeclaredField("stringList").getGenericType();
        final Type subStringListType = GenericTypeHolder.class.getDeclaredField("subStringList").getGenericType();
        final Type superStringListType = GenericTypeHolder.class.getDeclaredField("superStringList").getGenericType();

        assertNull(TypeUtils.getArrayComponentType(rawListType));
        assertNull(TypeUtils.getArrayComponentType(objectListType));
        assertNull(TypeUtils.getArrayComponentType(unboundListType));
        assertNull(TypeUtils.getArrayComponentType(superObjectListType));
        assertNull(TypeUtils.getArrayComponentType(stringListType));
        assertNull(TypeUtils.getArrayComponentType(subStringListType));
        assertNull(TypeUtils.getArrayComponentType(superStringListType));

        final Type rawListTypeArray = GenericTypeHolder.class.getDeclaredField("rawListArray").getGenericType();
        final Type objectListTypeArray = GenericTypeHolder.class.getDeclaredField("objectListArray").getGenericType();
        final Type unboundListTypeArray = GenericTypeHolder.class.getDeclaredField("unboundListArray").getGenericType();
        final Type superObjectListTypeArray = GenericTypeHolder.class.getDeclaredField("superObjectListArray").getGenericType();
        final Type stringListTypeArray = GenericTypeHolder.class.getDeclaredField("stringListArray").getGenericType();
        final Type subStringListTypeArray = GenericTypeHolder.class.getDeclaredField("subStringListArray").getGenericType();
        final Type superStringListTypeArray = GenericTypeHolder.class.getDeclaredField("superStringListArray").getGenericType();

        assertEquals(rawListType, TypeUtils.getArrayComponentType(rawListTypeArray));
        assertEquals(objectListType, TypeUtils.getArrayComponentType(objectListTypeArray));
        assertEquals(unboundListType, TypeUtils.getArrayComponentType(unboundListTypeArray));
        assertEquals(superObjectListType, TypeUtils.getArrayComponentType(superObjectListTypeArray));
        assertEquals(stringListType, TypeUtils.getArrayComponentType(stringListTypeArray));
        assertEquals(subStringListType, TypeUtils.getArrayComponentType(subStringListTypeArray));
        assertEquals(superStringListType, TypeUtils.getArrayComponentType(superStringListTypeArray));
    }

    @Test
    void testGetPrimitiveArrayComponentType() {
        assertEquals(boolean.class, TypeUtils.getArrayComponentType(boolean[].class));
        assertEquals(byte.class, TypeUtils.getArrayComponentType(byte[].class));
        assertEquals(short.class, TypeUtils.getArrayComponentType(short[].class));
        assertEquals(int.class, TypeUtils.getArrayComponentType(int[].class));
        assertEquals(char.class, TypeUtils.getArrayComponentType(char[].class));
        assertEquals(long.class, TypeUtils.getArrayComponentType(long[].class));
        assertEquals(float.class, TypeUtils.getArrayComponentType(float[].class));
        assertEquals(double.class, TypeUtils.getArrayComponentType(double[].class));

        assertNull(TypeUtils.getArrayComponentType(boolean.class));
        assertNull(TypeUtils.getArrayComponentType(byte.class));
        assertNull(TypeUtils.getArrayComponentType(short.class));
        assertNull(TypeUtils.getArrayComponentType(int.class));
        assertNull(TypeUtils.getArrayComponentType(char.class));
        assertNull(TypeUtils.getArrayComponentType(long.class));
        assertNull(TypeUtils.getArrayComponentType(float.class));
        assertNull(TypeUtils.getArrayComponentType(double.class));
    }

    @Test
    void testGetRawType() throws NoSuchFieldException {
        final Type stringParentFieldType = GenericTypeHolder.class.getDeclaredField("stringParent").getGenericType();
        final Type integerParentFieldType = GenericTypeHolder.class.getDeclaredField("integerParent").getGenericType();
        final Type foosFieldType = GenericTypeHolder.class.getDeclaredField("foos").getGenericType();
        final Type genericParentT = GenericParent.class.getTypeParameters()[0];
        assertEquals(GenericParent.class, TypeUtils.getRawType(stringParentFieldType, null));
        assertEquals(GenericParent.class, TypeUtils.getRawType(integerParentFieldType, null));
        assertEquals(List.class, TypeUtils.getRawType(foosFieldType, null));
        assertEquals(String.class, TypeUtils.getRawType(genericParentT, StringParameterizedChild.class));
        assertEquals(String.class, TypeUtils.getRawType(genericParentT, stringParentFieldType));
        assertEquals(Foo.class, TypeUtils.getRawType(Iterable.class.getTypeParameters()[0], foosFieldType));
        assertEquals(Foo.class, TypeUtils.getRawType(List.class.getTypeParameters()[0], foosFieldType));
        assertNull(TypeUtils.getRawType(genericParentT, GenericParent.class));
        assertEquals(GenericParent[].class, TypeUtils.getRawType(GenericTypeHolder.class.getDeclaredField("barParents").getGenericType(), null));
    }

    /**
     * Tests https://issues.apache.org/jira/browse/LANG-1697
     */
    @Test
    void testGetRawType_LANG_1697() {
        assertEquals(int[].class, TypeUtils.getRawType(TypeUtils.genericArrayType(Integer.TYPE), Integer.TYPE));
        // LANG-1697:
        assertNull(TypeUtils.getRawType(TypeUtils.genericArrayType(TypeUtils.WILDCARD_ALL), null));
        // TODO: Is this correct?
        assertNull(TypeUtils.getRawType(TypeUtils.genericArrayType(TypeUtils.WILDCARD_ALL), TypeUtils.WILDCARD_ALL));
        // TODO: Is this correct?
        assertNull(TypeUtils.getRawType(TypeUtils.genericArrayType(TypeUtils.WILDCARD_ALL), Integer.TYPE));
    }

    @Test
    void testGetTypeArguments() {
        Map<TypeVariable<?>, Type> typeVarAssigns;
        TypeVariable<?> treeSetTypeVar;
        Type typeArg;

        typeVarAssigns = TypeUtils.getTypeArguments(Integer.class, Comparable.class);
        treeSetTypeVar = Comparable.class.getTypeParameters()[0];
        assertTrue(typeVarAssigns.containsKey(treeSetTypeVar),
                "Type var assigns for Comparable from Integer: " + typeVarAssigns);
        typeArg = typeVarAssigns.get(treeSetTypeVar);
        assertEquals(Integer.class, typeVarAssigns.get(treeSetTypeVar),
                "Type argument of Comparable from Integer: " + typeArg);

        typeVarAssigns = TypeUtils.getTypeArguments(int.class, Comparable.class);
        treeSetTypeVar = Comparable.class.getTypeParameters()[0];
        assertTrue(typeVarAssigns.containsKey(treeSetTypeVar),
                "Type var assigns for Comparable from int: " + typeVarAssigns);
        typeArg = typeVarAssigns.get(treeSetTypeVar);
        assertEquals(Integer.class, typeVarAssigns.get(treeSetTypeVar),
                "Type argument of Comparable from int: " + typeArg);

        final Collection<Integer> col = Collections.emptyList();
        typeVarAssigns = TypeUtils.getTypeArguments(List.class, Collection.class);
        treeSetTypeVar = Comparable.class.getTypeParameters()[0];
        assertFalse(typeVarAssigns.containsKey(treeSetTypeVar),
                "Type var assigns for Collection from List: " + typeVarAssigns);

        typeVarAssigns = TypeUtils.getTypeArguments(AAAClass.BBBClass.class, AAClass.BBClass.class);
        assertEquals(2, typeVarAssigns.size());
        assertEquals(String.class, typeVarAssigns.get(AAClass.class.getTypeParameters()[0]));
        assertEquals(String.class, typeVarAssigns.get(AAClass.BBClass.class.getTypeParameters()[0]));

        typeVarAssigns = TypeUtils.getTypeArguments(Other.class, This.class);
        assertEquals(2, typeVarAssigns.size());
        assertEquals(String.class, typeVarAssigns.get(This.class.getTypeParameters()[0]));
        assertEquals(Other.class.getTypeParameters()[0], typeVarAssigns.get(This.class.getTypeParameters()[1]));

        typeVarAssigns = TypeUtils.getTypeArguments(And.class, This.class);
        assertEquals(2, typeVarAssigns.size());
        assertEquals(Number.class, typeVarAssigns.get(This.class.getTypeParameters()[0]));
        assertEquals(Number.class, typeVarAssigns.get(This.class.getTypeParameters()[1]));

        typeVarAssigns = TypeUtils.getTypeArguments(Thing.class, Other.class);
        assertEquals(2, typeVarAssigns.size());
        assertEquals(getClass().getTypeParameters()[0], typeVarAssigns.get(getClass().getTypeParameters()[0]));
        assertEquals(getClass().getTypeParameters()[0], typeVarAssigns.get(Other.class.getTypeParameters()[0]));
    }

    @Test
    void testGetTypeArgumentsInheritedGenericArray() {
        final TypeVariable<?> variable = ClassWildcardTypes.class.getTypeParameters()[1];
        final TypeVariable<?> listVariable = List.class.getTypeParameters()[0];
        final Type source = TypeUtils.parameterize(ArrayValues.class, variable);
        final Map<TypeVariable<?>, Type> arguments = TypeUtils.getTypeArguments(source, List.class);
        final GenericArrayType array = (GenericArrayType) arguments.get(listVariable);
        assertSame(variable, array.getGenericComponentType());
        assertEquals(String[].class,
                TypeUtils.getTypeArguments(TypeUtils.parameterize(ArrayValues.class, String.class), List.class).get(listVariable));
    }

    @Test
    void testGetTypeArgumentsInheritedWildcardBounds() {
        final TypeVariable<?> variable = ClassWildcardTypes.class.getTypeParameters()[1];
        final TypeVariable<?> listVariable = List.class.getTypeParameters()[0];
        final WildcardType upper = TypeUtils.wildcardType().withUpperBounds(variable).build();
        final WildcardType lower = TypeUtils.wildcardType().withLowerBounds(variable).build();
        final WildcardType inheritedUpper = (WildcardType) TypeUtils.getTypeArguments(TypeUtils.parameterize(ArrayList.class, upper), List.class)
                .get(listVariable);
        final WildcardType inheritedLower = (WildcardType) TypeUtils.getTypeArguments(TypeUtils.parameterize(ArrayList.class, lower), List.class)
                .get(listVariable);
        assertArrayEquals(new Type[] { variable }, inheritedUpper.getUpperBounds());
        assertArrayEquals(new Type[0], inheritedUpper.getLowerBounds());
        assertArrayEquals(new Type[] { Object.class }, inheritedLower.getUpperBounds());
        assertArrayEquals(new Type[] { variable }, inheritedLower.getLowerBounds());
    }

    @ParameterizedTest
    @MethodSource
    void testHashCodeMatchesJdk(final String fieldName, final Type built) throws NoSuchFieldException {
        final Type jdk = HashCodeTypes.class.getDeclaredField(fieldName).getGenericType();
        assertEquals(jdk, built);
        assertEquals(built, jdk);

        final Map<Type, String> jdkMap = new HashMap<>();
        jdkMap.put(jdk, "value");
        final Map<Type, String> builtMap = new HashMap<>();
        builtMap.put(built, "value");
        final Set<Type> jdkSet = new HashSet<>();
        jdkSet.add(jdk);
        final Set<Type> builtSet = new HashSet<>();
        builtSet.add(built);
        assertEquals(jdk.hashCode(), built.hashCode());
        assertEquals("value", jdkMap.get(built));
        assertEquals("value", builtMap.get(jdk));
        assertTrue(jdkSet.contains(built));
        assertTrue(builtSet.contains(jdk));
    }

    @Test
    void testInterfaceBoundPreserved() {
        assertEquals("T extends java.util.List<java.lang.String>",
                TypeUtils.toString(InterfaceBound.class.getTypeParameters()[0]));
    }

    @Test
    void testIsArrayGenericTypes() throws NoSuchFieldException {
        final Type rawListType = GenericTypeHolder.class.getDeclaredField("rawList").getGenericType();
        final Type objectListType = GenericTypeHolder.class.getDeclaredField("objectList").getGenericType();
        final Type unboundListType = GenericTypeHolder.class.getDeclaredField("unboundList").getGenericType();
        final Type superObjectListType = GenericTypeHolder.class.getDeclaredField("superObjectList").getGenericType();
        final Type stringListType = GenericTypeHolder.class.getDeclaredField("stringList").getGenericType();
        final Type subStringListType = GenericTypeHolder.class.getDeclaredField("subStringList").getGenericType();
        final Type superStringListType = GenericTypeHolder.class.getDeclaredField("superStringList").getGenericType();

        assertFalse(TypeUtils.isArrayType(rawListType));
        assertFalse(TypeUtils.isArrayType(objectListType));
        assertFalse(TypeUtils.isArrayType(unboundListType));
        assertFalse(TypeUtils.isArrayType(superObjectListType));
        assertFalse(TypeUtils.isArrayType(stringListType));
        assertFalse(TypeUtils.isArrayType(subStringListType));
        assertFalse(TypeUtils.isArrayType(superStringListType));

        final Type rawListTypeArray = GenericTypeHolder.class.getDeclaredField("rawListArray").getGenericType();
        final Type objectListTypeArray = GenericTypeHolder.class.getDeclaredField("objectListArray").getGenericType();
        final Type unboundListTypeArray = GenericTypeHolder.class.getDeclaredField("unboundListArray").getGenericType();
        final Type superObjectListTypeArray = GenericTypeHolder.class.getDeclaredField("superObjectListArray").getGenericType();
        final Type stringListTypeArray = GenericTypeHolder.class.getDeclaredField("stringListArray").getGenericType();
        final Type subStringListTypeArray = GenericTypeHolder.class.getDeclaredField("subStringListArray").getGenericType();
        final Type superStringListTypeArray = GenericTypeHolder.class.getDeclaredField("superStringListArray").getGenericType();

        assertTrue(TypeUtils.isArrayType(rawListTypeArray));
        assertTrue(TypeUtils.isArrayType(objectListTypeArray));
        assertTrue(TypeUtils.isArrayType(unboundListTypeArray));
        assertTrue(TypeUtils.isArrayType(superObjectListTypeArray));
        assertTrue(TypeUtils.isArrayType(stringListTypeArray));
        assertTrue(TypeUtils.isArrayType(subStringListTypeArray));
        assertTrue(TypeUtils.isArrayType(superStringListTypeArray));
    }

    @Test
    void testIsArrayTypeClasses() {
        assertTrue(TypeUtils.isArrayType(boolean[].class));
        assertTrue(TypeUtils.isArrayType(byte[].class));
        assertTrue(TypeUtils.isArrayType(short[].class));
        assertTrue(TypeUtils.isArrayType(int[].class));
        assertTrue(TypeUtils.isArrayType(char[].class));
        assertTrue(TypeUtils.isArrayType(long[].class));
        assertTrue(TypeUtils.isArrayType(float[].class));
        assertTrue(TypeUtils.isArrayType(double[].class));
        assertTrue(TypeUtils.isArrayType(Object[].class));
        assertTrue(TypeUtils.isArrayType(String[].class));

        assertFalse(TypeUtils.isArrayType(boolean.class));
        assertFalse(TypeUtils.isArrayType(byte.class));
        assertFalse(TypeUtils.isArrayType(short.class));
        assertFalse(TypeUtils.isArrayType(int.class));
        assertFalse(TypeUtils.isArrayType(char.class));
        assertFalse(TypeUtils.isArrayType(long.class));
        assertFalse(TypeUtils.isArrayType(float.class));
        assertFalse(TypeUtils.isArrayType(double.class));
        assertFalse(TypeUtils.isArrayType(Object.class));
        assertFalse(TypeUtils.isArrayType(String.class));
    }

    @ParameterizedTest(name = "{0} -> {1}: {2}")
    @MethodSource
    void testIsAssignable_ClassWildcardBounds(final String fromField, final String toField, final boolean expected) throws NoSuchFieldException {
        final Type from = ClassWildcardTypes.class.getDeclaredField(fromField).getGenericType();
        final Type to = ClassWildcardTypes.class.getDeclaredField(toField).getGenericType();
        assertEquals(expected, TypeUtils.isAssignable(from, to), () -> from + " -> " + to);
    }

    @Test
    void testIsAssignable_ClassWithBoundedWildcardObject() {
        final Type to = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(Object.class).build());
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, String.class), to),
                "Class<String> should be assignable to Class<? extends Object>");
    }

    @Test
    void testIsAssignable_ClassWithLowerBoundedWildcard() {
        final Type to = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withLowerBounds(Integer.class).build());
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, Number.class), to),
                "Class<Number> should be assignable to Class<? super Integer>");
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withLowerBounds(Number.class).build()), to),
                "Class<? super Number> should be assignable to Class<? super Integer>");
        assertFalse(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, String.class), to),
                "Class<String> should not be assignable to Class<? super Integer>");
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, List.class),
                TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withLowerBounds(TypeUtils.parameterize(List.class, String.class)).build())),
                "Class<List> should be assignable to Class<? super List<String>>");
    }

    @Test
    void testIsAssignable_ClassWithParameterizedType1() {
        final ParameterizedType topre1 = TypeUtils.parameterize(TestIF.class, TypeUtils.wildcardType().build());
        final Type to1 = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(topre1).build());
        final Type from1 = TypeUtils.parameterize(Class.class, TestIF.class);
        assertFalse(TypeUtils.isAssignable(from1, to1), "Class<TestIF> should not be assignable to Class<? extends TestIF<?>>");
    }

    @Test
    void testIsAssignable_ClassWithParameterizedType2() {
        final ParameterizedType topre2 = TypeUtils.parameterize(TestIF.class, TypeUtils.wildcardType().build());
        final Type to2 = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(topre2).build());
        final Type from2 = TypeUtils.parameterize(Class.class, TestImpl.class);
        assertFalse(TypeUtils.isAssignable(from2, to2), "Class<TestImpl> should not be assignable to Class<? extends TestIF<?>>");
    }

    @Test
    void testIsAssignable_ClassWithParameterizedType3() {
        final ParameterizedType topre3 = TypeUtils.parameterize(TestIF.class, Number.class);
        final Type to3 = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(topre3).build());
        final Type from3 = TypeUtils.parameterize(Class.class, TestImpl2.class);
        assertFalse(TypeUtils.isAssignable(from3, to3), "Class<TestImpl2> should not be assignable to Class<? extends TestIF<Number>>");
    }

    @Test
    void testIsAssignable_ClassWithParameterizedWildcardBound() {
        final Type to = TypeUtils.parameterize(Class.class,
                TypeUtils.wildcardType().withUpperBounds(TypeUtils.parameterize(Collection.class, TypeUtils.wildcardType().build())).build());
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, TypeUtils.parameterize(List.class, String.class)), to),
                "Class<List<String>> should be assignable to Class<? extends Collection<?>>");
        assertFalse(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, TypeUtils.parameterize(List.class, String.class)),
                TypeUtils.parameterize(Class.class, TypeUtils.wildcardType()
                        .withUpperBounds(TypeUtils.parameterize(Collection.class, Integer.class)).build())),
                "Class<List<String>> should not be assignable to Class<? extends Collection<Integer>>");
    }

    @Test
    void testIsAssignable_ClassWithUnboundedWildcard() {
        final Type to = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().build());
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, Integer.class), to),
                "Class<Integer> should be assignable to Class<?>");
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, Class.class.getTypeParameters()[0]), to),
                "Class<T> should be assignable to Class<?>");
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, List.class.getTypeParameters()[0]), to),
                "Class<E> should be assignable to Class<?> when E is declared by another class");
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(Number.class).build()), to),
                "Class<? extends Number> should be assignable to Class<?>");
        assertTrue(TypeUtils.isAssignable(Class.class, to), "raw Class should be assignable to Class<?>");
        assertFalse(TypeUtils.isAssignable(to, TypeUtils.parameterize(Class.class, Integer.class)),
                "Class<?> should not be assignable to Class<Integer>");
    }

    @Test
    void testIsAssignable_ClassWithUpperBoundedWildcard() {
        final Type to = TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(Number.class).build());
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, Integer.class), to),
                "Class<Integer> should be assignable to Class<? extends Number>");
        assertTrue(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, TypeUtils.wildcardType().withUpperBounds(Integer.class).build()), to),
                "Class<? extends Integer> should be assignable to Class<? extends Number>");
        assertFalse(TypeUtils.isAssignable(TypeUtils.parameterize(Class.class, String.class), to),
                "Class<String> should not be assignable to Class<? extends Number>");
    }

    @Test
    public void testIsAssignable_HiddenMapLogic() {
        class Container<T> {
        }
        class StringContainer extends Container<String> {
        }
        final Type stringContainerType = StringContainer.class.getGenericSuperclass();
        assertTrue(TypeUtils.isAssignable(StringContainer.class, Container.class));
    }

    @Test
    public void testIsAssignable_Type_TypeVariable_Map_Public() throws Exception {
        class Container<T> {
        }
        final TypeVariable<?> typeVarT = Container.class.getTypeParameters()[0];
        final boolean result = TypeUtils.isAssignable(Integer.class, typeVarT);
        assertFalse(result);
    }

    @Test
    void testIsAssignable_UnrelatedTypeVariables() {
        final TypeVariable<?>[] variables = ClassWildcardTypes.class.getTypeParameters();
        assertFalse(TypeUtils.isAssignable(variables[0], variables[1]));
        assertFalse(TypeUtils.isAssignable(variables[1], variables[0]));
        assertFalse(TypeUtils.isAssignable(variables[1], variables[3]));
        assertTrue(TypeUtils.isAssignable(variables[3], variables[1]));
    }

    @Test
    void testIsAssignableClasses() {
        assertTrue(TypeUtils.isAssignable(char.class, double.class));
        assertTrue(TypeUtils.isAssignable(byte.class, double.class));
        assertTrue(TypeUtils.isAssignable(short.class, double.class));
        assertTrue(TypeUtils.isAssignable(int.class, double.class));
        assertTrue(TypeUtils.isAssignable(long.class, double.class));
        assertTrue(TypeUtils.isAssignable(float.class, double.class));

        assertTrue(TypeUtils.isAssignable(int.class, long.class));
        assertTrue(TypeUtils.isAssignable(Integer.class, long.class));
        assertFalse(TypeUtils.isAssignable(int.class, Long.class));
        assertFalse(TypeUtils.isAssignable(Integer.class, Long.class));
        assertTrue(TypeUtils.isAssignable(Integer.class, int.class));
        assertTrue(TypeUtils.isAssignable(int.class, Integer.class));
        assertTrue(TypeUtils.isAssignable(int.class, Number.class));
        assertTrue(TypeUtils.isAssignable(int.class, Object.class));
        assertTrue(TypeUtils.isAssignable(int.class, Comparable.class));
        assertTrue(TypeUtils.isAssignable(int.class, Serializable.class));

        assertFalse(TypeUtils.isAssignable(int[].class, long[].class));
        assertFalse(TypeUtils.isAssignable(Integer[].class, int[].class));
        assertFalse(TypeUtils.isAssignable(int[].class, Object[].class));
        assertTrue(TypeUtils.isAssignable(Integer[].class, Object[].class));
    }

    @Test
    void testIsAssignableDirectClassHierarchy() throws NoSuchFieldException {
        final Type bClassType = AClass.class.getField("bClass").getGenericType(); // B is superclass
        final Type cClassType = AClass.class.getField("cClass").getGenericType(); // C subclass of B
        final Type dClassType = AClass.class.getField("dClass").getGenericType(); // D subclass of C
        final Type eClassType = AClass.class.getField("eClass").getGenericType(); // E subclass of D
        final Type fClassType = AClass.class.getField("fClass").getGenericType(); // F subclass of E

        assertTrue(TypeUtils.isAssignable(cClassType, bClassType));
        assertTrue(TypeUtils.isAssignable(dClassType, bClassType));
        assertTrue(TypeUtils.isAssignable(eClassType, bClassType));
        assertTrue(TypeUtils.isAssignable(fClassType, bClassType));

        assertTrue(TypeUtils.isAssignable(dClassType, cClassType));
        assertTrue(TypeUtils.isAssignable(eClassType, cClassType));
        assertTrue(TypeUtils.isAssignable(fClassType, cClassType));

        assertTrue(TypeUtils.isAssignable(eClassType, dClassType));
        assertTrue(TypeUtils.isAssignable(fClassType, dClassType));

        assertTrue(TypeUtils.isAssignable(fClassType, eClassType));
    }

    @Test
    void testIsAssignableGenericArrayTypeToObject() {
        final Class<Constructor> rawClass = Constructor.class;
        final Class<Insets> typeArgClass = Insets.class;
        // Builds a ParameterizedType for Constructor<Insets>
        final ParameterizedType paramType = TypeUtils.parameterize(rawClass, typeArgClass);
        assertEquals(rawClass, paramType.getRawType());
        assertEquals(typeArgClass, paramType.getActualTypeArguments()[0]);

        assertTrue(Object.class.isAssignableFrom(paramType.getClass()));
        assertFalse(paramType.getClass().isAssignableFrom(Object.class));

        final Type testType = Object.class;
        assertTrue(TypeUtils.isAssignable(paramType, testType),
                () -> String.format("TypeUtils.isAssignable(%s, %s)", paramType, testType));
        assertFalse(TypeUtils.isAssignable(testType, paramType),
                () -> String.format("TypeUtils.isAssignable(%s, %s)", testType, paramType));
    }

    @Test
    void testIsAssignableGenericArrayTypeToParameterizedType() {
        final Class<Constructor> rawClass = Constructor.class;
        final Class<Insets> typeArgClass = Insets.class;
        // Builds a ParameterizedType for Constructor<Insets>
        final ParameterizedType paramType = TypeUtils.parameterize(rawClass, typeArgClass);
        assertEquals(rawClass, paramType.getRawType());
        assertEquals(typeArgClass, paramType.getActualTypeArguments()[0]);

        assertFalse(GenericArrayType.class.isAssignableFrom(paramType.getClass()));
        assertFalse(paramType.getClass().isAssignableFrom(GenericArrayType.class));

        final GenericArrayType testType = TypeUtils.genericArrayType(paramType);
        assertFalse(TypeUtils.isAssignable(paramType, testType),
                () -> String.format("TypeUtils.isAssignable(%s, %s)", paramType, testType));
        assertFalse(TypeUtils.isAssignable(testType, paramType),
                () -> String.format("TypeUtils.isAssignable(%s, %s)", testType, paramType));
    }

    @Test
    @Disabled("TODO")
    void testIsAssignableGenericArrayTypeToWildcardType() {
        final Class<Constructor> rawClass = Constructor.class;
        final Class<Insets> typeArgClass = Insets.class;
        // Builds a ParameterizedType for Constructor<Insets>
        final ParameterizedType paramType = TypeUtils.parameterize(rawClass, typeArgClass);
        assertEquals(rawClass, paramType.getRawType());
        assertEquals(typeArgClass, paramType.getActualTypeArguments()[0]);

        assertFalse(WildcardType.class.isAssignableFrom(paramType.getClass()));
        assertFalse(paramType.getClass().isAssignableFrom(WildcardType.class));

        final WildcardType testType = TypeUtils.WILDCARD_ALL;
        // TODO This test returns true unlike the test above.
        // Is this a bug in this test or in the main code?
        assertFalse(TypeUtils.isAssignable(paramType, testType),
                () -> String.format("TypeUtils.isAssignable(%s, %s)", paramType, testType));
        assertFalse(TypeUtils.isAssignable(testType, paramType),
                () -> String.format("TypeUtils.isAssignable(%s, %s)", testType, paramType));
    }

    @Test
    void testIsAssignableGenericClassHierarchy() throws NoSuchFieldException {
        /*
         *            <<This>>
         *      /      /     \     \
         * <<And>>   That   Other   Tester
         *      \   /         |
         *       The        Thing
         */
        final Type disType = getClass().getField("dis").getGenericType();       // This is superinterface
        final Type datType = getClass().getField("dat").getGenericType();       // That implements This
        final Type dat2Type = getClass().getField("dat2").getGenericType();
        final Type dat3Type = getClass().getField("dat3").getGenericType();
        final Type daType = getClass().getField("da").getGenericType();         // The extends That and implements And
        final Type uhderType = getClass().getField("uhder").getGenericType();   // Other implements This
        final Type dingType = getClass().getField("ding").getGenericType();     // Thing extends Other
        final Type testerType = getClass().getField("tester").getGenericType(); // Tester implements This
        final Type tester2Type = getClass().getField("tester2").getGenericType();

        assertTrue(TypeUtils.isAssignable(datType, disType));
        assertFalse(TypeUtils.isAssignable(daType, disType));
        assertTrue(TypeUtils.isAssignable(uhderType, disType));
        assertFalse(TypeUtils.isAssignable(dingType, disType));
        assertTrue(TypeUtils.isAssignable(testerType, disType));
        assertFalse(TypeUtils.isAssignable(tester2Type, disType));

        assertFalse(TypeUtils.isAssignable(dat2Type, datType));
        assertFalse(TypeUtils.isAssignable(datType, dat2Type));
        assertFalse(TypeUtils.isAssignable(dat3Type, datType));
    }

    @Test
    void testIsAssignableGenericComparableTypes() throws NoSuchFieldException {
        final Type intComparableType = getClass().getField("intComparable").getGenericType();
        assertTrue(TypeUtils.isAssignable(int.class, intComparableType));

        final Type longComparableType = getClass().getField("longComparable").getGenericType();
        assertFalse(TypeUtils.isAssignable(int.class, longComparableType));
        assertFalse(TypeUtils.isAssignable(Integer.class, longComparableType));

        final Type intComparableArrayType = getClass().getField("intWildcardComparable").getGenericType();
        assertTrue(TypeUtils.isAssignable(Integer[].class, intComparableArrayType));
    }

    @Test
    void testIsAssignableGenericListArrays() throws NoSuchFieldException {
        final Type rawListTypeArray = GenericTypeHolder.class.getDeclaredField("rawListArray").getGenericType();
        final Type objectListTypeArray = GenericTypeHolder.class.getDeclaredField("objectListArray").getGenericType();
        final Type unboundListTypeArray = GenericTypeHolder.class.getDeclaredField("unboundListArray").getGenericType();
        final Type superObjectListTypeArray = GenericTypeHolder.class.getDeclaredField("superObjectListArray").getGenericType();
        final Type stringListTypeArray = GenericTypeHolder.class.getDeclaredField("stringListArray").getGenericType();
        final Type subStringListTypeArray = GenericTypeHolder.class.getDeclaredField("subStringListArray").getGenericType();
        final Type superStringListTypeArray = GenericTypeHolder.class.getDeclaredField("superStringListArray").getGenericType();

        assertTrue(TypeUtils.isAssignable(rawListTypeArray, rawListTypeArray));
        assertTrue(TypeUtils.isAssignable(rawListTypeArray, objectListTypeArray));
        assertTrue(TypeUtils.isAssignable(objectListTypeArray, rawListTypeArray));
        assertTrue(TypeUtils.isAssignable(rawListTypeArray, unboundListTypeArray));
        assertTrue(TypeUtils.isAssignable(unboundListTypeArray, rawListTypeArray));
        assertTrue(TypeUtils.isAssignable(rawListTypeArray, superObjectListTypeArray));
        assertTrue(TypeUtils.isAssignable(superObjectListTypeArray, rawListTypeArray));
        assertTrue(TypeUtils.isAssignable(rawListTypeArray, stringListTypeArray));
        assertTrue(TypeUtils.isAssignable(stringListTypeArray, rawListTypeArray));
        assertTrue(TypeUtils.isAssignable(rawListTypeArray, subStringListTypeArray));
        assertTrue(TypeUtils.isAssignable(subStringListTypeArray, rawListTypeArray));
        assertTrue(TypeUtils.isAssignable(rawListTypeArray, superStringListTypeArray));
        assertTrue(TypeUtils.isAssignable(superStringListTypeArray, rawListTypeArray));

        assertTrue(TypeUtils.isAssignable(objectListTypeArray, objectListTypeArray));
        assertTrue(TypeUtils.isAssignable(objectListTypeArray, unboundListTypeArray));
        assertFalse(TypeUtils.isAssignable(unboundListTypeArray, objectListTypeArray));
        assertTrue(TypeUtils.isAssignable(objectListTypeArray, superObjectListTypeArray));
        assertFalse(TypeUtils.isAssignable(superObjectListTypeArray, objectListTypeArray));
        assertFalse(TypeUtils.isAssignable(objectListTypeArray, stringListTypeArray));
        assertFalse(TypeUtils.isAssignable(stringListTypeArray, objectListTypeArray));
        assertFalse(TypeUtils.isAssignable(objectListTypeArray, subStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(subStringListTypeArray, objectListTypeArray));
        assertTrue(TypeUtils.isAssignable(objectListTypeArray, superStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(superStringListTypeArray, objectListTypeArray));

        assertTrue(TypeUtils.isAssignable(unboundListTypeArray, unboundListTypeArray));
        assertFalse(TypeUtils.isAssignable(unboundListTypeArray, superObjectListTypeArray));
        assertTrue(TypeUtils.isAssignable(superObjectListTypeArray, unboundListTypeArray));
        assertFalse(TypeUtils.isAssignable(unboundListTypeArray, stringListTypeArray));
        assertTrue(TypeUtils.isAssignable(stringListTypeArray, unboundListTypeArray));
        assertFalse(TypeUtils.isAssignable(unboundListTypeArray, subStringListTypeArray));
        assertTrue(TypeUtils.isAssignable(subStringListTypeArray, unboundListTypeArray));
        assertFalse(TypeUtils.isAssignable(unboundListTypeArray, superStringListTypeArray));
        assertTrue(TypeUtils.isAssignable(superStringListTypeArray, unboundListTypeArray));

        assertTrue(TypeUtils.isAssignable(superObjectListTypeArray, superObjectListTypeArray));
        assertFalse(TypeUtils.isAssignable(superObjectListTypeArray, stringListTypeArray));
        assertFalse(TypeUtils.isAssignable(stringListTypeArray, superObjectListTypeArray));
        assertFalse(TypeUtils.isAssignable(superObjectListTypeArray, subStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(subStringListTypeArray, superObjectListTypeArray));
        assertTrue(TypeUtils.isAssignable(superObjectListTypeArray, superStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(superStringListTypeArray, superObjectListTypeArray));

        assertTrue(TypeUtils.isAssignable(stringListTypeArray, stringListTypeArray));
        assertTrue(TypeUtils.isAssignable(stringListTypeArray, subStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(subStringListTypeArray, stringListTypeArray));
        assertTrue(TypeUtils.isAssignable(stringListTypeArray, superStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(superStringListTypeArray, stringListTypeArray));

        assertTrue(TypeUtils.isAssignable(subStringListTypeArray, subStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(subStringListTypeArray, superStringListTypeArray));
        assertFalse(TypeUtils.isAssignable(superStringListTypeArray, subStringListTypeArray));
        assertTrue(TypeUtils.isAssignable(superStringListTypeArray, superStringListTypeArray));
    }

    @Test
    void testIsAssignableGenericListTypes() throws NoSuchFieldException {
        final Type rawListType = GenericTypeHolder.class.getDeclaredField("rawList").getGenericType();
        final Type objectListType = GenericTypeHolder.class.getDeclaredField("objectList").getGenericType();
        final Type unboundListType = GenericTypeHolder.class.getDeclaredField("unboundList").getGenericType();
        final Type superObjectListType = GenericTypeHolder.class.getDeclaredField("superObjectList").getGenericType();
        final Type stringListType = GenericTypeHolder.class.getDeclaredField("stringList").getGenericType();
        final Type subStringListType = GenericTypeHolder.class.getDeclaredField("subStringList").getGenericType();
        final Type superStringListType = GenericTypeHolder.class.getDeclaredField("superStringList").getGenericType();

        assertTrue(TypeUtils.isAssignable(rawListType, rawListType));
        assertTrue(TypeUtils.isAssignable(rawListType, objectListType));
        assertTrue(TypeUtils.isAssignable(objectListType, rawListType));
        assertTrue(TypeUtils.isAssignable(rawListType, unboundListType));
        assertTrue(TypeUtils.isAssignable(unboundListType, rawListType));
        assertTrue(TypeUtils.isAssignable(rawListType, superObjectListType));
        assertTrue(TypeUtils.isAssignable(superObjectListType, rawListType));
        assertTrue(TypeUtils.isAssignable(rawListType, stringListType));
        assertTrue(TypeUtils.isAssignable(stringListType, rawListType));
        assertTrue(TypeUtils.isAssignable(rawListType, subStringListType));
        assertTrue(TypeUtils.isAssignable(subStringListType, rawListType));
        assertTrue(TypeUtils.isAssignable(rawListType, superStringListType));
        assertTrue(TypeUtils.isAssignable(superStringListType, rawListType));

        assertTrue(TypeUtils.isAssignable(objectListType, objectListType));
        assertTrue(TypeUtils.isAssignable(objectListType, unboundListType));
        assertFalse(TypeUtils.isAssignable(unboundListType, objectListType));
        assertTrue(TypeUtils.isAssignable(objectListType, superObjectListType));
        assertFalse(TypeUtils.isAssignable(superObjectListType, objectListType));
        assertFalse(TypeUtils.isAssignable(objectListType, stringListType));
        assertFalse(TypeUtils.isAssignable(stringListType, objectListType));
        assertFalse(TypeUtils.isAssignable(objectListType, subStringListType));
        assertFalse(TypeUtils.isAssignable(subStringListType, objectListType));
        assertTrue(TypeUtils.isAssignable(objectListType, superStringListType));
        assertFalse(TypeUtils.isAssignable(superStringListType, objectListType));

        assertTrue(TypeUtils.isAssignable(unboundListType, unboundListType));
        assertFalse(TypeUtils.isAssignable(unboundListType, superObjectListType));
        assertTrue(TypeUtils.isAssignable(superObjectListType, unboundListType));
        assertFalse(TypeUtils.isAssignable(unboundListType, stringListType));
        assertTrue(TypeUtils.isAssignable(stringListType, unboundListType));
        assertFalse(TypeUtils.isAssignable(unboundListType, subStringListType));
        assertTrue(TypeUtils.isAssignable(subStringListType, unboundListType));
        assertFalse(TypeUtils.isAssignable(unboundListType, superStringListType));
        assertTrue(TypeUtils.isAssignable(superStringListType, unboundListType));

        assertTrue(TypeUtils.isAssignable(superObjectListType, superObjectListType));
        assertFalse(TypeUtils.isAssignable(superObjectListType, stringListType));
        assertFalse(TypeUtils.isAssignable(stringListType, superObjectListType));
        assertFalse(TypeUtils.isAssignable(superObjectListType, subStringListType));
        assertFalse(TypeUtils.isAssignable(subStringListType, superObjectListType));
        assertTrue(TypeUtils.isAssignable(superObjectListType, superStringListType));
        assertFalse(TypeUtils.isAssignable(superStringListType, superObjectListType));

        assertTrue(TypeUtils.isAssignable(stringListType, stringListType));
        assertTrue(TypeUtils.isAssignable(stringListType, subStringListType));
        assertFalse(TypeUtils.isAssignable(subStringListType, stringListType));
        assertTrue(TypeUtils.isAssignable(stringListType, superStringListType));
        assertFalse(TypeUtils.isAssignable(superStringListType, stringListType));

        assertTrue(TypeUtils.isAssignable(subStringListType, subStringListType));
        assertFalse(TypeUtils.isAssignable(subStringListType, superStringListType));
        assertFalse(TypeUtils.isAssignable(superStringListType, subStringListType));
        assertTrue(TypeUtils.isAssignable(superStringListType, superStringListType));
    }

    @Test
    void testIsAssignableWildcardWithMultipleUpperBounds() {
        // ? extends Serializable & Cloneable
        final WildcardType subject = TypeUtils.wildcardType()
                .withUpperBounds(Serializable.class, Cloneable.class)
                .build();

        // ? extends Serializable
        final WildcardType targetSerializable = TypeUtils.wildcardType()
                .withUpperBounds(Serializable.class)
                .build();

        // ? extends Cloneable
        final WildcardType targetCloneable = TypeUtils.wildcardType()
                .withUpperBounds(Cloneable.class)
                .build();

        // ? extends CharSequence
        final WildcardType targetCharSequence = TypeUtils.wildcardType()
                .withUpperBounds(CharSequence.class)
                .build();

        // ? extends Serializable & Cloneable
        final WildcardType targetSerializableAndCloneable = TypeUtils.wildcardType()
                .withUpperBounds(Serializable.class, Cloneable.class)
                .build();

        // ? extends Serializable & CharSequence
        final WildcardType targetSerializableAndCharSequence = TypeUtils.wildcardType()
                .withUpperBounds(Serializable.class, CharSequence.class)
                .build();

        // Single target bound satisfied
        assertTrue(TypeUtils.isAssignable(subject, targetSerializable));
        assertTrue(TypeUtils.isAssignable(subject, targetCloneable));
        assertTrue(TypeUtils.isAssignable(subject, TypeUtils.wildcardType().withUpperBounds(Object.class).build()));
        assertFalse(TypeUtils.isAssignable(subject, targetCharSequence));

        // Multiple target bounds where all are satisfied
        assertTrue(TypeUtils.isAssignable(subject, targetSerializableAndCloneable));
        assertTrue(TypeUtils.isAssignable(subject, TypeUtils.wildcardType().withUpperBounds(Object.class, Serializable.class).build()));

        // Multiple target bounds where only one is satisfied
        assertFalse(TypeUtils.isAssignable(subject, targetSerializableAndCharSequence));

        // Reverse direction: single bound cannot satisfy multiple bounds
        assertFalse(TypeUtils.isAssignable(targetSerializable, subject));
        assertFalse(TypeUtils.isAssignable(targetCloneable, subject));
    }

    @SuppressWarnings("boxing") // boxing is deliberate here
    @Test
    void testIsInstance() throws NoSuchFieldException {
        assertFalse(TypeUtils.isInstance(1, null));
        final Type intComparableType = getClass().getField("intComparable").getGenericType();
        final Type uriComparableType = getClass().getField("uriComparable").getGenericType();
        assertTrue(TypeUtils.isInstance(1, intComparableType));
        assertFalse(TypeUtils.isInstance(1, uriComparableType));
    }

    @Test
    void testLowerBoundedWildcardType() {
       final WildcardType lowerBounded = TypeUtils.wildcardType().withLowerBounds(java.sql.Date.class).build();
       assertEquals(String.format("? super %s", java.sql.Date.class.getName()), TypeUtils.toString(lowerBounded));
       assertEquals(String.format("? super %s", java.sql.Date.class.getName()), lowerBounded.toString());

       final TypeVariable<Class<Iterable>> iterableT0 = Iterable.class.getTypeParameters()[0];
       final WildcardType lowerTypeVariable = TypeUtils.wildcardType().withLowerBounds(iterableT0).build();
       assertEquals(String.format("? super %s", iterableT0.getName()), TypeUtils.toString(lowerTypeVariable));
       assertEquals(String.format("? super %s", iterableT0.getName()), lowerTypeVariable.toString());
    }

    @Test
    void testMultiBoundRecursiveType() {
        assertEquals("org.apache.commons.lang3.reflect.MultiBoundClass<U extends java.lang.Number & java.lang.Comparable<? super U>>",
                TypeUtils.toString(MultiBoundClass.class));
        assertEquals("U extends java.lang.Number & java.lang.Comparable<? super U>",
                TypeUtils.toString(MultiBoundClass.class.getTypeParameters()[0]));
    }

    @Test
    void testMultiParamRecursiveType() {
        final ParameterizedType parameterizedType = TypeUtils.parameterize(TwoParams.class, TwoParams.class.getTypeParameters());
        assertEquals("org.apache.commons.lang3.reflect.TwoParams<T, U>",
                TypeUtils.toString(parameterizedType));
    }

    @Test
    void testNormalizeUpperBounds() {
        final Type[] typeArray = { Collection.class, List.class };
        final Type[] expectedArray = { List.class };
        assertArrayEquals(expectedArray, TypeUtils.normalizeUpperBounds(typeArray));
    }

    @Test
    void testNormalizeUpperBounds_LANG_820() {
        final Type[] typeArray = { String.class, String.class };
        final Type[] expectedArray = { String.class };
        assertArrayEquals(expectedArray, TypeUtils.normalizeUpperBounds(typeArray));
    }

    @Test
    void testParameterizedOwnerWithNonGenericInnerClassToString() throws NoSuchMethodException {
        final ParameterizedType owner = TypeUtils.parameterize(ParameterizedOwner.class, String.class);
        final ParameterizedType nonGenericInner = TypeUtils.parameterizeWithOwner(owner, ParameterizedOwner.NonGenericInner.class);
        assertEquals("org.apache.commons.lang3.reflect.ParameterizedOwner<java.lang.String>.NonGenericInner",
                TypeUtils.toString(nonGenericInner));

        final Type methodReturnType = ParameterizedOwner.class.getMethod("getInner").getGenericReturnType();
        assertEquals("org.apache.commons.lang3.reflect.ParameterizedOwner<T>.NonGenericInner",
                TypeUtils.toString(methodReturnType));
    }

    @Test
    void testParameterizeMapArg() throws NoSuchFieldException {
        final Map<TypeVariable<?>, Type> typeVariableMap = new HashMap<>();
        typeVariableMap.put(Comparable.class.getTypeParameters()[0], String.class);
        final ParameterizedType stringComparableType = TypeUtils.parameterize(Comparable.class, typeVariableMap);
        assertTrue(TypeUtils.equals(getClass().getField("stringComparable").getGenericType(), stringComparableType));
        assertEquals("java.lang.Comparable<java.lang.String>", stringComparableType.toString());
    }

    @Test
    void testParameterizeNarrowerTypeArray() {
        final TypeVariable<?>[] variables = ArrayList.class.getTypeParameters();
        final ParameterizedType parameterizedType = TypeUtils.parameterize(ArrayList.class, variables);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(variables[0], String.class);
        final Type unrolled = TypeUtils.unrollVariables(mapping, parameterizedType);
        assertEquals(TypeUtils.parameterize(ArrayList.class, String.class), unrolled);
    }

    @Test
    void testParameterizeNullPointerException() {
        assertNullPointerException(() -> TypeUtils.parameterize(null, Collections.emptyMap()));
        final Map<TypeVariable<?>, Type> nullTypeVariableMap = null;
        assertNullPointerException(() -> TypeUtils.parameterize(String.class, nullTypeVariableMap));
    }

    @Test
    void testParameterizeVarArgs() throws NoSuchFieldException {
        final ParameterizedType stringComparableType = TypeUtils.parameterize(Comparable.class, String.class);
        assertTrue(TypeUtils.equals(getClass().getField("stringComparable").getGenericType(), stringComparableType));
        assertEquals("java.lang.Comparable<java.lang.String>", stringComparableType.toString());
    }

    @Test
    void testParameterizeVarArgsNullPointerException() {
        assertNullPointerException(() -> TypeUtils.parameterize(null));
    }

    @SuppressWarnings("unlikely-arg-type")
    @Test
    void testParameterizeWithOwner() throws NoSuchFieldException {
        final Type owner = TypeUtils.parameterize(TypeUtilsTest.class, String.class);
        final ParameterizedType dat2Type1 = TypeUtils.parameterizeWithOwner(owner, That.class, String.class, String.class);
        assertTrue(TypeUtils.equals(getClass().getField("dat2").getGenericType(), dat2Type1));
        assertNotEquals(0, dat2Type1.hashCode());
        assertEquals(dat2Type1, dat2Type1);
        final ParameterizedType dat2Type2 = TypeUtils.parameterizeWithOwner(null, That.class, String.class, String.class);
        assertEquals(That.class, dat2Type2.getRawType());
        assertNotEquals(0, dat2Type2.hashCode());
        assertEquals(dat2Type2, dat2Type2);
        assertNotEquals(dat2Type2, dat2Type1);
        assertFalse(dat2Type1.equals(null));
        assertFalse(dat2Type1.equals(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testParameterizeWithOwner3ArgsNullPointerException() {
        final Type owner = TypeUtils.parameterize(TypeUtilsTest.class, String.class);
        assertNullPointerException(() -> TypeUtils.parameterizeWithOwner(owner, null, String.class));
        final Map<TypeVariable<?>, Type> nullTypeVariableMap = null;
        assertNullPointerException(() -> TypeUtils.parameterizeWithOwner(owner, That.class, nullTypeVariableMap));
        final Map<TypeVariable<?>, Type> typeVariableMap1 = new HashMap<>();
        typeVariableMap1.put(Comparable.class.getTypeParameters()[0], String.class);
        assertEquals(Comparable.class, TypeUtils.parameterizeWithOwner(null, Comparable.class, typeVariableMap1).getRawType());
        final Map<TypeVariable<?>, Type> typeVariableMap2 = new HashMap<>();
        typeVariableMap2.put(MyInnerClass.class.getTypeParameters()[0], String.class);
        assertEquals(MyInnerClass.class, TypeUtils.parameterizeWithOwner(null, MyInnerClass.class, typeVariableMap2).getRawType());
        assertEquals(MyInnerClass.class, TypeUtils.parameterizeWithOwner(owner, MyInnerClass.class, typeVariableMap2).getRawType());
    }

    @Test
    void testParameterizeWithOwnerVarArgsNullPointerException() {
        final Type owner = TypeUtils.parameterize(TypeUtilsTest.class, String.class);
        assertNullPointerException(() -> TypeUtils.parameterizeWithOwner(owner, null));
    }

    @Test
    void testRecursiveTypeWildcardBoundClass() {
        assertEquals("org.apache.commons.lang3.reflect.MyClass<U extends org.apache.commons.lang3.reflect.MySuperClass<? super U>>",
                TypeUtils.toString(MyClass.class));
        assertEquals("U extends org.apache.commons.lang3.reflect.MySuperClass<? super U>",
                TypeUtils.toString(MyClass.class.getTypeParameters()[0]));
    }

    @Test
    void testRepeatedSiblingReferencesToString() {
        final ParameterizedType listString = TypeUtils.parameterize(List.class, String.class);
        final ParameterizedType mapType = TypeUtils.parameterize(Map.class, listString, listString);
        assertEquals("java.util.Map<java.util.List<java.lang.String>, java.util.List<java.lang.String>>",
                TypeUtils.toString(mapType));

        final TypeVariable<?> t = DependentBounds.class.getTypeParameters()[0];
        final ParameterizedType biFunctionType = TypeUtils.parameterize(BiFunction.class, t, t, t);
        assertEquals("java.util.function.BiFunction<T, T, T>", TypeUtils.toString(biFunctionType));

        final WildcardType wildcard = TypeUtils.wildcardType().withUpperBounds(listString).build();
        final ParameterizedType mapWildcards = TypeUtils.parameterize(Map.class, wildcard, wildcard);
        assertEquals("java.util.Map<? extends java.util.List<java.lang.String>, ? extends java.util.List<java.lang.String>>",
                TypeUtils.toString(mapWildcards));
    }

    @Test
    void testThreadLocalCleanupAfterException() {
        final Type unsupportedType = new Type() {
            @Override
            public String getTypeName() {
                return "Unsupported";
            }
        };
        assertThrows(IllegalArgumentException.class, () -> TypeUtils.toString(unsupportedType));
        assertEquals("java.lang.String", TypeUtils.toString(String.class));

        final Type faultyType = new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                throw new IllegalStateException("Simulated failure in getActualTypeArguments");
            }

            @Override
            public Type getOwnerType() {
                return null;
            }

            @Override
            public Type getRawType() {
                return List.class;
            }
        };
        assertThrows(IllegalStateException.class, () -> TypeUtils.toString(faultyType));
        assertEquals("java.lang.String", TypeUtils.toString(String.class));

        final ParameterizedType wrapper = new ParameterizedType() {
            @Override
            public Type[] getActualTypeArguments() {
                return new Type[] { faultyType };
            }

            @Override
            public Type getOwnerType() {
                return null;
            }

            @Override
            public Type getRawType() {
                return Set.class;
            }
        };
        assertThrows(IllegalStateException.class, () -> TypeUtils.toString(wrapper));
        assertEquals("java.util.List<java.lang.String>",
                TypeUtils.toString(TypeUtils.parameterize(List.class, String.class)));
    }

    @Test
    void testToLongString() {
        assertNullPointerException(() -> TypeUtils.toLongString(null));
        assertEquals(getClass().getName() + ":B", TypeUtils.toLongString(getClass().getTypeParameters()[0]));
        assertEquals(getClass().getName() + ".MyInnerClass:T", TypeUtils.toLongString(MyInnerClass.class.getTypeParameters()[0]));
        assertEquals(getClass().getName() + ".That:K", TypeUtils.toLongString(That.class.getTypeParameters()[0]));
        assertEquals(getClass().getName() + ".The:K", TypeUtils.toLongString(The.class.getTypeParameters()[0]));
        assertEquals(getClass().getName() + ".MyInnerClass.MyInnerClass2:X", TypeUtils.toLongString(MyInnerClass.MyInnerClass2.class.getTypeParameters()[0]));
    }

    @Test
    void testToLongStringBoundedTypeVariable() {
        assertEquals("org.apache.commons.lang3.reflect.DependentBounds:T extends java.lang.Number",
                TypeUtils.toLongString(DependentBounds.class.getTypeParameters()[0]));
        assertEquals("org.apache.commons.lang3.reflect.DependentBounds:S extends T",
                TypeUtils.toLongString(DependentBounds.class.getTypeParameters()[1]));
        assertEquals("org.apache.commons.lang3.reflect.MultiBoundClass:U extends java.lang.Number & java.lang.Comparable<? super U>",
                TypeUtils.toLongString(MultiBoundClass.class.getTypeParameters()[0]));
        assertEquals("org.apache.commons.lang3.reflect.InterfaceBound:T extends java.util.List<java.lang.String>",
                TypeUtils.toLongString(InterfaceBound.class.getTypeParameters()[0]));
        assertEquals("org.apache.commons.lang3.reflect.MyClass:U extends org.apache.commons.lang3.reflect.MySuperClass<? super U>",
                TypeUtils.toLongString(MyClass.class.getTypeParameters()[0]));
    }

    @Test
    void testToString() {
        assertNullPointerException(() -> TypeUtils.toString(null));
        assertIllegalArgumentException(() -> TypeUtils.toString(new Type() {
            // empty
        }));
    }

    @Test
    void testToString_LANG_1311() {
        assertEquals("int[]", TypeUtils.toString(int[].class));
        assertEquals("java.lang.Integer[]", TypeUtils.toString(Integer[].class));
        final Field stringListField = FieldUtils.getDeclaredField(getClass(), "stringListArray");
        assertEquals("java.util.List<java.lang.String>[]", TypeUtils.toString(stringListField.getGenericType()));
    }

    @Test
    void testTypesSatisfyVariables() throws NoSuchMethodException {
        final Map<TypeVariable<?>, Type> typeVarAssigns = new HashMap<>();
        final Integer max = TypeUtilsTest.<Integer>stub();
        typeVarAssigns.put(getClass().getMethod("stub").getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(typeVarAssigns));
        typeVarAssigns.clear();
        typeVarAssigns.put(getClass().getMethod("stub2").getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(typeVarAssigns));
        typeVarAssigns.clear();
        typeVarAssigns.put(getClass().getMethod("stub3").getTypeParameters()[0], Integer.class);
        assertTrue(TypeUtils.typesSatisfyVariables(typeVarAssigns));
        assertNullPointerException(() -> TypeUtils.typesSatisfyVariables(null));
    }

    @ParameterizedTest
    @MethodSource
    void testTypeToString(final Type type) {
        // No stack overflow
        assertNotNull(TypeUtils.toString(type));
    }

    @Test
    void testUnboundedWildcardType() {
        final WildcardType unbounded = TypeUtils.wildcardType().withLowerBounds((Type) null).withUpperBounds().build();
        assertTrue(TypeUtils.equals(TypeUtils.WILDCARD_ALL, unbounded));
        assertEquals(TypeUtils.WILDCARD_ALL.hashCode(), unbounded.hashCode());
        assertArrayEquals(new Type[] { Object.class }, TypeUtils.getImplicitUpperBounds(unbounded));
        assertArrayEquals(new Type[] { null }, TypeUtils.getImplicitLowerBounds(unbounded));
        assertEquals("?", TypeUtils.toString(unbounded));
        assertEquals("?", unbounded.toString());
        assertNullPointerException(() -> TypeUtils.getImplicitLowerBounds(null));
        assertNullPointerException(() -> TypeUtils.getImplicitUpperBounds(null));
    }

    @Test
    void testUnrollVariables() {
        final TypeVariable<?>[] variables = ArrayList.class.getTypeParameters();
        final ParameterizedType parameterizedType = TypeUtils.parameterize(ArrayList.class, variables);
        assertEquals("java.util.ArrayList<E>", TypeUtils.unrollVariables(null, parameterizedType).getTypeName());
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(variables[0], String.class);
        assertEquals("java.util.ArrayList<java.lang.String>", TypeUtils.unrollVariables(mapping, parameterizedType).getTypeName());
    }

    @Test
    void testUnrollVariablesCycleThroughTypeArgumentAndOwner() {
        // LANG-1836: Map<Inner, T> whose argument Inner has the Map as its owner. The cycle is left as it is instead of overflowing the stack, while T is unrolled.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final CyclicParameterizedType inner = new CyclicParameterizedType(Outer.Inner.class);
        final CyclicParameterizedType map = new CyclicParameterizedType(Map.class, inner, t);
        inner.setOwnerType(map);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        final Type[] unrolledArguments = ((ParameterizedType) TypeUtils.unrollVariables(mapping, map)).getActualTypeArguments();
        assertSame(inner, unrolledArguments[0]);
        assertEquals(String.class, unrolledArguments[1]);
    }

    @Test
    void testUnrollVariablesCyclicOwnerChain() {
        // LANG-1836: A -> owner B<T> -> owner A is left as it is and must not cause a StackOverflowError.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final CyclicParameterizedType a = new CyclicParameterizedType(Outer.Inner.class);
        final CyclicParameterizedType b = new CyclicParameterizedType(Outer.class, t);
        a.setOwnerType(b);
        b.setOwnerType(a);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        final ParameterizedType unrolled = (ParameterizedType) TypeUtils.unrollVariables(mapping, a);
        assertEquals(Outer.Inner.class, unrolled.getRawType());
        assertSame(b, unrolled.getOwnerType());
    }

    @Test
    void testUnrollVariablesCyclicOwnerChainFromEitherType() {
        // LANG-1836: the cycle is left alone whichever type of the cycle is unrolled first.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final CyclicParameterizedType a = new CyclicParameterizedType(Outer.Inner.class);
        final CyclicParameterizedType b = new CyclicParameterizedType(Outer.class, t);
        a.setOwnerType(b);
        b.setOwnerType(a);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        assertSame(b, TypeUtils.unrollVariables(mapping, b));
    }

    @Test
    void testUnrollVariablesGenericArray() {
        final TypeVariable<?> variable = ArrayValues.class.getTypeParameters()[0];
        final GenericArrayType array = TypeUtils.genericArrayType(variable);
        assertSame(array, TypeUtils.unrollVariables(Collections.emptyMap(), array));
        assertSame(array, TypeUtils.unrollVariables(Collections.singletonMap(variable, variable), array));
        assertEquals(String[].class, TypeUtils.unrollVariables(Collections.singletonMap(variable, String.class), array));
        final Type list = TypeUtils.parameterize(List.class, String.class);
        assertEquals(TypeUtils.genericArrayType(list), TypeUtils.unrollVariables(Collections.singletonMap(variable, list), array));
        assertEquals(String[][].class,
                TypeUtils.unrollVariables(Collections.singletonMap(variable, String.class), TypeUtils.genericArrayType(array)));
    }

    @Test
    void testUnrollVariablesGenericArrayCyclicAssignment() {
        final TypeVariable<?> variable = ArrayValues.class.getTypeParameters()[0];
        final GenericArrayType array = TypeUtils.genericArrayType(variable);
        final Map<TypeVariable<?>, Type> mapping = Collections.singletonMap(variable, array);
        assertSame(array, TypeUtils.unrollVariables(mapping, variable));
        assertSame(variable, array.getGenericComponentType());
    }

    @Test
    void testUnrollVariablesGenericArraySelfReference() {
        final GenericArrayType array = new GenericArrayType() {
            @Override
            public Type getGenericComponentType() {
                return this;
            }
        };
        assertSame(array, TypeUtils.unrollVariables(Collections.emptyMap(), array));
        assertSame(array, array.getGenericComponentType());
    }

    @Test
    void testUnrollVariablesMultiLevelOwnerType() throws NoSuchFieldException {
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final TypeVariable<?> u = Outer.InnerU.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> mapping = new HashMap<>();
        mapping.put(t, String.class);
        mapping.put(u, Integer.class);
        final Type original = Outer.InnerU.class.getDeclaredField("deep").getGenericType();
        final Type outer = TypeUtils.parameterize(Outer.class, String.class);
        final Type inner = TypeUtils.parameterizeWithOwner(outer, Outer.InnerU.class, Integer.class);
        final Type expected = TypeUtils.parameterizeWithOwner(inner, Outer.InnerU.Deep.class, String.class);
        assertEquals(expected, TypeUtils.unrollVariables(mapping, original));
        assertTrue(TypeUtils.containsTypeVariables(original));
    }

    @Test
    void testUnrollVariablesMutuallyCyclicAssignments() {
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final TypeVariable<?> u = Outer.InnerU.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> mapping = new HashMap<>();
        mapping.put(t, u);
        mapping.put(u, t);
        assertSame(t, TypeUtils.unrollVariables(mapping, t));
        assertSame(u, TypeUtils.unrollVariables(mapping, u));
        final Type repeated = TypeUtils.parameterize(Map.class, t, t);
        assertSame(repeated, TypeUtils.unrollVariables(mapping, repeated));
    }

    @Test
    void testUnrollVariablesOwnerType() throws NoSuchFieldException {
        // LANG-1836
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        final ParameterizedType outerString = TypeUtils.parameterize(Outer.class, String.class);
        // Outer<T>.Inner -> Outer<String>.Inner
        assertEquals(TypeUtils.parameterizeWithOwner(outerString, Outer.Inner.class),
                TypeUtils.unrollVariables(mapping, Outer.class.getDeclaredField("inner").getGenericType()));
        // Outer<T>.InnerU<Integer> -> Outer<String>.InnerU<Integer>
        assertEquals(TypeUtils.parameterizeWithOwner(outerString, Outer.InnerU.class, Integer.class),
                TypeUtils.unrollVariables(mapping, Outer.class.getDeclaredField("innerUInteger").getGenericType()));
        // Outer<T>.InnerU<T> -> Outer<String>.InnerU<String>
        assertEquals(TypeUtils.parameterizeWithOwner(outerString, Outer.InnerU.class, String.class),
                TypeUtils.unrollVariables(mapping, Outer.class.getDeclaredField("innerUT").getGenericType()));
        // Map.Entry<T, Integer> -> Map.Entry<String, Integer>: the raw owner Map.class is left unchanged.
        assertEquals(TypeUtils.parameterizeWithOwner(Map.class, Map.Entry.class, String.class, Integer.class),
                TypeUtils.unrollVariables(mapping, Outer.class.getDeclaredField("entry").getGenericType()));
    }

    @Test
    void testUnrollVariablesRepeatedVariable() throws NoSuchFieldException {
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        // Map<T, T> -> Map<String, String>: every occurrence of T is unrolled, not only the first.
        assertEquals(TypeUtils.parameterize(Map.class, String.class, String.class),
                TypeUtils.unrollVariables(mapping, Outer.class.getDeclaredField("map").getGenericType()));
    }

    @Test
    void testUnrollVariablesReturnsTheSameTypeWhenNothingChanges() {
        // LANG-1836: a type that unrolling does not change is returned as it is instead of being rebuilt.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final Type listOfT = TypeUtils.parameterize(List.class, t);
        assertSame(listOfT, TypeUtils.unrollVariables(Collections.emptyMap(), listOfT));
        final Type listOfString = TypeUtils.parameterize(List.class, String.class);
        assertSame(listOfString, TypeUtils.unrollVariables(Collections.emptyMap(), listOfString));
    }

    @Test
    void testUnrollVariablesReturnsTheSameWildcardWhenNothingChanges() {
        final WildcardType concrete = TypeUtils.wildcardType().withUpperBounds(Number.class).build();
        assertSame(concrete, TypeUtils.unrollVariables(Collections.emptyMap(), concrete));
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final WildcardType variable = TypeUtils.wildcardType().withLowerBounds(t).build();
        assertSame(variable, TypeUtils.unrollVariables(Collections.singletonMap(t, t), variable));
    }

    @Test
    void testUnrollVariablesSelfCyclicAssignment() {
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> mapping = Collections.singletonMap(t, t);
        assertSame(t, TypeUtils.unrollVariables(mapping, t));
        final Type repeated = TypeUtils.parameterize(Map.class, t, t);
        assertSame(repeated, TypeUtils.unrollVariables(mapping, repeated));
    }

    @Test
    void testUnrollVariablesSelfOwnedTypeWithTypeVariable() {
        // LANG-1836
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final CyclicParameterizedType self = new CyclicParameterizedType(Outer.InnerU.class, t);
        self.setOwnerType(self);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        assertSame(self, TypeUtils.unrollVariables(mapping, self));
    }

    @Test
    void testUnrollVariablesSelfReferencingTypeArgument() {
        // LANG-1836: the cycle through the type argument is left as it is while the variable is still unrolled.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final CyclicParameterizedType self = new CyclicParameterizedType(Map.class);
        self.setTypeArguments(self, t);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, String.class);
        final Type[] unrolledArguments = ((ParameterizedType) TypeUtils.unrollVariables(mapping, self)).getActualTypeArguments();
        assertSame(self, unrolledArguments[0]);
        assertEquals(String.class, unrolledArguments[1]);
    }

    @Test
    void testUnrollVariablesWildcardBounds() {
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final Map<TypeVariable<?>, Type> mapping = Collections.singletonMap(t, String.class);
        final WildcardType upper = TypeUtils.wildcardType().withUpperBounds(t).build();
        final WildcardType lower = TypeUtils.wildcardType().withLowerBounds(t).build();
        final Type original = TypeUtils.parameterize(Map.class, upper, lower);
        final Type expected = TypeUtils.parameterize(Map.class,
                TypeUtils.wildcardType().withUpperBounds(String.class).build(),
                TypeUtils.wildcardType().withLowerBounds(String.class).build());
        assertEquals(expected, TypeUtils.unrollVariables(mapping, original));
        assertArrayEquals(new Type[] { t }, upper.getUpperBounds());
        assertArrayEquals(new Type[0], upper.getLowerBounds());
        assertArrayEquals(new Type[] { Object.class }, lower.getUpperBounds());
        assertArrayEquals(new Type[] { t }, lower.getLowerBounds());
        assertArrayEquals(new Type[] { upper, lower }, ((ParameterizedType) original).getActualTypeArguments());
    }

    @Test
    void testUnrollVariablesWildcardCycleThroughOwnerType() {
        // LANG-1836: {T -> Outer<? extends T>.Inner} must not cause a StackOverflowError when T is unrolled.
        final TypeVariable<?> t = Outer.class.getTypeParameters()[0];
        final WildcardType extendsT = TypeUtils.wildcardType().withUpperBounds(t).build();
        final Type outerExtendsT = TypeUtils.parameterizeWithOwner(TypeUtils.parameterize(Outer.class, extendsT), Outer.Inner.class);
        final Map<TypeVariable<?>, Type> mapping = Collections.<TypeVariable<?>, Type>singletonMap(t, outerExtendsT);
        assertEquals(outerExtendsT, TypeUtils.unrollVariables(mapping, t));
    }

    @SuppressWarnings("unlikely-arg-type")
    @Test
    void testWildcardType() throws NoSuchFieldException {
        final WildcardType simpleWildcard = TypeUtils.wildcardType().withUpperBounds(String.class).build();
        final Field cClass = AClass.class.getField("cClass");
        assertTrue(TypeUtils.equals(((ParameterizedType) cClass.getGenericType()).getActualTypeArguments()[0], simpleWildcard));
        assertEquals(String.format("? extends %s", String.class.getName()), TypeUtils.toString(simpleWildcard));
        assertEquals(String.format("? extends %s", String.class.getName()), simpleWildcard.toString());
        assertNotEquals(0, simpleWildcard.hashCode());
        assertEquals(simpleWildcard, simpleWildcard);
        assertFalse(simpleWildcard.equals(null));
        assertFalse(simpleWildcard.equals(TypeUtils.genericArrayType(String.class)));
    }

    @Test
    void testWildcardTypeBuilderDefensiveCopy() {
        // Upper bounds defensive copying on input array and getter
        final Type[] upperBounds = { String.class };
        final WildcardType wildcardUpper = TypeUtils.wildcardType().withUpperBounds(upperBounds).build();
        upperBounds[0] = Integer.class;
        assertArrayEquals(new Type[] { String.class }, wildcardUpper.getUpperBounds());
        wildcardUpper.getUpperBounds()[0] = Integer.class;
        assertArrayEquals(new Type[] { String.class }, wildcardUpper.getUpperBounds());

        // Lower bounds defensive copying on input array and getter
        final Type[] lowerBounds = { String.class };
        final WildcardType wildcardLower = TypeUtils.wildcardType().withLowerBounds(lowerBounds).build();
        lowerBounds[0] = Integer.class;
        assertArrayEquals(new Type[] { String.class }, wildcardLower.getLowerBounds());
        wildcardLower.getLowerBounds()[0] = Integer.class;
        assertArrayEquals(new Type[] { String.class }, wildcardLower.getLowerBounds());
    }

    @Test
    void testWildcardTypeImplicitUpperBound() throws NoSuchFieldException {
        final WildcardType built = TypeUtils.wildcardType().build();
        // An unbounded wildcard has an implicit upper bound of Object, per WildcardType.getUpperBounds().
        assertArrayEquals(new Type[] { Object.class }, built.getUpperBounds());
        // equals() must be symmetric with a JDK unbounded wildcard.
        final WildcardType jdk = (WildcardType) ((ParameterizedType) TypeUtilsTest.class.getField("wildcardComparable")
                .getGenericType()).getActualTypeArguments()[0];
        assertEquals(built, jdk);
        assertEquals(jdk, built);
        // Equal wildcards must share a hash code.
        assertEquals(jdk.hashCode(), built.hashCode());
        assertEquals(TypeUtils.WILDCARD_ALL, built);
        assertEquals(TypeUtils.WILDCARD_ALL.hashCode(), built.hashCode());
    }

    @Test
    void testWildcardTypeRedundantUpperBound() {
        // equals() ignores a redundant upper bound, so hashCode() must ignore it too.
        final WildcardType redundant = TypeUtils.wildcardType().withUpperBounds(Collection.class, List.class).build();
        final WildcardType simple = TypeUtils.wildcardType().withUpperBounds(List.class).build();
        assertEquals(simple, redundant);
        assertEquals(redundant, simple);
        assertEquals(simple.hashCode(), redundant.hashCode());
    }

    @Test
    void testWrap() {
        final Type t = getClass().getTypeParameters()[0];
        assertTrue(TypeUtils.equals(t, TypeUtils.wrap(t).getType()));
        assertEquals(String.class, TypeUtils.wrap(String.class).getType());
    }

}
